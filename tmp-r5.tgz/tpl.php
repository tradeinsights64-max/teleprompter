<?php
use Illuminate\Support\Facades\DB;
$T = ['flow.country_needs_info' => [
 'en' => "Thanks for your interest in Trade Insight 🙏\n\nBefore we set you up, we need a little more information about where you live and trade. Please message our team: @trade_insight_support_team",
 'am' => "ለTrade Insight ፍላጎት ስላሳዩ እናመሰግናለን 🙏\n\nከመመዝገብዎ በፊት ስለሚኖሩበት እና trade ስለሚያደርጉበት ሀገር ትንሽ ተጨማሪ መረጃ ያስፈልገናል። እባክዎ ቡድናችንን ያናግሩ፦ @trade_insight_support_team"]];
foreach ($T as $key => $langs) foreach ($langs as $lang => $body) {
  $q = DB::table('message_templates')->where('key',$key)->where('language',$lang);
  if ($q->exists()) { $q->update(['body'=>$body]); echo "updated $key $lang\n"; continue; }
  $base = (array) DB::table('message_templates')->where('key','flow.inactivity_reminder')->where('language',$lang)->first();
  unset($base['id']); $base['key']=$key; $base['body']=$body; foreach (['created_at','updated_at'] as $c) if (array_key_exists($c,$base)) $base[$c]=now();
  if (array_key_exists('label',$base)) $base['label']='Country Review — needs more info';
  DB::table('message_templates')->insert($base); echo "created $key $lang\n";
}
foreach (DB::table('message_templates')->where('key','flow.region_paid_options')->get(['language','body']) as $r) echo "OFFER $r->language: ".str_replace("\n"," / ",$r->body)."\n";
echo 'payments '.(app(App\Services\Payments\PurchaseFlow::class)->enabled() ? 'on' : 'off')."\n";
Cache::flush();
