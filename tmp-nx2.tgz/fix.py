import os,re,shutil,glob,json
os.chdir('/var/www/TradeInsightProduction/TD/StudentPortal')
B='/root/backups/allcourses-20261120'; os.makedirs(B,exist_ok=True)
def rd(p): return open(p,encoding='utf-8').read()
def wr(p,s): open(p,'w',encoding='utf-8').write(s)
def q(x): return json.dumps(x,ensure_ascii=False)
HERO='Stop guessing the market. All courses, live sessions every week and a VIP community — all free. Your seat is waiting in our Telegram bot.'
M1o='The full 13-module Academy, Bootcamp and VIP — 100% free. Register through our Telegram bot.'
M1n='All courses, Bootcamp and VIP — 100% free. Register through our Telegram bot.'
M2o='The same 13-module Academy and VIP if the free option is not available in your country.'
M2n='The same courses and VIP if the free option is not available in your country.'
AM={HERO:'ማርኬቱን በግምት መነገድ ይብቃ። ሁሉም ኮርሶች፣ በየሳምንቱ live sessions እና VIP community — ሁሉም ነጻ። ቦታዎ በTelegram bot ይጠብቅዎታል።',
    M1n:'ሁሉም ኮርሶች፣ Bootcamp እና VIP — 100% ነጻ። በTelegram bot ይመዝገቡ።',
    M2n+' Pay by bank transfer, Telebirr or another way — we help you.':'ነጻው አማራጭ በሀገርዎ የማይሰራ ከሆነ ተመሳሳይ ኮርሶች እና VIP። በባንክ፣ በTelebirr ወይም በሌላ መንገድ ይክፈሉ — እኛ እንረዳዎታለን።'}
REN={'Home-ti1120c.js':'Home-ti1120d.js','Mentorship-ti1120c.js':'Mentorship-ti1120d.js'}
s=rd('assets/Home-ti1120c.js')
s,n=re.subn(r'children:\["The full ",[^\[\]]*?"-course Academy, Bootcamp & VIP — 100% FREE\. Register through our Telegram bot\."\]','children:'+q(HERO),s)
print('home hero',n); wr('assets/Home-ti1120d.js',s)
s=rd('assets/Mentorship-ti1120c.js'); n=s.count(M1o)+s.count(M2o); s=s.replace(M1o,M1n).replace(M2o,M2n); print('mentor',n); wr('assets/Mentorship-ti1120d.js',s)
for p in glob.glob('assets/*.js'):
    if p.endswith(tuple(REN.values())): continue
    s=rd(p); t=s
    for a,b in REN.items(): t=t.replace(a,b)
    if t!=s: shutil.copy2(p,B+'/'+os.path.basename(p)); wr(p,t); print('refs',p)
shutil.copy2('index.html',B+'/index.html'); s=rd('index.html')
s=s.replace('13-course NLM Academy, Bootcamp and VIP live sessions','All NLM Academy courses, Bootcamp and VIP live sessions')
s=re.sub(r'am\.js\?v=[0-9a-z]+','am.js?v=20261120f',s); wr('index.html',s)
shutil.copy2('i18n/am.js',B+'/am.js'); s=rd('i18n/am.js')
anchor=q('100% Free')+': '+q('100% ነጻ')
s=s.replace(anchor,anchor+''.join(', '+q(k)+': '+q(v) for k,v in AM.items()),1); wr('i18n/am.js',s); print('am ok', anchor in s)
for f in ['assets/Home-ti1120d.js','assets/Mentorship-ti1120d.js','assets/CourseDetail-ti1120c.js','index.html']:
    for m in re.finditer(r'(?i)(13[- ](module|course)s?|thirteen)',rd(f)): print('LEFT',f,rd(f)[max(0,m.start()-60):m.end()+40].replace('\n',' '))
