<?php

namespace App\Console\Commands;

use App\Models\Member;
use App\Services\EventRecorder;
use App\Services\Exness\ExnessApiException;
use App\Services\Exness\ExnessClientInterface;
use Illuminate\Console\Command;

/**
 * Populates members.commission_30d — the figure behind the High Volume
 * Client Report (§14.1).
 *
 * Source: GET /api/reports/rewards/ over a rolling window. Rows carry the
 * short client_uid and reward_usd, so commission is summed per client and
 * matched to members by their stored client UID.
 */
class FlowSyncCommission extends Command
{
    protected $signature = 'flow:sync-commission {--days=30 : Rolling window in days}';

    protected $description = 'Aggregate 30-day partner commission per member from the Exness rewards report';

    public function handle(ExnessClientInterface $exness, EventRecorder $events): int
    {
        \App\Services\Exness\RequestGate::label('commission');

        $days = max(1, (int) $this->option('days'));
        $from = now()->subDays($days)->format('Y-m-d');
        $to = now()->format('Y-m-d');

        $perClient = [];
        $offset = 0;
        $pageSize = 1000;
        $rowsRead = 0;

        do {
            // 2026-11-20: the shared Exness cap (8/min) is often used up by the deposit
            // queue at 06:30, so wait for the next minute and try again (max 5 tries).
            $page = null;
            for ($try = 1; $try <= 5 && $page === null; $try++) {
                try {
                    $page = $exness->rewards($from, $to, ['limit' => $pageSize, 'offset' => $offset]);
                } catch (ExnessApiException $e) {
                    if ($try < 5 && stripos($e->getMessage(), 'cap') !== false) {
                        sleep(65);
                        continue;
                    }
                    break;
                }
            }
            try {
                if ($page === null) {
                    throw $e ?? new ExnessApiException('no response');
                }
            } catch (ExnessApiException $e) {
                $this->error('Rewards report failed: '.$e->getMessage());
                $events->system('flow.commission_sync_failed', null, ['error' => $e->getMessage()]);

                return self::FAILURE;
            }

            $rows = $page['data'] ?? [];

            foreach ($rows as $row) {
                $uid = (string) ($row['client_uid'] ?? '');
                if ($uid === '') {
                    continue;
                }
                $perClient[$uid] = ($perClient[$uid] ?? 0) + (float) ($row['reward_usd'] ?? 0);
            }

            $rowsRead += count($rows);
            $offset += $pageSize;
        } while (count($rows) === $pageSize);

        // Reset first so members who earned nothing in the window drop to 0.
        Member::whereNotNull('exness_client_uid')->update(['commission_30d' => 0]);

        $matched = 0;
        foreach ($perClient as $shortUid => $commission) {
            // Stored UIDs are the full UUID; rewards rows use the 8-char form.
            $updated = Member::where('exness_client_uid', 'like', $shortUid.'%')
                ->update(['commission_30d' => round($commission, 2)]);
            $matched += $updated;
        }

        $events->system('flow.commission_synced', null, [
            'window_days' => $days, 'reward_rows' => $rowsRead,
            'clients_with_commission' => count($perClient), 'members_matched' => $matched,
        ]);

        $this->info("Rewards rows: {$rowsRead} · clients: ".count($perClient)." · members updated: {$matched}");

        return self::SUCCESS;
    }
}
