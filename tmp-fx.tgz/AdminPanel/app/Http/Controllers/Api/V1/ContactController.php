<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ContactDetailResource;
use App\Rules\Captcha;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\ContactMessage\App\Models\ContactMessage;
use Modules\Page\App\Models\ContactUs;
use App\Helper\EmailHelper;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Modules\ContactMessage\App\Emails\SendContactMessage;
use Modules\GlobalSetting\App\Models\GlobalSetting;

/**
 * Contact page: the published contact details, and the message form.
 *
 * GET  mirrors HomeController@contact_us, which is nothing but ContactUs::first().
 * POST mirrors Modules/ContactMessage Frontend\ContactMessageController@store_contact_message.
 *
 * The POST does not send mail inside the request (notifyStaff runs after the
 * response, see below). The Blade controller calls
 * EmailHelper::mail_setup() and then Mail::to(...)->send(...) inline, inside the
 * request: if SMTP is slow or misconfigured the visitor's browser hangs on the
 * submit and eventually gets a 500 — for a message that was already saved a
 * moment earlier. The row is persisted here and the response returns
 * immediately; notifying staff belongs behind a queued job, which this codebase
 * does not have a worker for yet. Nothing is lost — every submission is in
 * contact_messages, which is exactly what the admin inbox screen
 * (Modules/ContactMessage) reads.
 */
class ContactController extends Controller
{
    public function show(): ContactDetailResource
    {
        return new ContactDetailResource(ContactUs::query()->orderBy('id')->first());
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            // Same required set as ContactMessageRequest. instructor_id is 0
            // for a general enquiry; the Blade form posts it as a hidden field
            // and the API keeps that contract so a future "message this
            // instructor" form can reuse the endpoint unchanged.
            'instructor_id' => ['required', 'integer', 'min:0'],
            'name'          => ['required', 'string', 'max:255'],
            'email'         => ['required', 'email', 'max:255'],
            'phone'         => ['nullable', 'string', 'max:255'],
            'subject'       => ['required', 'string', 'max:255'],
            'message'       => ['required', 'string', 'max:5000'],

            // Non-implicit rule: skipped when the field is absent, which is the
            // case while recaptcha_status is off, and enforced the moment an
            // admin switches reCAPTCHA on — same as the Blade form.
            'g-recaptcha-response' => new Captcha(),
        ], [
            'name.required'    => trans('translate.Name is required'),
            'email.required'   => trans('translate.Email is required'),
            'subject.required' => trans('translate.Subject is required'),
            'message.required' => trans('translate.Message is required'),
        ]);

        // ContactMessage has an empty $fillable, so mass assignment is a no-op;
        // attributes are set individually, as the Blade controller does.
        $contact_message = new ContactMessage();
        $contact_message->name    = $validated['name'];
        $contact_message->email   = $validated['email'];
        $contact_message->phone   = $validated['phone'] ?? null;
        $contact_message->subject = $validated['subject'];
        $contact_message->message = $validated['message'];
        $contact_message->save();

        // Notify staff once the visitor already has the response, so slow or
        // broken SMTP can never hang the form or lose the saved message.
        dispatch(fn () => self::notifyStaff($contact_message->id))->afterResponse();

        return response()->json([
            'message' => 'Thanks — your message has been received. We usually reply within one working day.',
        ], 201);
    }

    /**
     * Email a saved message to Admin → Settings "contact message mail"
     * (support@tradeinsightnlm.com) through the SMTP in Admin → Email settings.
     * Reply-To is the visitor, so staff can answer straight from the inbox.
     */
    public static function notifyStaff(int $id): void
    {
        self::notifyTelegram($id);

        try {
            $m = ContactMessage::find($id);
            $to = GlobalSetting::where('key', 'contact_message_mail')->value('value');
            if (! $m || ! $to || ! filter_var($to, FILTER_VALIDATE_EMAIL)) {
                return;
            }

            EmailHelper::mail_setup();

            $body = 'Name: ' . e($m->name) . '<br>Email: ' . e($m->email) . '<br>Phone: ' . e($m->phone ?: '-')
                . '<br><br>' . nl2br(e($m->message));

            Mail::mailer('smtp')->to($to)->send(
                (new SendContactMessage($body, 'Website contact: ' . $m->subject, $m->email, $m->name))
                    ->replyTo($m->email, $m->name)
            );
        } catch (\Throwable $e) {
            Log::error('Contact message mail failed', ['id' => $id, 'error' => $e->getMessage()]);
        }
    }

    /**
     * 2026-11-20: also send every contact message to the owner on Telegram, so it
     * reaches him even while the SMTP login is broken. Chat = global setting
     * "contact_message_telegram", else the super admin's 2FA Telegram ID.
     */
    public static function notifyTelegram(int $id): void
    {
        try {
            $m = ContactMessage::find($id);
            $token = config('services.telegram.bot_token');
            $chat = GlobalSetting::where('key', 'contact_message_telegram')->value('value')
                ?: \Illuminate\Support\Facades\DB::table('admins')->whereNotNull('two_factor_telegram_id')->orderBy('id')->value('two_factor_telegram_id');
            if (! $m || ! $token || ! $chat) {
                return;
            }
            $text = "📩 Website contact message\n\nName: {$m->name}\nEmail: {$m->email}\nPhone: ".($m->phone ?: '-')
                ."\nSubject: {$m->subject}\n\n".mb_substr((string) $m->message, 0, 3000);
            \Illuminate\Support\Facades\Http::timeout(10)->asForm()->post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id' => $chat, 'text' => $text, 'disable_web_page_preview' => 'true',
            ]);
        } catch (\Throwable $e) {
            Log::error('Contact message Telegram notify failed', ['id' => $id, 'error' => $e->getMessage()]);
        }
    }
}
