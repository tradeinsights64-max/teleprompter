<?php

namespace App\Http\Controllers\Api\V1\Extensions;

use App\Http\Controllers\Controller;
use App\Support\CourseReviewRules;
use App\Support\StudentProgress;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Modules\Course\App\Models\Course;
use Modules\Course\App\Models\CourseReview;

/**
 * Issue 49 — course ratings & reviews.
 *
 *   GET  courses/{slug}/reviews            public: average, count, distribution, published reviews
 *   GET  student/courses/{slug}/review     the student's eligibility and own ratings per stage
 *   POST student/courses/{slug}/review     create or (where allowed) update the rating for a stage
 *
 * Ratings belong to the COURSE; instructor profiles aggregate the ratings of
 * their courses (InstructorController::reviewSubquery), which already reads
 * course_reviews with status 'enable'.
 */
class CourseReviewController extends Controller
{
    public function index(Request $request, string $slug): JsonResponse
    {
        $course = Course::where('slug', $slug)->firstOrFail();

        $summary = Cache::remember("course_reviews_summary_{$course->id}", 300, function () use ($course) {
            $rows = CourseReview::where('course_id', $course->id)->where('status', 'enable');
            $dist = (clone $rows)->select('rating', DB::raw('COUNT(*) c'))->groupBy('rating')->pluck('c', 'rating');

            return [
                'average' => round((float) (clone $rows)->avg('rating'), 2),
                'count' => (clone $rows)->count(),
                'distribution' => collect([5, 4, 3, 2, 1])->mapWithKeys(fn ($s) => [$s => (int) ($dist[$s] ?? 0)]),
            ];
        });

        $reviews = CourseReview::with('student:id,name,image')
            ->where('course_id', $course->id)->where('status', 'enable')
            ->whereNotNull('review')->where('review', '<>', '')
            ->latest('id')->paginate(min(20, max(1, (int) $request->query('per_page', 6))));

        return response()->json([
            'data' => collect($reviews->items())->map(fn ($r) => [
                'id' => $r->id,
                'rating' => (int) $r->rating,
                'review' => $r->review,
                'stage' => $r->stage,
                'stage_label' => CourseReviewRules::STAGES[$r->stage] ?? null,
                'student' => ['name' => $this->displayName($r->student?->name), 'avatar' => $r->student?->image ? tide_image($r->student->image) : null],
                'date' => $r->created_at?->toDateString(),
                'edited' => (bool) $r->edited_at,
            ])->values(),
            'summary' => $summary,
            'meta' => ['current_page' => $reviews->currentPage(), 'last_page' => $reviews->lastPage(), 'total' => $reviews->total()],
        ]);
    }

    public function mine(string $slug, StudentProgress $progress): JsonResponse
    {
        [$course, $student] = $this->context($slug);
        $pct = (int) ($progress->courseTotals($course->id, $student->id)['percentage'] ?? 0);
        $mine = CourseReview::where('course_id', $course->id)->where('student_id', $student->id)->get()->keyBy('stage');

        return response()->json(['data' => [
            'course_id' => $course->id,
            'progress' => $pct,
            'allow_edits' => CourseReviewRules::allowEdits(),
            'stages' => collect(CourseReviewRules::STAGES)->map(fn ($label, $stage) => [
                'stage' => $stage,
                'label' => $label,
                'threshold' => CourseReviewRules::threshold($stage),
                'eligible' => $pct >= CourseReviewRules::threshold($stage),
                'review' => isset($mine[$stage]) ? [
                    'rating' => (int) $mine[$stage]->rating,
                    'review' => $mine[$stage]->review,
                    'status' => $mine[$stage]->status,
                    'updated_at' => $mine[$stage]->updated_at?->toIso8601String(),
                ] : null,
                'can_submit' => $pct >= CourseReviewRules::threshold($stage) && (! isset($mine[$stage]) || CourseReviewRules::allowEdits()),
            ])->values(),
        ]]);
    }

    public function store(Request $request, string $slug, StudentProgress $progress): JsonResponse
    {
        [$course, $student] = $this->context($slug);

        $data = $request->validate([
            'stage' => ['required', Rule::in(array_keys(CourseReviewRules::STAGES))],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'review' => ['nullable', 'string', 'max:2000'],
        ]);

        $pct = (int) ($progress->courseTotals($course->id, $student->id)['percentage'] ?? 0);
        $need = CourseReviewRules::threshold($data['stage']);
        abort_if($pct < $need, 403, $data['stage'] === 'completion'
            ? 'You can rate this course once you have completed it.'
            : "You can rate this course once you reach {$need}% progress (you are at {$pct}%).");

        $review = DB::transaction(function () use ($course, $student, $data, $pct) {
            $existing = CourseReview::where(['course_id' => $course->id, 'student_id' => $student->id, 'stage' => $data['stage']])->lockForUpdate()->first();

            if ($existing && ! CourseReviewRules::allowEdits()) {
                abort(409, 'You have already rated this course at this stage.');
            }

            $row = $existing ?? new CourseReview();
            $row->course_id = $course->id;
            $row->student_id = $student->id;
            $row->instructor_id = $course->user_id;
            $row->stage = $data['stage'];
            $row->rating = $data['rating'];
            // 2026-11-20: the column is NOT NULL, so a star-only rating stores '' (was a 500 error).
            $row->review = trim((string) ($data['review'] ?? ''));
            $row->progress_at_submit = $pct;
            if ($existing) {
                $row->edited_at = now();
                // A moderator's decision stands: an edit does not un-hide a hidden review.
            } else {
                $row->status = CourseReviewRules::autoPublish() ? 'enable' : 'pending';
            }
            $row->save();

            return $row;
        });

        Cache::forget("course_reviews_summary_{$course->id}");

        return response()->json([
            'message' => $review->wasRecentlyCreated ? 'Thank you — your rating has been saved.' : 'Your rating has been updated.',
            'data' => ['rating' => (int) $review->rating, 'review' => $review->review, 'stage' => $review->stage, 'status' => $review->status],
        ], $review->wasRecentlyCreated ? 201 : 200);
    }

    /** @return array{0: Course, 1: \App\Models\User} */
    private function context(string $slug): array
    {
        $student = Auth::guard('web')->user();
        $course = Course::where('slug', $slug)->firstOrFail();
        $enrolled = in_array((int) $course->id, app(StudentProgress::class)->enrolledCourseIds((int) $student->id), true);
        abort_unless($enrolled, 403, 'Only students enrolled in this course can rate it.');

        return [$course, $student];
    }

    private function displayName(?string $name): string
    {
        $parts = preg_split('/\s+/', trim((string) $name)) ?: [];
        if (! $parts || $parts[0] === '') {
            return 'Student';
        }

        // First name + last initial: reviews are public.
        return $parts[0].(isset($parts[1]) ? ' '.mb_substr($parts[1], 0, 1).'.' : '');
    }
}
