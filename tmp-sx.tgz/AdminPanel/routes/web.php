<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\Admin\UserController;

use App\Http\Controllers\Admin\ProfileController;

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\Auth\LoginController;

use App\Http\Controllers\Admin\FrontEndManagementController;
use App\Http\Controllers\Auth\LoginController as StudentLoginController;


use App\Http\Controllers\Student\ProfileController as StudentProfileController;
use App\Http\Controllers\Instructor\ProfileController as InstructorProfileController;

use App\Http\Controllers\UserImportController;


Route::group(['middleware' => [ 'HtmlSpecialchars', 'MaintenanceMode']], function () {

    /*
     | The public site lives on the apex domain in React (Decision 5). These
     | Blade routes are the older second front door on the admin host and now
     | redirect there — see RedirectDuplicatedFrontend for why, and note the
     | middleware is inert while FRONTEND_URL is unset, so a local checkout
     | without the React app still renders them.
     |
     | The route NAMES stay: dozens of Blade views (including the admin panel's
     | own chrome) call route('home'), route('blogs') and friends.
     */
    Route::middleware('frontend')->group(function () {
        Route::get('/', [HomeController::class, 'index'])->name('home');

        Route::get('/about-us', [HomeController::class, 'about_us'])->name('about-us');

        Route::get('/blogs', [HomeController::class, 'blogs'])->name('blogs');
        Route::get('/blog/{slug}', [HomeController::class, 'blog'])->name('blog');

        Route::get('/faq', [HomeController::class, 'faq'])->name('faq');

        Route::get('/privacy-policy', [HomeController::class, 'privacy_policy'])->name('privacy-policy');
        Route::get('/terms-conditions', [HomeController::class, 'terms_conditions'])->name('terms-conditions');

        Route::get('/custom-page/{slug}', [HomeController::class, 'custom_page'])->name('custom-page');

        Route::get('/contact-us', [HomeController::class, 'contact_us'])->name('contact-us');

        /*
         * TODO — Future implementation: the Mentorship page exists in the TIDE UI but
         * the backend has no mentorship model, table or controller. It is served as a
         * static view so navigation and layout are complete; no data is fabricated.
         */
        Route::view('/mentorship', 'mentorship')->name('mentorship');
    });

    // POST — a form submission, not a page. Left alone: redirecting it would
    // silently drop the comment.
    Route::post('/store-blog-comment/{id}', [HomeController::class, 'store_blog_comment'])->name('store-blog-comment');

    Route::get('/language-switcher', [HomeController::class,  'language_switcher'])->name('language-switcher');
    Route::get('/currency-switcher', [HomeController::class, 'currency_switcher'])->name('currency-switcher');

    Route::get('/download-file/{file}', [HomeController::class, 'download_file'])->name('download-file');


    /*
     * Laravel's Auth::routes() scaffolding is intentionally not registered.
     * It published a parallel set of /login, /register and /password/* routes
     * that duplicated the custom student.* auth flow below and were never
     * reachable from any view. Authentication lives entirely in the
     * student.* group: email + password, with Laravel's password broker
     * handling resets.
     */

    Route::group(['as' => 'student.', 'prefix' => 'student'], function(){
        Route::controller(StudentLoginController::class)->group(function () {

            /*
             | The web-guard login. Since Decision 1 students authenticate by
             | emailed code on the React site, so in practice this form is now
             | the INSTRUCTOR sign-in — same guard, same controller, and it
             | refuses the password-less student rows outright.
             |
             | /staff/login is registered below as a plainly-named alias; this
             | route keeps its path and name because the Blade views link to it.
             */
            Route::get('/login', 'custom_login_page')->name('login');
            Route::post('/store-login', 'store_login')->middleware('throttle:staff-login')->name('store-login');
            Route::get('/logout', 'student_logout')->name('logout');

            Route::get('login/google', 'redirect_to_google')->name('login-google');
            Route::get('/callback/google', 'google_callback')->name('callback-google');

            Route::get('login/facebook', 'redirect_to_facebook')->name('login-facebook');
            Route::get('/callback/facebook', 'facebook_callback')->name('callback-facebook');

            Route::get('/forget-password', 'custom_forget_page')->name('forget-password');
            Route::post('/send-forget-password', 'send_custom_forget_pass')->name('send-forget-password');

            /*
             | Registration is CLOSED on the web (Decision 2, MERGE_PLAN.md
             | §E.3) — the Telegram bot is the only path to a new account.
             | The GET keeps its route name because headers and footers all
             | over the Blade views link route('student.register'); it now
             | sends the visitor to the login screen, whose unknown-email
             | branch points at the bot. The POSTs are gone entirely:
             |   store-register, exness-verify, store-exness-register.
             */
            Route::redirect('/register', '/student/login', 302)->name('register');

            Route::controller(\App\Http\Controllers\Auth\ResetPasswordController::class)->group(function () {

                Route::get('/reset-password/{token}', 'showResetForm')->name('reset-password');
                Route::post('/reset-password', 'reset')->name('store-reset-password');
            });


        });
    });

/*
 | Instructor sign-in under a name that says so. The student.* login is the
 | same web guard and the same form; students no longer have a password to
 | type into it, so "student/login" had become a misleading URL to hand to
 | staff. The React login screen points here when it recognises a staff
 | account (OtpAuthController's `use_password` branch).
 */
Route::redirect('/staff/login', '/student/login')->name('staff.login');

/*
 | Bulk user import — admin only. This route was UNAUTHENTICATED: anyone who
 | could POST an Excel file could create arbitrary accounts, which under
 | Decision 2 (and frankly under any decision) cannot stand. An administrator
 | importing a cohort remains a legitimate operation, so the route moves
 | behind the admin guard rather than disappearing.
 */
Route::post('/import-users', [UserImportController::class, 'import'])
    ->middleware('auth:admin')
    ->name('import.users');


    /*
     | The student portal is React on the apex domain (Decision 5). These Blade
     | screens redirect there for a signed-in student; the routes and their
     | names stay because the Blade chrome links to them, and because an
     | instructor reaching them should land somewhere sensible rather than 404.
     |
     | GET pages only — the PUT/POST/DELETE handlers below keep working, since
     | redirecting a form submission silently discards the submission.
     */
    Route::group(['as' => 'student.', 'prefix' => 'student'], function(){
        Route::group(['middleware' => 'auth:web'],function () {
            /*
             | The student portal is React on the apex domain (Decision 5), so
             | these Blade SCREENS redirect there. Their routes and names stay:
             | the Blade chrome links to them by name, and a student who lands
             | here should arrive at the real portal rather than a 404.
             |
             | Only GET pages are redirected. The write handlers below keep
             | serving — redirecting a form POST would discard the submission
             | and report success.
             */
            Route::middleware('frontend')->group(function () {
                Route::get('/dashboard', [StudentProfileController::class, 'dashboard'])->name('dashboard');
                Route::get('/edit-profile', [StudentProfileController::class, 'edit_profile'])->name('edit-profile');
                Route::get('/change-password', [StudentProfileController::class, 'change_password'])->name('change-password');
                Route::get('/account-delete', [StudentProfileController::class, 'account_delete'])->name('account-delete');
                Route::get('/become-an-instructor', [StudentProfileController::class, 'become_an_instructor'])->name('become-an-instructor');
            });

            Route::put('/update-profile', [StudentProfileController::class, 'update_profile'])->name('update-profile');
            Route::put('/update-password', [StudentProfileController::class, 'update_password'])->name('update-password');
            Route::post('/instructor-application', [StudentProfileController::class, 'instructor_application'])->name('instructor-application');
            Route::delete('/confirm-account-delete', [StudentProfileController::class, 'confirm_account_delete'])->name('confirm-account-delete');

            Route::get('/chart-data', [StudentProfileController::class, 'getChartData'])->name('chart-data');

            /*
             * TODO — Future implementation: the TIDE UI has a Homework screen but
             * the backend has no assignment/homework model, table or controller.
             * Served as a static placeholder so the sidebar is complete; no data
             * is invented.
             */
            Route::view('/homework', 'student.homework')->name('homework');
            
            // Payment Routes
            Route::get('payment/{course_id}', [\App\Http\Controllers\Student\PaymentController::class, 'show'])->name('payment.show');
            Route::post('payment/{course_id}', [\App\Http\Controllers\Student\PaymentController::class, 'store'])->name('payment.store');

        });
    });


    Route::group(['as' => 'instructor.', 'prefix' => 'instructor'], function(){

        Route::group(['middleware' => ['auth:web', 'CheckInstructor']],function () {

            Route::get('/dashboard', [InstructorProfileController::class, 'dashboard'])->name('dashboard');

            // TODO — Future implementation. The TIDE Homework Review screen has no
            // backend (no assignment model); renders a static placeholder page.
            Route::view('/homework-review', 'instructor.homework_review')->name('homework-review');

            Route::get('/edit-profile', [InstructorProfileController::class, 'edit_profile'])->name('edit-profile');
            Route::put('/update-profile', [InstructorProfileController::class, 'update_profile'])->name('update-profile');

            Route::get('/instructor-profile', [InstructorProfileController::class, 'instructor_profile'])->name('instructor-profile');
            Route::put('/update-instructor-profile', [InstructorProfileController::class, 'update_instructor_profile'])->name('update-instructor-profile');

            Route::get('/change-password', [InstructorProfileController::class, 'change_password'])->name('change-password');
            Route::put('/update-password', [InstructorProfileController::class, 'update_password'])->name('update-password');

            Route::get('/account-delete', [InstructorProfileController::class, 'account_delete'])->name('account-delete');
            Route::delete('/confirm-account-delete', [InstructorProfileController::class, 'confirm_account_delete'])->name('confirm-account-delete');

        });


    });

    /*
     * The public instructor profile route `/instructor/{username}` is NOT declared
     * here. It is a catch-all that shadows every `instructor/*` portal route —
     * including module-contributed ones — so it is registered last, from
     * RouteServiceProvider::registerPublicInstructorProfile().
     */

});



Route::group(['as'=> 'admin.', 'prefix' => 'admin'],function (){

    Route::get('login', [LoginController::class, 'custom_login_page'])->name('login');
    Route::post('store-login', [LoginController::class, 'store_login'])->middleware('throttle:staff-login')->name('store-login');
    Route::post('store-register', [LoginController::class, 'store_register'])->name('store-register');
    Route::post('logout', [LoginController::class, 'admin_logout'])->name('logout');


    Route::group(['middleware' => ['auth:admin']], function () {

        Route::get('/', [DashboardController::class, 'dashboard']);
        Route::get('dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');

        // Analytics — daily visitors, user actions, the conversion funnel and
        // background-workflow health, aggregated read-only.
        Route::get('analytics', [\App\Http\Controllers\Admin\AnalyticsController::class, 'index'])->name('analytics');

        /*
         | Homework Oversight — a real module as of 2026-09-27 (it was a
         | static placeholder before). Route NAMES keep the spellings the
         | sidebar has always used.
         */
        Route::get('homework', [\App\Http\Controllers\Admin\HomeworkController::class, 'index'])->name('homework');
        Route::get('homework/create', [\App\Http\Controllers\Admin\HomeworkController::class, 'create'])->name('homework.create');
        Route::post('homework', [\App\Http\Controllers\Admin\HomeworkController::class, 'store'])->name('homework.store');
        Route::get('homework/{homework}/edit', [\App\Http\Controllers\Admin\HomeworkController::class, 'edit'])->name('homework.edit');
        Route::put('homework/{homework}', [\App\Http\Controllers\Admin\HomeworkController::class, 'update'])->name('homework.update');
        Route::delete('homework/{homework}', [\App\Http\Controllers\Admin\HomeworkController::class, 'destroy'])->name('homework.destroy');
        Route::get('homework/{homework}/submissions', [\App\Http\Controllers\Admin\HomeworkController::class, 'submissions'])->name('homework.submissions');
        Route::post('homework-submissions/{submission}/review', [\App\Http\Controllers\Admin\HomeworkController::class, 'review'])->name('homework.review');

        // Platform announcements — published to the site and, when asked, to
        // every Telegram member through the bot's own broadcast pipeline.
        Route::get('announcements', [\App\Http\Controllers\Admin\AnnouncementController::class, 'index'])->name('announcements');
        Route::get('announcements/create', [\App\Http\Controllers\Admin\AnnouncementController::class, 'create'])->name('announcements.create');
        Route::post('announcements', [\App\Http\Controllers\Admin\AnnouncementController::class, 'store'])->name('announcements.store');
        Route::get('announcements/{announcement}/edit', [\App\Http\Controllers\Admin\AnnouncementController::class, 'edit'])->name('announcements.edit');
        Route::put('announcements/{announcement}', [\App\Http\Controllers\Admin\AnnouncementController::class, 'update'])->name('announcements.update');
        Route::delete('announcements/{announcement}', [\App\Http\Controllers\Admin\AnnouncementController::class, 'destroy'])->name('announcements.destroy');

        // Bonus lessons — the shelf outside the 26-module curriculum.
        Route::get('bonus-lessons', [\App\Http\Controllers\Admin\BonusLessonController::class, 'index'])->name('bonus-lessons');
        Route::get('bonus-lessons/create', [\App\Http\Controllers\Admin\BonusLessonController::class, 'create'])->name('bonus-lessons.create');
        Route::post('bonus-lessons', [\App\Http\Controllers\Admin\BonusLessonController::class, 'store'])->name('bonus-lessons.store');
        Route::get('bonus-lessons/{bonusLesson}/edit', [\App\Http\Controllers\Admin\BonusLessonController::class, 'edit'])->name('bonus-lessons.edit');
        Route::put('bonus-lessons/{bonusLesson}', [\App\Http\Controllers\Admin\BonusLessonController::class, 'update'])->name('bonus-lessons.update');
        Route::delete('bonus-lessons/{bonusLesson}', [\App\Http\Controllers\Admin\BonusLessonController::class, 'destroy'])->name('bonus-lessons.destroy');

        // Live sessions — the meetings the student portal and the mobile app
        // both display; a session with no course is platform-wide.
        Route::get('live-sessions', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'index'])->name('live-sessions');
        Route::get('live-sessions/create', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'create'])->name('live-sessions.create');
        Route::post('live-sessions', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'store'])->name('live-sessions.store');
        Route::get('live-sessions/{meeting}/edit', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'edit'])->name('live-sessions.edit');
        Route::put('live-sessions/{meeting}', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'update'])->name('live-sessions.update');
        Route::delete('live-sessions/{meeting}', [\App\Http\Controllers\Admin\SessionScheduleController::class, 'destroy'])->name('live-sessions.destroy');

        // Issue 45 (2026-10-10): the real audit log (was a placeholder view).
        Route::get('audit-logs', [\App\Http\Controllers\Admin\Extensions\AuditLogController::class, 'index'])->name('audit-logs');
        Route::get('audit-logs/export', [\App\Http\Controllers\Admin\Extensions\AuditLogController::class, 'export'])->name('audit-logs.export');
        Route::get('audit-logs/{log}', [\App\Http\Controllers\Admin\Extensions\AuditLogController::class, 'show'])->whereNumber('log')->name('audit-logs.show');

        Route::resource('payment', \App\Http\Controllers\Admin\PaymentController::class);

        Route::controller(ProfileController::class)->group(function(){
            Route::get('edit-profile', 'edit_profile')->name('edit-profile');
            Route::put('profile-update', 'profile_update')->name('profile-update');
            Route::put('update-password', 'update_password')->name('update-password');
        });

        Route::controller(UserController::class)->group(function () {
            Route::get('user-list', 'user_list')->name('user-list');
            Route::get('pending-user', 'pending_user')->name('pending-user');
            Route::get('user-show/{id}', 'user_show')->name('user-show');
                 Route::get('user-reset/{id}', 'user_reset')->name('user-reset');
            Route::get('user-addcourse', 'user_password')->name('user-addcourse');
            Route::delete('user-delete/{id}', 'user_destroy')->name('user-delete');
            Route::put('user-status/{id}', 'user_status')->name('user-status');
            Route::put('user-update/{id}', 'update')->name('user-update');

            Route::get('seller-list', 'seller_list')->name('seller-list');
            Route::get('pending-seller', 'pending_seller')->name('pending-seller');
            Route::get('seller-show/{id}', 'seller_show')->name('seller-show');
            Route::get('seller-create', 'seller_create')->name('seller-create');
            Route::post('seller-store', 'seller_store')->name('seller-store');

            Route::get('seller-joining-request', 'seller_joining_request')->name('seller-joining-request');
            Route::get('seller-joining-detail/{id}', 'seller_joining_detail')->name('seller-joining-detail');
            Route::put('seller-joining-approval/{id}', 'seller_joining_approval')->name('seller-joining-approval');
            Route::put('seller-joining-reject/{id}', 'seller_joining_reject')->name('seller-joining-reject');

        });
        

         // Frontend Management
         Route::controller(FrontEndManagementController::class)->name('front-end.')->group(function () {
            Route::get('/frontend-section', 'index')->name('frontend-section');
            Route::get('/section/{id}', 'section')->name('section');
            Route::put('store/{key}/{id?}', 'store')->name('store');
        });

        /*
         | Challenges — the admin operations console (Phase 5). Monitoring plus
         | the lifecycle/registration/rule actions. Every mutating action is
         | audited with the admin as actor inside ChallengeOps; ranking is never
         | edited by hand here — the engine re-ranks after an eligibility change.
         */
        Route::controller(\App\Http\Controllers\Admin\ChallengeAdminController::class)
            ->prefix('challenges')->name('challenges.')->group(function () {
                Route::get('/', 'index')->name('index');

                /*
                 | The builder (merge task 5.5). Literal segments sit ABOVE the
                 | {challenge} wildcard — 'create' would otherwise be read as a
                 | challenge id and 404 on a missing model.
                 */
                Route::get('create', 'create')->name('create');
                Route::post('/', 'store')->name('store');
                Route::get('{challenge}/edit', 'edit')->whereNumber('challenge')->name('edit');
                Route::put('{challenge}', 'update')->whereNumber('challenge')->name('update');

                Route::get('/{challenge}', 'show')->whereNumber('challenge')->name('show');

                Route::post('registrations/{registration}/approve', 'approveRegistration')->whereNumber('registration')->name('registrations.approve');
                Route::post('registrations/{registration}/reject', 'rejectRegistration')->whereNumber('registration')->name('registrations.reject');
                Route::post('registrations/{registration}/verify-override', 'overrideVerification')->whereNumber('registration')->name('registrations.verify-override');

                Route::post('rule-cases/{evaluation}/resolve', 'resolveRuleCase')->whereNumber('evaluation')->name('rule-cases.resolve');

                Route::post('{challenge}/freeze', 'freeze')->whereNumber('challenge')->name('freeze');
                Route::post('{challenge}/unfreeze', 'unfreeze')->whereNumber('challenge')->name('unfreeze');
                Route::post('{challenge}/recompute', 'recompute')->whereNumber('challenge')->name('recompute');
                Route::post('{challenge}/finalize', 'finalize')->whereNumber('challenge')->name('finalize');
            });


    });


});


// Issues 32–52 (2026-10-10): admin modules for the feature batch.
require __DIR__.'/admin_extensions.php';

// Issues 67/68 (2026-10-28): homework / bonus lesson attachments, served only
// through short-lived signed links handed out after an access check.
Route::get('files/attachments/{attachment}', [\App\Http\Controllers\ContentAttachmentController::class, 'download'])
    ->middleware(['signed:relative', 'throttle:120,1'])->name('content-attachments.download');
