<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * Typically, users are redirected here after authentication.
     *
     * `home` is the NAME of the `/` route (HomeController@index) — there is no
     * `/home` path in the route table, so the Laravel default of '/home' would
     * 404 anything that followed it.
     *
     * @var string
     */
    public const HOME = '/';

    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     */
    public function boot(): void
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::middleware('api')
                ->prefix('api')
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });

        $this->registerPublicInstructorProfile();
    }

    /**
     * The public instructor profile lives at `/instructor/{username}`, which is a
     * catch-all that shadows every `instructor/*` portal route — including the
     * ones contributed by modules, whose providers boot after this one.
     *
     * Registering it from the `booted` callback puts it last in the route table,
     * so it only ever matches what no portal route claimed.
     */
    protected function registerPublicInstructorProfile(): void
    {
        $this->app->booted(function () {
            Route::middleware(['web', 'HtmlSpecialchars', 'MaintenanceMode'])
                ->get('/instructor/{username}', [\App\Http\Controllers\HomeController::class, 'instructor'])
                ->name('instructor');
        });
    }

    /**
     * Configure the rate limiters for the application.
     */
    protected function configureRateLimiting(): void
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        /*
         * OTP limits (MERGE_PLAN.md §E.1). Named limiters, not bare
         * `throttle:N,1`: the unnamed form keys on IP alone and shares one
         * counter across every route that uses it, so a student requesting a
         * code would eat the budget for verifying it.
         *
         * Keyed on identifier+IP so an attacker cannot lock a victim out from
         * a different address, and cannot rotate addresses freely from one.
         * These two limits are part of the 4-digit entropy budget — see
         * config/auth.php — and are not to be raised casually.
         */
        RateLimiter::for('otp-request', function (Request $request) {
            $email = strtolower(trim((string) $request->input('email')));

            return [
                Limit::perMinute(3)->by('otp-req:' . sha1($email . '|' . $request->ip())),
                Limit::perHour(10)->by('otp-req-ip:' . $request->ip()),
            ];
        });

        // 2026-11-20 security: password logins (admin + instructor forms) —
        // 5 tries a minute per IP, 20 an hour per IP, 10 an hour per email.
        RateLimiter::for('staff-login', function (Request $request) {
            $email = strtolower(trim((string) $request->input('email')));

            return [
                Limit::perMinute(5)->by('staff-login-ip:' . $request->ip()),
                Limit::perHour(20)->by('staff-login-iph:' . $request->ip()),
                Limit::perHour(10)->by('staff-login-email:' . sha1($email)),
            ];
        });

        RateLimiter::for('otp-verify', function (Request $request) {
            $email = strtolower(trim((string) $request->input('email')));

            return Limit::perMinute(10)->by('otp-ver:' . sha1($email . '|' . $request->ip()));
        });
    }
}
