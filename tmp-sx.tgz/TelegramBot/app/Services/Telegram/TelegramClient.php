<?php

namespace App\Services\Telegram;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Thin wrapper over the Telegram Bot API.
 * No member-facing text originates here — callers pass rendered template
 * output only (brief rule 5).
 */
class TelegramClient
{
    /** API methods logged to the telegram_activities feed. */
    private const LOGGED_METHODS = [
        'sendMessage', 'sendPhoto', 'editMessageText', 'deleteMessage',
        'createChatInviteLink', 'revokeChatInviteLink',
        'banChatMember', 'unbanChatMember', 'approveChatJoinRequest', 'declineChatJoinRequest',
        'setWebhook', 'deleteWebhook',
    ];

    private ?ActivityRecorder $recorder = null;

    public function __construct(
        private readonly string $botToken,
        private readonly int $timeout = 30,
    ) {}

    public function setActivityRecorder(?ActivityRecorder $recorder): void
    {
        $this->recorder = $recorder;
    }

    public function getMe(): array
    {
        return $this->call('getMe');
    }

    public function getWebhookInfo(): array
    {
        return $this->call('getWebhookInfo');
    }

    public function getChat(int|string $chatId): array
    {
        return $this->call('getChat', ['chat_id' => $chatId]);
    }

    public function getChatMember(int|string $chatId, int $userId): array
    {
        return $this->call('getChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function getChatMemberCount(int|string $chatId): int
    {
        $result = $this->call('getChatMemberCount', ['chat_id' => $chatId]);

        return is_numeric($result) ? (int) $result : (int) ($result['count'] ?? 0);
    }

    public function editMessageText(int|string $chatId, int $messageId, string $text): array
    {
        $result = $this->call('editMessageText', ['chat_id' => $chatId, 'message_id' => $messageId, 'text' => $text]);

        return is_array($result) ? $result : ['edited' => (bool) $result];
    }

    public function deleteMessage(int|string $chatId, int $messageId): void
    {
        $this->call('deleteMessage', ['chat_id' => $chatId, 'message_id' => $messageId]);
    }

    /**
     * @param  array|null  $inlineKeyboard  rows of [{text, url|callback_data}]
     */
    /** Issue 59: a "typing…" chat action — the cheapest way to learn whether a user has blocked the bot. */
    public function sendChatAction(int|string $chatId, string $action = 'typing'): void
    {
        $this->call('sendChatAction', ['chat_id' => $chatId, 'action' => $action]);
    }

    public function sendMessage(int|string $chatId, string $text, ?array $inlineKeyboard = null, bool $disablePreview = false): array
    {
        $params = [
            'chat_id' => $chatId,
            'text' => $text,
            'link_preview_options' => json_encode(['is_disabled' => $disablePreview]),
        ];

        if ($inlineKeyboard !== null) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }

        return $this->call('sendMessage', $params);
    }

    /**
     * Send with any reply_markup — used for reply keyboards, e.g. Telegram's
     * native "Share Contact" button ({request_contact: true}) and
     * {remove_keyboard: true} to take it away again.
     */
    public function sendMessageWithMarkup(int|string $chatId, string $text, array $replyMarkup): array
    {
        return $this->call('sendMessage', [
            'chat_id' => $chatId,
            'text' => $text,
            'reply_markup' => json_encode($replyMarkup),
            'link_preview_options' => json_encode(['is_disabled' => true]),
        ]);
    }

    /**
     * Replace the inline keyboard under an already-sent message. Works for
     * text and photo messages alike, which is why the social step uses it
     * to flip a "Not checked" button to "Checked" in place.
     *
     * @param  array|null  $inlineKeyboard  rows of [{text, url|callback_data}]; null removes the keyboard
     */
    public function editMessageReplyMarkup(int|string $chatId, int $messageId, ?array $inlineKeyboard): void
    {
        $this->call('editMessageReplyMarkup', [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'reply_markup' => json_encode(['inline_keyboard' => $inlineKeyboard ?? []]),
        ]);
    }

    /**
     * @param  string|null  $text  short toast shown to the tapping user (max 200 chars)
     */
    public function answerCallbackQuery(string $callbackQueryId, ?string $text = null): void
    {
        $params = ['callback_query_id' => $callbackQueryId];

        if ($text !== null && $text !== '') {
            $params['text'] = mb_substr($text, 0, 200);
        }

        $this->call('answerCallbackQuery', $params);
    }

    /**
     * Send an image with a caption — used for the branded opening screen.
     * $photo may be a public URL or a Telegram file_id.
     */
    public function sendPhoto(int|string $chatId, string $photo, string $caption = '', ?array $inlineKeyboard = null): array
    {
        $params = [
            'chat_id' => $chatId,
            'photo' => $photo,
            'caption' => mb_substr($caption, 0, 1024), // Telegram caption limit
        ];

        if ($inlineKeyboard !== null) {
            $params['reply_markup'] = json_encode(['inline_keyboard' => $inlineKeyboard]);
        }

        return $this->call('sendPhoto', $params);
    }

    /**
     * Single-use expiring invite link (brief §10 step 5).
     */
    public function createChatInviteLink(int|string $chatId, ?int $memberLimit, ?int $expireTimestamp, bool $createsJoinRequest = false): array
    {
        $params = ['chat_id' => $chatId];

        // 2026-11-20 security: a join-request link lets the bot check every
        // person before they enter (Telegram forbids it with member_limit).
        if ($createsJoinRequest && $memberLimit === null) {
            $params['creates_join_request'] = true;
        }

        if ($memberLimit !== null) {
            $params['member_limit'] = $memberLimit;
        }
        if ($expireTimestamp !== null) {
            $params['expire_date'] = $expireTimestamp;
        }

        return $this->call('createChatInviteLink', $params);
    }

    public function approveChatJoinRequest(int|string $chatId, int|string $userId): array
    {
        return $this->call('approveChatJoinRequest', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function declineChatJoinRequest(int|string $chatId, int|string $userId): array
    {
        return $this->call('declineChatJoinRequest', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function revokeChatInviteLink(int|string $chatId, string $inviteLink): array
    {
        return $this->call('revokeChatInviteLink', ['chat_id' => $chatId, 'invite_link' => $inviteLink]);
    }

    /**
     * Removal per brief §11 rule 1: ban then immediately unban so the
     * person can be re-invited later.
     */
    public function kickAndUnban(int|string $chatId, int $userId): void
    {
        $this->call('banChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
        $this->call('unbanChatMember', ['chat_id' => $chatId, 'user_id' => $userId, 'only_if_banned' => true]);
    }

    public function banChatMember(int|string $chatId, int $userId): array
    {
        return $this->call('banChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function getUpdates(int $offset, int $timeout, array $allowedUpdates): array
    {
        return $this->call('getUpdates', [
            'offset' => $offset,
            'timeout' => $timeout,
            'allowed_updates' => json_encode($allowedUpdates),
        ], $timeout + 10);
    }

    public function setWebhook(string $url, string $secretToken, array $allowedUpdates): void
    {
        $this->call('setWebhook', [
            'url' => $url,
            'secret_token' => $secretToken,
            'allowed_updates' => json_encode($allowedUpdates),
        ]);
    }

    public function deleteWebhook(): void
    {
        $this->call('deleteWebhook');
    }

    // ------------------------------------------------------------------

    private function call(string $method, array $params = [], ?int $timeoutOverride = null): mixed
    {
        $chatId = $params['chat_id'] ?? null;
        $content = isset($params['text']) ? (string) $params['text'] : null;

        try {
            $response = Http::timeout($timeoutOverride ?? $this->timeout)
                ->asForm()
                ->post(config('telegram.api_base', 'https://api.telegram.org')."/bot{$this->botToken}/{$method}", $params);
        } catch (ConnectionException $e) {
            Log::warning('telegram.connection_error', ['method' => $method, 'error' => $e->getMessage()]);
            $this->record($method, $chatId, $content, 'failed', $e->getMessage(), null);
            throw new TelegramApiException("Telegram connection failed for {$method}: {$e->getMessage()}");
        }

        $json = $response->json();

        if (! is_array($json) || ($json['ok'] ?? false) !== true) {
            $code = is_array($json) ? ($json['error_code'] ?? $response->status()) : $response->status();
            $description = is_array($json) ? ($json['description'] ?? 'unknown') : 'non-JSON response';

            Log::warning('telegram.api_error', [
                'method' => $method,
                'error_code' => $code,
                'description' => $description,
            ]);

            $this->record($method, $chatId, $content, 'failed', "[{$code}] {$description}", null);

            throw new TelegramApiException(
                "Telegram {$method} failed: {$description}",
                is_int($code) ? $code : null,
                is_string($description) ? $description : null,
            );
        }

        $result = $json['result'] ?? [];

        $this->record($method, $chatId, $content, 'success', null, is_array($result) ? $result : ['result' => $result]);

        return $result;
    }

    private function record(string $method, mixed $chatId, ?string $content, string $status, ?string $error, ?array $response): void
    {
        if ($this->recorder === null || ! in_array($method, self::LOGGED_METHODS, true)) {
            return;
        }

        $this->recorder->outbound('api.'.$method, $chatId, $content, $status, $error, $response);
    }
}
