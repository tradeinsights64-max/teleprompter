<?php

namespace App\Services;

use App\Services\Membership\GroupConfiguration;
use App\Services\Telegram\TelegramApiException;
use App\Services\Telegram\TelegramClient;

/**
 * The shared, non-expiring join link for each community group.
 *
 * ONE LINK PER GROUP, NOT ONE PER MEMBER. The per-member single-use links that
 * InviteService issues are right for the verification flow, where the link is
 * a grant to a named person and the join can be attributed. They are wrong for
 * messaging the whole member base: that would be two extra Telegram API calls
 * per recipient, which on a few thousand members is thousands of calls against
 * a rate-limited API, and a partial failure leaves some people with no link at
 * all.
 *
 * So the group link is created once, stored, and reused for everyone. It has
 * no member limit and no expiry date, so it keeps working indefinitely — the
 * brief's "generated correctly and do not expire".
 *
 * Stored in settings rather than cache because a cache flush must not silently
 * mint a second link: every link Telegram issues stays live until revoked, and
 * a group slowly accumulating orphan links is a thing nobody can clean up from
 * the admin panel.
 */
class GroupInviteLinks
{
    /** Services that have a join button, in the order they are shown. */
    public const SERVICES = ['bootcamp', 'free_vip'];

    public function __construct(
        private readonly Settings $settings,
        private readonly TelegramClient $telegram,
        private readonly GroupConfiguration $groups,
        private readonly EventRecorder $events,
    ) {}

    private function settingKey(string $service): string
    {
        return "invite.shared_link.{$service}";
    }

    /**
     * The stored link for a service, without contacting Telegram.
     */
    public function stored(string $service): ?string
    {
        $value = $this->settings->string($this->settingKey($service));

        return $value !== '' ? $value : null;
    }

    /**
     * The shared join link for a service, creating it on first use.
     *
     * @param  bool  $refresh  mint a new link even if one is stored
     * @return string|null null when the group is not configured or Telegram refused
     */
    public function for(string $service, bool $refresh = false): ?string
    {
        if (! $refresh && ($existing = $this->stored($service)) !== null) {
            return $existing;
        }

        $chatId = $this->groups->chatIdFor($service);

        if (empty($chatId)) {
            $this->events->system('invite.shared_link_failed', null, [
                'service' => $service,
                'reason' => 'no Telegram group configured for this service',
            ]);

            return null;
        }

        try {
            // No member limit, no expiry — but since 2026-11-20 it is a
            // join-REQUEST link: a forwarded link no longer lets strangers in;
            // UpdateDispatcher::handleJoinRequest approves only members who
            // qualify for this group and declines everyone else.
            $link = $this->telegram->createChatInviteLink($chatId, null, null, true);
        } catch (TelegramApiException $e) {
            $this->events->system('invite.shared_link_failed', null, [
                'service' => $service,
                'chat_id' => $chatId,
                'reason' => $e->getMessage(),
            ]);

            return null;
        }

        $url = $link['invite_link'] ?? null;

        if (! is_string($url) || $url === '') {
            return null;
        }

        // setOrCreate, not set(): this key is written by the application, so
        // there is no seeded row to update the first time a link is minted.
        $this->settings->setOrCreate(
            $this->settingKey($service),
            $url,
            'string',
            'invites',
            ucfirst(str_replace('_', ' ', $service)).' shared invite link',
            'Created automatically. Never expires and is reused for everyone. Clear it from Admin → Group Invites to mint a new one.',
        );

        $this->events->system('invite.shared_link_created', null, [
            'service' => $service,
            'chat_id' => $chatId,
            'invite_link' => $url,
            'refresh' => $refresh,
        ]);

        return $url;
    }

    /**
     * Every configured service's link, keyed by service.
     *
     * @return array<string, string> only services that actually resolved
     */
    public function all(bool $refresh = false): array
    {
        $links = [];

        foreach (self::SERVICES as $service) {
            $url = $this->for($service, $refresh);

            if ($url !== null) {
                $links[$service] = $url;
            }
        }

        return $links;
    }

    /**
     * Forget the stored links so the next send mints fresh ones.
     *
     * Does NOT revoke them at Telegram: anyone who already has the old link
     * keeps working, which is the safe default for a reset that might be a
     * mistake. Use revoke() when the intent is to cut off the old link.
     */
    public function reset(): void
    {
        foreach (self::SERVICES as $service) {
            $this->settings->setOrCreate($this->settingKey($service), '', 'string', 'invites');
        }

        $this->events->system('invite.shared_links_reset', null, [
            'services' => self::SERVICES,
            'revoked' => false,
        ]);
    }

    /**
     * Revoke the stored links at Telegram, then forget them.
     *
     * Irreversible: everyone holding the old link loses it.
     */
    public function revoke(): void
    {
        foreach (self::SERVICES as $service) {
            $url = $this->stored($service);
            $chatId = $this->groups->chatIdFor($service);

            if ($url === null || empty($chatId)) {
                continue;
            }

            try {
                $this->telegram->revokeChatInviteLink($chatId, $url);
            } catch (TelegramApiException $e) {
                $this->events->system('invite.shared_link_revoke_failed', null, [
                    'service' => $service,
                    'reason' => $e->getMessage(),
                ]);
            }
        }

        $this->reset();

        $this->events->system('invite.shared_links_reset', null, [
            'services' => self::SERVICES,
            'revoked' => true,
        ]);
    }

    /**
     * Do the two groups actually differ? Both services fall back to the
     * bootcamp chat when free_vip has no group of its own, which would put
     * both buttons on the same chat — worth being able to check before a send.
     */
    public function groupsAreDistinct(): bool
    {
        $bootcamp = $this->groups->chatIdFor('bootcamp');
        $vip = $this->groups->chatIdFor('free_vip');

        return filled($bootcamp) && filled($vip) && $bootcamp !== $vip;
    }

    /**
     * @return array<string, string|null> service => chat id, for diagnostics
     */
    public function chatIds(): array
    {
        $ids = [];

        foreach (self::SERVICES as $service) {
            $ids[$service] = $this->groups->chatIdFor($service);
        }

        return $ids;
    }
}
