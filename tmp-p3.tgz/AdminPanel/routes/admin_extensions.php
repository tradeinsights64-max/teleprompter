<?php

/*
| Admin routes for the 2026-10-10 feature batch (issues 32–52).
|
| Loaded from routes/web.php, so the `web` group — and with it AdminAccess,
| which enforces each route's permission and writes the audit trail — wraps
| every route here. Permission = module (route-name pattern in
| App\Support\AdminPermissions) + action (last name segment / verb).
*/

use App\Http\Controllers\Admin\Extensions as X;
use Illuminate\Support\Facades\Route;

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {

    // Issue 32 — Featured & Media
    Route::get('media', [X\MediaFeatureController::class, 'index'])->name('media.index');
    Route::get('media/create', [X\MediaFeatureController::class, 'create'])->name('media.create');
    Route::post('media', [X\MediaFeatureController::class, 'store'])->name('media.store');
    Route::get('media/{medium}/edit', [X\MediaFeatureController::class, 'edit'])->name('media.edit');
    Route::put('media/{medium}', [X\MediaFeatureController::class, 'update'])->name('media.update');
    Route::post('media/{medium}/publish', [X\MediaFeatureController::class, 'publish'])->name('media.publish');
    Route::post('media/{medium}/unpublish', [X\MediaFeatureController::class, 'unpublish'])->name('media.unpublish');
    Route::delete('media/{medium}', [X\MediaFeatureController::class, 'destroy'])->name('media.destroy');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issue 40 — Mentorship bookings (Calendly + Zoom + Telegram)
    Route::get('mentorship-bookings', [X\MentorshipBookingController::class, 'index'])->name('mentorship.index');
    Route::get('mentorship-bookings/settings', [X\MentorshipBookingController::class, 'settings'])->name('mentorship.settings');
    Route::put('mentorship-bookings/settings', [X\MentorshipBookingController::class, 'updateSettings'])->name('mentorship.settings.update');
    Route::post('mentorship-bookings/register-webhook', [X\MentorshipBookingController::class, 'registerWebhook'])->name('mentorship.webhook.register-approve');
    Route::post('mentorship-bookings/reconcile', [X\MentorshipBookingController::class, 'reconcile'])->name('mentorship.resync-all');
    Route::post('mentorship-bookings/overrides', [X\MentorshipBookingController::class, 'storeOverride'])->name('mentorship.overrides.store');
    Route::delete('mentorship-bookings/overrides/{override}', [X\MentorshipBookingController::class, 'destroyOverride'])->name('mentorship.overrides.destroy');
    Route::post('mentorship-bookings/webhook-events/{event}/retry', [X\MentorshipBookingController::class, 'retryWebhook'])->name('mentorship.webhook-events.retry');
    Route::post('mentorship-bookings/notifications/{notification}/retry', [X\MentorshipBookingController::class, 'retryNotification'])->name('mentorship.notifications.retry');
    Route::get('mentorship-bookings/{booking}', [X\MentorshipBookingController::class, 'show'])->whereNumber('booking')->name('mentorship.show');
    Route::post('mentorship-bookings/{booking}/retry-zoom', [X\MentorshipBookingController::class, 'retryZoom'])->name('mentorship.zoom.retry');
    Route::post('mentorship-bookings/{booking}/resync', [X\MentorshipBookingController::class, 'resync'])->name('mentorship.resync');
    Route::post('mentorship-bookings/{booking}/cancel', [X\MentorshipBookingController::class, 'cancel'])->name('mentorship.cancel-approve');
    Route::post('mentorship-bookings/{booking}/mark', [X\MentorshipBookingController::class, 'markStatus'])->name('mentorship.mark-status');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issues 49 + 51 — Ratings & reviews moderation
    Route::get('reviews', [X\CourseReviewController::class, 'index'])->name('reviews.index');
    Route::put('reviews/settings', [X\CourseReviewController::class, 'updateSettings'])->name('reviews.settings.update');
    Route::post('reviews/{review}/moderate', [X\CourseReviewController::class, 'moderate'])->name('reviews.moderate');
    Route::delete('reviews/{review}', [X\CourseReviewController::class, 'destroy'])->name('reviews.destroy');
    // Certificate feedback (2026-11-13) — under reviews.* so the Ratings & reviews permission applies.
    Route::get('student-reviews', [X\StudentReviewController::class, 'index'])->name('reviews.student.index');
    Route::post('student-reviews/{review}/approve', [X\StudentReviewController::class, 'approve'])->whereNumber('review')->name('reviews.student.approve');
    Route::post('student-reviews/{review}/hide', [X\StudentReviewController::class, 'hide'])->whereNumber('review')->name('reviews.student.hide');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issue 51 — Roles & permissions; admin accounts
    Route::get('roles', [X\RoleController::class, 'index'])->name('roles.index');
    Route::get('roles/create', [X\RoleController::class, 'create'])->name('roles.create');
    Route::post('roles', [X\RoleController::class, 'store'])->name('roles.store');
    Route::get('roles/{role}/edit', [X\RoleController::class, 'edit'])->name('roles.edit');
    Route::put('roles/{role}', [X\RoleController::class, 'update'])->name('roles.update');
    Route::delete('roles/{role}', [X\RoleController::class, 'destroy'])->name('roles.destroy');
    Route::get('admins', [X\RoleController::class, 'admins'])->name('admins.index');
    Route::post('admins', [X\RoleController::class, 'storeAdmin'])->name('admins.store');
    Route::put('admins/{admin}', [X\RoleController::class, 'updateAdmin'])->name('admins.update');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issue 51 (P1) — Question bank
    Route::get('question-bank', [X\QuestionBankController::class, 'index'])->name('question-bank.index');
    Route::get('question-bank/create', [X\QuestionBankController::class, 'create'])->name('question-bank.create');
    Route::post('question-bank', [X\QuestionBankController::class, 'store'])->name('question-bank.store');
    Route::post('question-bank/attach', [X\QuestionBankController::class, 'attach'])->name('question-bank.attach-approve');
    Route::post('question-bank/import', [X\QuestionBankController::class, 'import'])->name('question-bank.store-import');
    Route::get('question-bank/{item}/edit', [X\QuestionBankController::class, 'edit'])->name('question-bank.edit');
    Route::put('question-bank/{item}', [X\QuestionBankController::class, 'update'])->name('question-bank.update');
    Route::post('question-bank/{item}/status', [X\QuestionBankController::class, 'setStatus'])->name('question-bank.status-approve');
    Route::delete('question-bank/{item}', [X\QuestionBankController::class, 'destroy'])->name('question-bank.destroy');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issue 51 (P1) — Notification management
    Route::get('notifications', [X\NotificationController::class, 'index'])->name('notifications.index');
    Route::get('notifications/create', [X\NotificationController::class, 'create'])->name('notifications.create');
    Route::post('notifications', [X\NotificationController::class, 'store'])->name('notifications.store');
    Route::get('notifications/{notification}', [X\NotificationController::class, 'show'])->whereNumber('notification')->name('notifications.show');
    Route::get('notifications/{notification}/edit', [X\NotificationController::class, 'edit'])->name('notifications.edit');
    Route::put('notifications/{notification}', [X\NotificationController::class, 'update'])->name('notifications.update');
    Route::post('notifications/{notification}/cancel', [X\NotificationController::class, 'cancel'])->name('notifications.cancel-approve');
    Route::post('notifications/{notification}/retry', [X\NotificationController::class, 'retryFailed'])->name('notifications.retry');
    Route::delete('notifications/{notification}', [X\NotificationController::class, 'destroy'])->name('notifications.destroy');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // Issue 51 (P1) — Payments & revenue; referrals; global search
    Route::get('revenue', [X\RevenueController::class, 'index'])->name('revenue.index');
    Route::get('revenue/export', [X\RevenueController::class, 'export'])->name('revenue.export');
    Route::post('revenue/refunds', [X\RevenueController::class, 'storeRefund'])->name('revenue.refunds.store-approve');
    Route::get('referrals', [X\ReferralController::class, 'index'])->name('referrals.index');
    Route::get('referrals/export', [X\ReferralController::class, 'export'])->name('referrals.export');
    Route::get('search', [X\GlobalSearchController::class, 'index'])->name('search');
});

Route::prefix('admin')->name('admin.')->middleware('auth:admin')->group(function () {
    // 2026-11-20 — Trading DNA (module "dna": view) — Phase 3 overview + mentor view.
    Route::get('dna', [X\TradingDnaAdminController::class, 'index'])->name('dna.index');
    Route::get('dna/students', [X\TradingDnaAdminController::class, 'students'])->name('dna.students');
    Route::get('dna/students/{user}', [X\TradingDnaAdminController::class, 'show'])->whereNumber('user')->name('dna.students.show');

    // 2026-11-20 — Trading Journal (module "journal": view / edit / delete).
    Route::get('journal', [X\JournalAdminController::class, 'index'])->name('journal.index');
    Route::get('journal/students', [X\JournalAdminController::class, 'students'])->name('journal.students');
    Route::get('journal/students/{user}', [X\JournalAdminController::class, 'show'])->whereNumber('user')->name('journal.students.show');
    Route::get('journal/students/{user}/book', [X\JournalAdminController::class, 'book'])->whereNumber('user')->name('journal.students.book');
    Route::delete('journal/students/{user}', [X\JournalAdminController::class, 'destroy'])->whereNumber('user')->name('journal.students.destroy');
    Route::post('journal/students/{user}/notes', [X\JournalAdminController::class, 'storeNote'])->whereNumber('user')->name('journal.notes.store');
    Route::delete('journal/notes/{note}', [X\JournalAdminController::class, 'destroyNote'])->whereNumber('note')->name('journal.notes.destroy');
    Route::get('journal/connections', [X\JournalAdminController::class, 'connections'])->name('journal.connections');
    Route::post('journal/connections/{connection}/test', [X\JournalAdminController::class, 'testConnection'])->whereNumber('connection')->name('journal.connections.test');
    Route::post('journal/connections/{connection}/sync', [X\JournalAdminController::class, 'syncConnection'])->whereNumber('connection')->name('journal.connections.sync');
    Route::delete('journal/connections/{connection}', [X\JournalAdminController::class, 'destroyConnection'])->whereNumber('connection')->name('journal.connections.destroy');
    Route::get('journal/reports', [X\JournalAdminController::class, 'reports'])->name('journal.reports');
    Route::get('journal/reports/export-students', [X\JournalAdminController::class, 'exportStudents'])->name('journal.reports.export-students');
    Route::get('journal/reports/export-trades', [X\JournalAdminController::class, 'exportTrades'])->name('journal.reports.export-trades');
    Route::get('journal/settings', [X\JournalAdminController::class, 'settings'])->name('journal.settings');
    Route::put('journal/settings', [X\JournalAdminController::class, 'updateSettings'])->name('journal.settings.update');
});
