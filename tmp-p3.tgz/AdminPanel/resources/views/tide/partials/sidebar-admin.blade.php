{{--
    Admin sidebar — transcribed from TIDE/.build/sidebars/admin.html.
    Icons, grouping, order and classes unchanged; hrefs point at the real
    admin routes. Items whose design page has no backend are marked below.

    Mapping notes:
    - "Exception Queue" -> manual payments awaiting an admin decision
      (admin.course-pending-payment), the closest real "needs a human" queue.
    - "Memberships"     -> course enrolment orders (admin.course-enrollments).
    - "Certificates"    -> the existing certificate builder module.
    - Homework Oversight / Audit Logs / Announcements have no backend and
      route to TODO placeholder pages.
--}}
@php
    /*
     | Resolve a route name to a URL, or to '#' when that route is not
     | registered.
     |
     | This sidebar is @included by admin/master_layout.blade.php, which EVERY
     | authenticated admin page extends, and it names ~30 routes. A bare
     | route() throws RouteNotFoundException when one of them is missing, and
     | because the include sits in the layout that single failure returned 500
     | on every page in the panel at once — while the login screen, which does
     | not use this layout, kept working and made it look like a session bug.
     |
     | That is exactly what happened on 2026-09-26: a module route file was
     | deployed to Modules/GlobalSetting/Routes/ instead of .../routes/. Linux
     | is case-sensitive, so Laravel never loaded it, admin.mobile-app-setting
     | did not exist, and the whole panel went down behind one missing link.
     |
     | A navigation link is not worth a 500. A missing route now degrades to a
     | dead item in the menu, which is visible, survivable and obvious to
     | diagnose.
     */
    $navUrl = function (string $name): ?string {
        // app('router') rather than the Route facade: a Blade @php block has
        // no `use` statements, so the facade would need a fully-qualified
        // name, and one mistyped backslash here breaks every admin page —
        // which is the exact failure this helper exists to prevent.
        if (! app('router')->has($name)) {
            return '#';
        }

        // Issue 51: an item the admin's role cannot open is hidden (null),
        // and filtered out below.
        return \App\Providers\PlatformExtensionsServiceProvider::canRoute($name) ? route($name) : null;
    };

    // Same as $navUrl, plus the admin's language for pages that need ?lang_code=.
    $langUrl = function (string $name) use ($navUrl): ?string {
        $url = $navUrl($name);

        return $url && $url !== '#' ? route($name, ['lang_code' => admin_lang()]) : $url;
    };

    // Pages on the legacy layout pass no $active; highlight the Website items by route.
    if (empty($active)) {
        $active = request()->routeIs('admin.footer') ? 'website-footer' : (request()->routeIs('admin.contact-us') ? 'website-contact' : ($active ?? ''));
    }

    $groups = [
        null => [
            ['key' => 'dashboard', 'label' => 'Dashboard', 'url' => $navUrl('admin.dashboard'),
             'icon' => '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>'],
            ['key' => 'analytics', 'label' => 'Analytics', 'url' => $navUrl('admin.analytics'),
             'icon' => '<path d="M3 3v18h18"/><path d="M7 15l4-6 3 4 5-8"/>'],
            ['key' => 'applications', 'label' => 'Exception Queue', 'url' => $navUrl('admin.course-pending-payment'),
             'icon' => '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>'],
        ],
        'People' => [
            ['key' => 'students-group', 'label' => 'Students',
             'icon' => '<path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 20v-2a4 4 0 0 0-3-3.9"/>',
             'children' => [
                ['key' => 'students', 'label' => 'Student List', 'url' => $navUrl('admin.user-list')],
                ['key' => 'pending-students', 'label' => 'Pending Verification', 'url' => $navUrl('admin.pending-user')],
                ['key' => 'progress', 'label' => 'Student Progress', 'url' => $navUrl('admin.student-progress')],
                ['key' => 'memberships', 'label' => 'Memberships', 'url' => $navUrl('admin.course-enrollments')],
             ]],
            ['key' => 'instructors', 'label' => 'Instructors & Mentors', 'url' => $navUrl('admin.seller-list'),
             'icon' => '<path d="M22 10L12 5 2 10l10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>'],
            // Issue 40 — Calendly → Zoom → Telegram mentorship bookings.
            ['key' => 'mentorship', 'label' => 'Mentorship Bookings', 'url' => $navUrl('admin.mentorship.index'),
             'icon' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M9 16l2 2 4-4"/>'],
            // 2026-11-20 — Trading DNA (DISC): profile mix, reliability, mentor view.
            ['key' => 'dna-group', 'label' => 'Trading DNA',
             'icon' => '<path d="M7 3c0 6 10 6 10 12s-10 6-10 6"/><path d="M17 3c0 6-10 6-10 12s10 6 10 6"/>',
             'children' => [
                ['key' => 'dna', 'label' => 'Overview', 'url' => $navUrl('admin.dna.index')],
                ['key' => 'dna-students', 'label' => 'Students', 'url' => $navUrl('admin.dna.students')],
             ]],
            // 2026-11-20 — students' Trading Journal: books, broker connections, mentor notes, reports, page settings.
            ['key' => 'journal-group', 'label' => 'Trading Journal',
             'icon' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M8 13l3-3 2 2 3-4"/>',
             'children' => [
                ['key' => 'journal', 'label' => 'Overview', 'url' => $navUrl('admin.journal.index')],
                ['key' => 'journal-students', 'label' => 'Students', 'url' => $navUrl('admin.journal.students')],
                ['key' => 'journal-connections', 'label' => 'Connections', 'url' => $navUrl('admin.journal.connections')],
                ['key' => 'journal-reports', 'label' => 'Reports', 'url' => $navUrl('admin.journal.reports')],
                ['key' => 'journal-settings', 'label' => 'Settings', 'url' => $navUrl('admin.journal.settings')],
             ]],
        ],
        'Academy' => [
            ['key' => 'courses-group', 'label' => 'Courses',
             'icon' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
             'children' => [
                ['key' => 'courses', 'label' => 'Course List', 'url' => $navUrl('admin.courses.index')],
                ['key' => 'course-create', 'label' => 'Create Course', 'url' => $navUrl('admin.courses.create')],
                ['key' => 'course-approvals', 'label' => 'Awaiting Approval', 'url' => $navUrl('admin.pending-course')],
                ['key' => 'categories', 'label' => 'Learning Tracks', 'url' => $navUrl('admin.category.index')],
             ]],
            ['key' => 'homework', 'label' => 'Homework Oversight', 'url' => $navUrl('admin.homework'),
             'icon' => '<path d="M14 3v5h5"/><path d="M19 8v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7z"/><path d="M9 15l2 2 4-4"/>'],
            // Extra material outside the 26-module curriculum; never part of
            // course progress or the final exam.
            ['key' => 'bonus-lessons', 'label' => 'Bonus Lessons', 'url' => $navUrl('admin.bonus-lessons'),
             'icon' => '<path d="M12 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8z"/>'],
            ['key' => 'live-sessions', 'label' => 'Live Sessions', 'url' => $navUrl('admin.live-sessions'),
             'icon' => '<rect x="2" y="5" width="14" height="14" rx="2"/><path d="M22 7l-6 5 6 5z"/>'],
            ['key' => 'certificates', 'label' => 'Certificates', 'url' => $navUrl('admin.certificatebuilder'),
             'icon' => '<circle cx="12" cy="9" r="6"/><path d="M8.5 14.5L7 22l5-3 5 3-1.5-7.5"/>'],
            // Issue 51 — reusable exam questions; Issue 49 — course ratings; Issue 50 — FAQ.
            ['key' => 'question-bank', 'label' => 'Question Bank', 'url' => $navUrl('admin.question-bank.index'),
             'icon' => '<path d="M9 9a3 3 0 1 1 4 2.8c-.6.3-1 .9-1 1.6V14"/><path d="M12 17h.01"/><rect x="3" y="3" width="18" height="18" rx="3"/>'],
            ['key' => 'reviews', 'label' => 'Ratings & Reviews', 'url' => $navUrl('admin.reviews.index'),
             'icon' => '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>'],
            // Certificate feedback given before the first certificate download.
            ['key' => 'student-reviews', 'label' => 'Student Reviews', 'url' => $navUrl('admin.reviews.student.index'),
             'icon' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M12 7l1.2 2.4 2.6.4-1.9 1.8.5 2.6-2.4-1.2-2.4 1.2.5-2.6-1.9-1.8 2.6-.4z"/>'],
            ['key' => 'faq', 'label' => 'FAQ / Q&A', 'url' => $navUrl('admin.faq.index'),
             'icon' => '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>'],
            ['key' => 'challenges', 'label' => 'Challenges', 'url' => $navUrl('admin.challenges.index'),
             'icon' => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/>'],
        ],
        'Community' => [
            // Platform-wide announcements, published by admins (real module).
            ['key' => 'announcements', 'label' => 'Announcements', 'url' => $navUrl('admin.announcements'),
             'icon' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>'],
            ['key' => 'notifications', 'label' => 'Notifications', 'url' => $navUrl('admin.notifications.index'),
             'icon' => '<path d="M22 17H2a3 3 0 0 0 3-3V9a7 7 0 0 1 14 0v5a3 3 0 0 0 3 3z"/><path d="M8.5 21a3.5 3.5 0 0 0 7 0"/>'],
            ['key' => 'testimonials', 'label' => 'Testimonials', 'url' => $navUrl('admin.testimonial.index'),
             'icon' => '<path d="M7 8h10M7 12h6"/><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'],
            ['key' => 'blogs', 'label' => 'Blog', 'url' => $navUrl('admin.blog.index'),
             'icon' => '<path d="M14 3v5h5"/><path d="M19 8v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7z"/><path d="M9 13h6M9 17h4"/>'],
            ['key' => 'contact-messages', 'label' => 'Contact Messages', 'url' => $navUrl('admin.contact-message'),
             'icon' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 6 10-6"/>'],
            ['key' => 'comments', 'label' => 'Course Comments', 'url' => $navUrl('admin.comment-list'),
             'icon' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/>'],
            ['key' => 'support', 'label' => 'Support Tickets', 'url' => $navUrl('admin.support-tickets'),
             'icon' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'],
        ],
        'Finance' => [
            ['key' => 'revenue', 'label' => 'Payments & Revenue', 'url' => $navUrl('admin.revenue.index'),
             'icon' => '<path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>'],
            ['key' => 'referrals', 'label' => 'Referrals', 'url' => $navUrl('admin.referrals.index'),
             'icon' => '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>'],
        ],
        // Footer contacts/social links and the Contact page (2026-11-13). Both
        // pages need ?lang_code= to load their translated text.
        'Website' => [
            ['key' => 'website-footer', 'label' => 'Footer & Contacts', 'url' => $langUrl('admin.footer'),
             'icon' => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 15h18"/><path d="M7 18.5h4"/>'],
            ['key' => 'website-contact', 'label' => 'Contact Page', 'url' => $langUrl('admin.contact-us'),
             'icon' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>'],
        ],
        'Marketing' => [
            // Issue 32 — verified press, podcasts and media coverage.
            ['key' => 'media', 'label' => 'Featured & Media', 'url' => $navUrl('admin.media.index'),
             'icon' => '<rect x="2" y="7" width="20" height="15" rx="2"/><path d="M17 2l-5 5-5-5"/>'],
            ['key' => 'seo', 'label' => 'SEO Settings', 'url' => $navUrl('admin.seo-setting'),
             'icon' => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>'],
            ['key' => 'newsletter-subscribers', 'label' => 'Subscribers', 'url' => $navUrl('admin.newsletter-list'),
             'icon' => '<path d="M4 4h16v16H4z"/><path d="M4 8l8 5 8-5"/>'],
            ['key' => 'newsletter-send', 'label' => 'Send Newsletter', 'url' => $navUrl('admin.newsletter-email'),
             'icon' => '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>'],
        ],
        'System' => [
            ['key' => 'email-setting', 'label' => 'Email Settings', 'url' => $navUrl('admin.email-setting'),
             'icon' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 6 10-6"/>'],
            ['key' => 'email-template', 'label' => 'Email Templates', 'url' => $navUrl('admin.email-template'),
             'icon' => '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/>'],
            // Issue 51 — roles & permissions and admin accounts.
            ['key' => 'roles', 'label' => 'Roles & Permissions', 'url' => $navUrl('admin.roles.index'),
             'icon' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><circle cx="12" cy="10" r="2"/><path d="M12 12v3"/>'],
            ['key' => 'admins', 'label' => 'Admin Accounts', 'url' => $navUrl('admin.admins.index'),
             'icon' => '<circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M19 8v6M22 11h-6"/>'],
            // Issue 45 — the audit trail (was a placeholder).
            ['key' => 'audit', 'label' => 'Audit Logs', 'url' => $navUrl('admin.audit-logs'),
             'icon' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>'],
            ['key' => 'settings', 'label' => 'Settings', 'url' => $navUrl('admin.general-setting'),
             'icon' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9M4.6 9a1.7 1.7 0 0 0-.3-1.9M15 4.6a1.7 1.7 0 0 0 1.9.3M9 19.4a1.7 1.7 0 0 0-1.9-.3"/>'],
            // Where the APK and App Store links live; the website reads them
            // to send students to the app for PDF, slides and video.
            ['key' => 'mobile-app-setting', 'label' => 'Mobile App', 'url' => $navUrl('admin.mobile-app-setting'),
             'icon' => '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'],
            ['key' => 'profile', 'label' => 'My Profile', 'url' => $navUrl('admin.edit-profile'),
             'icon' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'],
        ],
    ];
@endphp

@php
    // Drop what this admin's role may not open, then any group left empty.
    foreach ($groups as $heading => $items) {
        $items = array_values(array_filter(array_map(function ($item) {
            if (! empty($item['children'])) {
                $item['children'] = array_values(array_filter($item['children'], fn ($c) => $c['url'] !== null));

                return $item['children'] ? $item : null;
            }

            return ($item['url'] ?? null) !== null ? $item : null;
        }, $items)));
        if ($items) {
            $groups[$heading] = $items;
        } else {
            unset($groups[$heading]);
        }
    }
@endphp
@include('tide.partials.sidebar-nav', ['groups' => $groups, 'active' => $active ?? ''])
