{{-- Trading DNA sub-navigation (2026-11-20). --}}
<div class="tx-tabs flex flex-wrap gap-2">
  @foreach (['admin.dna.index' => 'Overview', 'admin.dna.students' => 'Students'] as $r => $l)
    <a href="{{ route($r) }}" class="tx-tab {{ request()->routeIs($r) || ($r === 'admin.dna.students' && request()->routeIs('admin.dna.students.*')) ? 'is-active' : '' }}">{{ $l }}</a>
  @endforeach
</div>
