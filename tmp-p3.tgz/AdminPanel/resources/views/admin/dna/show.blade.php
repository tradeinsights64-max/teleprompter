{{-- 2026-11-20 — Admin → Trading DNA → one student (mentor view). --}}
@extends('tide.layouts.dashboard', ['role' => 'admin', 'active' => 'dna-students'])
@section('title', 'Trading DNA — '.($student->name ?? 'student').' — Trade Insight Academy')
@section('page_title', 'Trading DNA — '.($student->name ?? 'student #'.$student->id))

@php
  $lvl = fn ($s) => $s >= 65 ? 'tx-badge-red' : ($s >= 40 ? 'tx-badge-amber' : 'tx-badge-green');
  $shares = json_decode((string) $latest->shares, true) ?: [];
  $q = json_decode((string) $latest->quality, true)['level'] ?? null;
  $verdict = ['worse' => ['Worse than they said', 'tx-badge-red'], 'match' => ['Matches', 'tx-badge-green'], 'better' => ['Better than they said', 'tx-badge-navy']];
@endphp

@section('content')
<div class="space-y-6">
  @include('admin.dna._nav')

  <section class="tx-card p-6">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div>
        <p class="text-sm text-ink-500">{{ $student->email }}@if ($student->phone) · {{ $student->phone }}@endif @if ($student->country) · {{ $student->country }}@endif</p>
        <h2 class="mt-1 font-display text-2xl font-bold text-navy-900">{{ $latest->style_code }} · {{ $names[$latest->primary_style] ?? '' }}</h2>
        <p class="mt-1 text-sm text-ink-500">Latest test {{ \Illuminate\Support\Carbon::parse($latest->created_at)->format('d M Y') }} · {{ $latest->version === 'v2' ? 'new test' : 'old test' }} · average risk {{ $latest->overall_risk }}
          @if ($q) · answer quality <span class="tx-badge {{ ['high' => 'tx-badge-green', 'medium' => 'tx-badge-amber', 'low' => 'tx-badge-red'][$q] }}">{{ ucfirst($q) }}</span>@endif</p>
        <p class="mt-2 text-sm">D {{ round($shares['D'] ?? 0) }}% · I {{ round($shares['I'] ?? 0) }}% · S {{ round($shares['S'] ?? 0) }}% · C {{ round($shares['C'] ?? 0) }}%</p>
      </div>
      <a href="{{ route('admin.journal.students.show', $student->id) }}" class="tx-btn tx-btn-ghost">Open their journal →</a>
    </div>
  </section>

  <div class="grid gap-6 lg:grid-cols-2">
    <section class="tx-card p-6">
      <h3 class="mb-4 font-display text-base font-bold text-navy-900">Risk map (latest test)</h3>
      <table class="tx-table">
        <thead><tr><th>Behaviour</th><th class="text-right">Score</th><th>They said it happens</th></tr></thead>
        <tbody>@foreach ($risks as $k => $r)
          <tr><td class="font-semibold text-navy-900">{{ $riskNames[$k] ?? $k }}</td><td class="text-right"><span class="tx-badge {{ $lvl($r['score'] ?? 0) }}">{{ $r['score'] ?? 0 }}</span></td><td class="text-sm">{{ $freq[$r['habit'] ?? 0] ?? '—' }}</td></tr>
        @endforeach</tbody>
      </table>
    </section>

    <section class="tx-card p-6">
      <h3 class="mb-1 font-display text-base font-bold text-navy-900">Journal check: said vs did</h3>
      @if (! $measured || ! ($measured['enough'] ?? false))
        <p class="text-sm text-ink-500">Needs at least {{ $measured['min'] ?? 10 }} real journal trades. This student has {{ $measured['trades'] ?? 0 }}.</p>
        <p class="tx-help mt-2">Tip for the mentor call: ask them to log every trade for 2 weeks, with mistakes, emotion and "Did I follow my plan?".</p>
      @else
        <p class="mb-4 text-sm text-ink-500">Last {{ $measured['trades'] }} live trades ({{ $measured['from'] }} – {{ $measured['to'] }}). Start the call with the red rows.</p>
        @if (! $compare)<p class="text-sm text-ink-400">Not enough tagged data for any behaviour yet.</p>@else
        <table class="tx-table">
          <thead><tr><th>Behaviour</th><th>Said</th><th class="text-right">Journal</th><th></th></tr></thead>
          <tbody>@foreach ($compare as $c)
            <tr><td class="font-semibold text-navy-900">{{ $riskNames[$c['key']] ?? $c['key'] }}</td><td class="text-sm">{{ $c['said'] }}</td><td class="text-right">{{ $c['did'] }}%</td><td><span class="tx-badge {{ $verdict[$c['verdict']][1] }}">{{ $verdict[$c['verdict']][0] }}</span></td></tr>
          @endforeach</tbody>
        </table>
        @endif
      @endif
    </section>
  </div>

  <section class="tx-card">
    <div class="border-b border-ink-100 px-6 py-4"><h3 class="font-display text-base font-bold text-navy-900">All attempts</h3></div>
    <div class="overflow-x-auto"><table class="tx-table">
      <thead><tr><th>Date</th><th>Test</th><th>Profile</th><th>D · I · S · C (%)</th><th>#1 risk</th><th class="text-right">Avg risk</th></tr></thead>
      <tbody>@foreach ($attempts as $a)
        @php $s = json_decode((string) $a->shares, true) ?: []; $t = \App\Http\Controllers\Admin\Extensions\TradingDnaAdminController::top($a); @endphp
        <tr>
          <td class="whitespace-nowrap text-sm">{{ \Illuminate\Support\Carbon::parse($a->created_at)->format('d M Y H:i') }}</td>
          <td class="text-sm">{{ $a->version === 'v2' ? 'new' : 'old' }}</td>
          <td><strong>{{ $a->style_code }}</strong></td>
          <td class="text-sm">{{ round($s['D'] ?? 0) }} · {{ round($s['I'] ?? 0) }} · {{ round($s['S'] ?? 0) }} · {{ round($s['C'] ?? 0) }}</td>
          <td>@if ($t['key']){{ $riskNames[$t['key']] ?? $t['key'] }} <span class="tx-badge {{ $lvl($t['score']) }}">{{ $t['score'] }}</span>@endif</td>
          <td class="text-right">{{ $a->overall_risk }}</td>
        </tr>
      @endforeach</tbody>
    </table></div>
  </section>
</div>
@endsection
