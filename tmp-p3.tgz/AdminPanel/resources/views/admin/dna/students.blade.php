{{-- 2026-11-20 — Admin → Trading DNA → Students (mentor view). --}}
@extends('tide.layouts.dashboard', ['role' => 'admin', 'active' => 'dna-students'])
@section('title', 'Trading DNA students — Trade Insight Academy')
@section('page_title', 'Trading DNA — students')

@php
  $lvl = fn ($s) => $s >= 65 ? 'tx-badge-red' : ($s >= 40 ? 'tx-badge-amber' : 'tx-badge-green');
@endphp

@section('content')
<div class="space-y-6">
  @include('admin.dna._nav')

  <section class="tx-card">
    <form method="GET" class="tx-filters border-b border-ink-100 px-6 py-4" style="--tx-cols:6">
      <input type="search" name="q" value="{{ request('q') }}" placeholder="Search name, email, phone or ID…" class="tx-input">
      <select name="profile" class="tx-select"><option value="">All profiles</option>@foreach ($names as $l => $n)<option value="{{ $l }}" @selected(request('profile') === $l)>{{ $l }} — {{ $n }}</option>@endforeach</select>
      <select name="risk" class="tx-select"><option value="">Any #1 risk</option>@foreach ($risks as $k => $n)<option value="{{ $k }}" @selected(request('risk') === $k)>{{ $n }}</option>@endforeach</select>
      <select name="filter" class="tx-select"><option value="">All students</option><option value="high" @selected(request('filter') === 'high')>Top risk 65+</option></select>
      <select name="sort" class="tx-select"><option value="">Newest first</option><option value="risk" @selected(request('sort') === 'risk')>Highest risk first</option></select>
      <div class="flex gap-2"><button class="tx-btn tx-btn-dark w-full">Filter</button><a href="{{ route('admin.dna.students') }}" class="tx-btn tx-btn-ghost">Reset</a></div>
    </form>
    @if ($rows->isEmpty())
      <div class="px-6 py-16 text-center"><p class="font-display text-lg font-bold text-navy-900">No results match</p></div>
    @else
    <div class="overflow-x-auto"><table class="tx-table">
      <thead><tr><th>Student</th><th>Profile</th><th>#1 risk</th><th class="text-right">Avg risk</th><th>Answers</th><th class="text-right">Attempts</th><th class="text-right">Journal trades</th><th>Last test</th><th></th></tr></thead>
      <tbody>@foreach ($rows as $r)
        @php $q = json_decode((string) $r->quality, true)['level'] ?? null; @endphp
        <tr>
          <td><a class="font-semibold text-navy-900 hover:text-flame-600" href="{{ route('admin.dna.students.show', $r->user_id) }}">{{ $r->name ?? 'Deleted student #'.$r->user_id }}</a>
            <div class="text-xs text-ink-400">{{ $r->email }}@if ($r->phone) · {{ $r->phone }}@endif</div></td>
          <td><strong>{{ $r->style_code }}</strong><div class="text-xs text-ink-400">{{ $names[$r->primary_style] ?? '' }}</div></td>
          <td>@if ($r->top['key']){{ $risks[$r->top['key']] ?? $r->top['key'] }} <span class="tx-badge {{ $lvl($r->top['score']) }}">{{ $r->top['score'] }}</span>@else—@endif</td>
          <td class="text-right">{{ $r->overall_risk }}</td>
          <td>@if ($q)<span class="tx-badge {{ ['high' => 'tx-badge-green', 'medium' => 'tx-badge-amber', 'low' => 'tx-badge-red'][$q] }}">{{ ucfirst($q) }}</span>@else<span class="text-xs text-ink-400">old test</span>@endif</td>
          <td class="text-right">{{ $r->attempts }}</td>
          <td class="text-right">{{ $r->journal_trades ?: '—' }}</td>
          <td class="whitespace-nowrap text-sm">{{ \Illuminate\Support\Carbon::parse($r->created_at)->format('d M Y') }}</td>
          <td class="text-right"><a href="{{ route('admin.dna.students.show', $r->user_id) }}" class="tx-btn tx-btn-ghost tx-btn-sm">Open</a></td>
        </tr>
      @endforeach</tbody>
    </table></div>
    <div class="px-6 py-4">{{ $rows->links() }}</div>
    @endif
  </section>
</div>
@endsection
