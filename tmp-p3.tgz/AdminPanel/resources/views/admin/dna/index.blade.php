{{-- 2026-11-20 — Admin → Trading DNA → Overview (Phase 3). --}}
@extends('tide.layouts.dashboard', ['role' => 'admin', 'active' => 'dna'])
@section('title', 'Trading DNA — Trade Insight Academy')
@section('page_title', 'Trading DNA')

@php
  $names = \App\Http\Controllers\Admin\Extensions\TradingDnaAdminController::NAMES;
  $colors = ['D' => '#d92d20', 'I' => '#e8a200', 'S' => '#12965a', 'C' => '#2f5fe0'];
  $pct = fn ($n, $t) => $t ? round($n * 100 / $t) : 0;
  $rel = $reliability;
@endphp

@section('content')
<div class="space-y-6">
  @include('admin.dna._nav')

  <div class="tx-grid-stats">
    <div class="tx-stat"><p class="tx-stat-label">Students tested</p><p class="tx-stat-value">{{ number_format($kpi['students']) }}</p><p class="tx-help">{{ number_format($kpi['attempts']) }} attempts · {{ $kpi['last7'] }} in the last 7 days</p></div>
    <div class="tx-stat"><p class="tx-stat-label">Took the new test (v2)</p><p class="tx-stat-value">{{ number_format($kpi['v2']) }}</p><p class="tx-help">Since Nov 20, 2026</p></div>
    <div class="tx-stat"><p class="tx-stat-label">Retook the test</p><p class="tx-stat-value">{{ number_format($kpi['retakers']) }}</p><p class="tx-help">Students with 2+ attempts</p></div>
    <div class="tx-stat"><p class="tx-stat-label">High top risk (65+)</p><p class="tx-stat-value {{ $kpi['high_top'] ? 'text-rose-600' : '' }}">{{ number_format($kpi['high_top']) }}</p>
      <p class="tx-help"><a class="font-semibold hover:text-flame-600" href="{{ route('admin.dna.students', ['filter' => 'high', 'sort' => 'risk']) }}">Who to call first →</a></p></div>
  </div>

  <div class="grid gap-6 lg:grid-cols-2">
    <section class="tx-card p-6">
      <h3 class="mb-1 font-display text-base font-bold text-navy-900">Profile mix (latest result per student)</h3>
      <p class="mb-4 text-sm text-ink-500">The old test (v1) made the careful "C" answer easy to spot, so most people came out C. The new test (v2) should show a wider spread.</p>
      @foreach (['v1' => 'Old test (v1)', 'v2' => 'New test (v2)'] as $v => $label)
        @php $tot = array_sum($mix[$v]); @endphp
        <p class="mt-3 text-sm font-semibold text-navy-900">{{ $label }} · {{ $tot }} {{ \Illuminate\Support\Str::plural('student', $tot) }}</p>
        @if ($tot)
          <div class="mt-2 flex h-6 overflow-hidden rounded-full">
            @foreach ($mix[$v] as $l => $n)@if ($n)<div title="{{ $names[$l] }}: {{ $n }}" style="width:{{ $pct($n, $tot) }}%;background:{{ $colors[$l] }}" class="flex items-center justify-center text-xs font-bold text-white">{{ $l }} {{ $pct($n, $tot) }}%</div>@endif @endforeach
          </div>
        @else <p class="text-sm text-ink-400">No results yet.</p> @endif
      @endforeach
    </section>

    <section class="tx-card p-6">
      <h3 class="mb-1 font-display text-base font-bold text-navy-900">Is the test reliable?</h3>
      <p class="mb-4 text-sm text-ink-500">Students who took it twice. A good behaviour test gives a similar result when nothing has changed, and moves when behaviour really changes.</p>
      @if (! $rel['pairs'])
        <p class="text-sm text-ink-400">No retakes yet.</p>
      @else
      <table class="tx-table">
        <tbody>
          <tr><td>Retake pairs</td><td class="text-right font-semibold">{{ $rel['pairs'] }}</td></tr>
          <tr><td>Same main profile on retake</td><td class="text-right font-semibold">{{ $rel['same_primary_pct'] }}%</td></tr>
          <tr><td>DISC mix similarity (correlation, 1 = identical)</td><td class="text-right font-semibold">{{ $rel['mean_r'] ?? '—' }}</td></tr>
          <tr><td>Average change per risk score</td><td class="text-right font-semibold">{{ $rel['mean_risk_delta'] ?? '—' }} points</td></tr>
          <tr><td>Retakes within 14 days</td><td class="text-right font-semibold">{{ $rel['short'] }}@if ($rel['short']) · {{ $rel['short_same_pct'] }}% same profile · r {{ $rel['short_r'] ?? '—' }}@endif</td></tr>
        </tbody>
      </table>
      <p class="tx-help mt-3">Read it like this: correlation above 0.7 and 70%+ same profile = stable. Retakes after 4+ weeks are expected to move if the student worked on the roadmap. Mixed v1/v2 pairs are less comparable (the questions changed).</p>
      @endif
    </section>
  </div>

  <div class="grid gap-6 lg:grid-cols-2">
    <section class="tx-card p-6">
      <h3 class="mb-1 font-display text-base font-bold text-navy-900">Most common highest risk</h3>
      <p class="mb-4 text-sm text-ink-500">What to teach next: the behaviour that is most often a student's #1 risk.</p>
      @php $maxTop = max(1, ...array_column($riskRows, 'top')); @endphp
      <table class="tx-table">
        <thead><tr><th>Risk</th><th style="width:40%">#1 risk for</th><th class="text-right">Avg score</th></tr></thead>
        <tbody>@foreach ($riskRows as $r)
          <tr>
            <td class="font-semibold text-navy-900"><a class="hover:text-flame-600" href="{{ route('admin.dna.students', ['risk' => $r['key'], 'sort' => 'risk']) }}">{{ $r['label'] }}</a></td>
            <td><div class="flex items-center gap-2"><div class="h-2 rounded-full bg-ink-100" style="flex:1"><div class="h-2 rounded-full bg-flame-500" style="width:{{ round($r['top'] * 100 / $maxTop, 1) }}%"></div></div><span class="text-xs">{{ $r['top'] }}</span></div></td>
            <td class="text-right">{{ $r['avg'] ?? '—' }}</td>
          </tr>
        @endforeach</tbody>
      </table>
    </section>

    <section class="tx-card p-6">
      <h3 class="mb-1 font-display text-base font-bold text-navy-900">Answer quality (new test)</h3>
      <p class="mb-4 text-sm text-ink-500">4 hidden check questions catch answers that contradict each other or look "too perfect".</p>
      @php $qt = array_sum($quality); @endphp
      @if (! $qt)
        <p class="text-sm text-ink-400">No v2 results yet.</p>
      @else
      <table class="tx-table"><tbody>
        @foreach (['high' => ['High — reliable', 'tx-badge-green'], 'medium' => ['Medium — read as a guide', 'tx-badge-amber'], 'low' => ['Low — ask them to retake', 'tx-badge-red']] as $k => [$l, $c])
          <tr><td><span class="tx-badge {{ $c }}">{{ $l }}</span></td><td class="text-right font-semibold">{{ $quality[$k] }} ({{ $pct($quality[$k], $qt) }}%)</td></tr>
        @endforeach
      </tbody></table>
      @if ($quality['low'])<p class="tx-help mt-3"><a class="font-semibold hover:text-flame-600" href="{{ route('admin.dna.students', ['quality' => 'low']) }}">Students with low answer quality →</a></p>@endif
      @endif
    </section>
  </div>
</div>
@endsection
