<?php

namespace App\Http\Controllers\Admin\Extensions;

use App\Http\Controllers\Controller;
use App\Support\TradingDnaMeasured;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Admin → Trading DNA (2026-11-20, Phase 3). Reads disc_assessments only.
 *
 *  - Overview: who took the test, profile mix (v1 vs v2), the most common top
 *    risks, answer quality, and how reliable the test is (retake stability).
 *  - Students: latest result per student, filterable, so a mentor can pick
 *    who to call first.
 *  - Student: every attempt, the risk map and the journal check
 *    (said vs did, TradingDnaMeasured).
 *
 * Route names sit under admin.dna.* → the "dna" permission module.
 */
class TradingDnaAdminController extends Controller
{
    public const LETTERS = ['D', 'I', 'S', 'C'];
    public const NAMES = ['D' => 'Dominance · The Commander', 'I' => 'Influence · The Surfer', 'S' => 'Steadiness · The Sniper', 'C' => 'Conscientiousness · The Architect'];
    public const RISKS = [
        'overtrading' => 'Overtrading', 'impatience' => 'Impatience & early entries', 'hesitation' => 'Hesitation & missed entries',
        'revenge' => 'Revenge trading', 'oversizing' => 'Excessive risk-taking', 'early_exit' => 'Early exits',
        'moving_sl' => 'Moving the stop loss', 'holding_losers' => 'Difficulty accepting losses', 'fomo' => 'FOMO',
        'plan_deviation' => 'Plan deviation', 'over_analysis' => 'Excessive analysis', 'overconfidence' => 'Overconfidence after wins',
    ];
    public const FREQ = ['Never', 'Rarely', 'Sometimes', 'Often', 'Almost always'];

    // ---------- overview ----------

    public function index()
    {
        $rows = DB::table('disc_assessments')->orderBy('user_id')->orderBy('id')
            ->get(['id', 'user_id', 'version', 'primary_style', 'style_code', 'shares', 'risks', 'overall_risk', 'quality', 'created_at']);

        $byUser = $rows->groupBy('user_id');
        $latest = $byUser->map(fn ($g) => $g->last());

        $kpi = [
            'students' => $byUser->count(),
            'attempts' => $rows->count(),
            'retakers' => $byUser->filter(fn ($g) => $g->count() > 1)->count(),
            'v2' => $rows->where('version', 'v2')->count(),
            'last7' => $rows->where('created_at', '>=', now()->subDays(7)->toDateTimeString())->count(),
            'avg_overall' => $latest->count() ? round($latest->avg('overall_risk'), 1) : null,
            'high_top' => $latest->filter(fn ($r) => self::top($r)['score'] >= 65)->count(),
        ];

        // Profile mix: latest result per student, split by test version (v1 had the "obvious answer" bias).
        $mix = ['v1' => array_fill_keys(self::LETTERS, 0), 'v2' => array_fill_keys(self::LETTERS, 0)];
        foreach ($latest as $r) {
            $v = $r->version === 'v2' ? 'v2' : 'v1';
            $mix[$v][$r->primary_style] = ($mix[$v][$r->primary_style] ?? 0) + 1;
        }

        // Most common highest risk + average score per risk (latest result per student).
        $topCount = array_fill_keys(array_keys(self::RISKS), 0);
        $avg = array_fill_keys(array_keys(self::RISKS), [0, 0]);
        foreach ($latest as $r) {
            $risks = json_decode((string) $r->risks, true) ?: [];
            $t = self::top($r);
            if ($t['key']) {
                $topCount[$t['key']]++;
            }
            foreach ($risks as $k => $v) {
                if (isset($avg[$k])) {
                    $avg[$k][0] += (int) ($v['score'] ?? 0);
                    $avg[$k][1]++;
                }
            }
        }
        $riskRows = [];
        foreach (self::RISKS as $k => $label) {
            $riskRows[] = ['key' => $k, 'label' => $label, 'top' => $topCount[$k], 'avg' => $avg[$k][1] ? round($avg[$k][0] / $avg[$k][1]) : null];
        }
        usort($riskRows, fn ($a, $b) => [$b['top'], $b['avg']] <=> [$a['top'], $a['avg']]);

        // Answer quality (v2 only).
        $quality = ['high' => 0, 'medium' => 0, 'low' => 0];
        foreach ($rows->where('version', 'v2') as $r) {
            $q = json_decode((string) $r->quality, true);
            if (isset($q['level'], $quality[$q['level']])) {
                $quality[$q['level']]++;
            }
        }

        return view('admin.dna.index', compact('kpi', 'mix', 'riskRows', 'quality') + ['reliability' => self::reliability($byUser)]);
    }

    /**
     * Retake stability for students with two attempts or more (consecutive pairs).
     * A sound behaviour test gives similar results when nothing has changed;
     * pairs within 14 days are the cleanest check, later pairs also show real change.
     */
    private static function reliability($byUser): array
    {
        $out = ['pairs' => 0, 'same_primary' => 0, 'r' => [], 'risk_delta' => [], 'short' => 0, 'short_same' => 0, 'short_r' => []];
        foreach ($byUser as $g) {
            $g = $g->values();
            for ($i = 1; $i < $g->count(); $i++) {
                $a = $g[$i - 1];
                $b = $g[$i];
                $sa = json_decode((string) $a->shares, true) ?: [];
                $sb = json_decode((string) $b->shares, true) ?: [];
                $r = self::pearson(array_map(fn ($l) => (float) ($sa[$l] ?? 0), self::LETTERS), array_map(fn ($l) => (float) ($sb[$l] ?? 0), self::LETTERS));
                $ra = json_decode((string) $a->risks, true) ?: [];
                $rb = json_decode((string) $b->risks, true) ?: [];
                $d = [];
                foreach ($ra as $k => $v) {
                    if (isset($rb[$k])) {
                        $d[] = abs((int) ($rb[$k]['score'] ?? 0) - (int) ($v['score'] ?? 0));
                    }
                }
                $same = $a->primary_style === $b->primary_style;
                $out['pairs']++;
                $out['same_primary'] += $same ? 1 : 0;
                if ($r !== null) {
                    $out['r'][] = $r;
                }
                if ($d) {
                    $out['risk_delta'][] = array_sum($d) / count($d);
                }
                if (strtotime($b->created_at) - strtotime($a->created_at) <= 14 * 86400) {
                    $out['short']++;
                    $out['short_same'] += $same ? 1 : 0;
                    if ($r !== null) {
                        $out['short_r'][] = $r;
                    }
                }
            }
        }
        $mean = fn ($v) => $v ? round(array_sum($v) / count($v), 2) : null;

        return [
            'pairs' => $out['pairs'],
            'same_primary_pct' => $out['pairs'] ? round($out['same_primary'] * 100 / $out['pairs']) : null,
            'mean_r' => $mean($out['r']),
            'mean_risk_delta' => $out['risk_delta'] ? round(array_sum($out['risk_delta']) / count($out['risk_delta']), 1) : null,
            'short' => $out['short'],
            'short_same_pct' => $out['short'] ? round($out['short_same'] * 100 / $out['short']) : null,
            'short_r' => $mean($out['short_r']),
        ];
    }

    private static function pearson(array $x, array $y): ?float
    {
        $n = count($x);
        $mx = array_sum($x) / $n;
        $my = array_sum($y) / $n;
        $sxy = $sxx = $syy = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $sxy += ($x[$i] - $mx) * ($y[$i] - $my);
            $sxx += ($x[$i] - $mx) ** 2;
            $syy += ($y[$i] - $my) ** 2;
        }

        return $sxx > 0 && $syy > 0 ? $sxy / sqrt($sxx * $syy) : null;
    }

    /** Highest risk of one attempt row. */
    public static function top(object $r): array
    {
        $best = ['key' => null, 'score' => 0, 'level' => null];
        foreach (json_decode((string) $r->risks, true) ?: [] as $k => $v) {
            if ((int) ($v['score'] ?? 0) > $best['score']) {
                $best = ['key' => $k, 'score' => (int) $v['score'], 'level' => $v['level'] ?? null];
            }
        }

        return $best;
    }

    // ---------- students ----------

    public function students(Request $request)
    {
        $latestIds = DB::table('disc_assessments')->select(DB::raw('MAX(id) AS id'), 'user_id', DB::raw('COUNT(*) AS attempts'))->groupBy('user_id');
        $q = DB::table('disc_assessments as d')
            ->joinSub($latestIds, 'l', 'l.id', '=', 'd.id')
            ->leftJoin('users as u', 'u.id', '=', 'd.user_id')
            ->leftJoin('journal_books as b', 'b.user_id', '=', 'd.user_id')
            ->select('d.*', 'l.attempts', 'u.name', 'u.email', 'u.phone', DB::raw('COALESCE(b.trades_count, 0) AS journal_trades'))
            ->when($request->filled('q'), function ($w) use ($request) {
                $t = '%'.trim((string) $request->query('q')).'%';
                $w->where(fn ($x) => $x->where('u.name', 'like', $t)->orWhere('u.email', 'like', $t)->orWhere('u.phone', 'like', $t)->orWhere('d.user_id', (int) $request->query('q')));
            })
            ->when(in_array($request->query('profile'), self::LETTERS, true), fn ($w) => $w->where('d.primary_style', $request->query('profile')))
            ->when($request->query('quality') === 'low', fn ($w) => $w->where('d.quality', 'like', '%"low"%'))
            ->orderByDesc('d.created_at');

        $rows = $q->get()->map(function ($r) {
            $t = self::top($r);
            $r->top = $t;

            return $r;
        });
        if (array_key_exists((string) $request->query('risk'), self::RISKS)) {
            $rows = $rows->filter(fn ($r) => $r->top['key'] === $request->query('risk'));
        }
        if ($request->query('filter') === 'high') {
            $rows = $rows->filter(fn ($r) => $r->top['score'] >= 65);
        }
        if ($request->query('sort') === 'risk') {
            $rows = $rows->sortByDesc(fn ($r) => $r->top['score']);
        }

        $page = max(1, (int) $request->query('page', 1));
        $paged = new \Illuminate\Pagination\LengthAwarePaginator($rows->slice(($page - 1) * 30, 30)->values(), $rows->count(), 30, $page, ['path' => $request->url(), 'query' => $request->query()]);

        return view('admin.dna.students', ['rows' => $paged, 'risks' => self::RISKS, 'names' => self::NAMES]);
    }

    public function show(int $user)
    {
        $student = DB::table('users')->where('id', $user)->first(['id', 'name', 'email', 'phone', 'country', 'created_at']);
        abort_unless($student, 404);
        $attempts = DB::table('disc_assessments')->where('user_id', $user)->orderByDesc('id')->get();
        abort_if($attempts->isEmpty(), 404);
        $latest = $attempts->first();
        $risks = json_decode((string) $latest->risks, true) ?: [];
        uasort($risks, fn ($a, $b) => ($b['score'] ?? 0) <=> ($a['score'] ?? 0));

        $measured = null;
        try {
            $measured = TradingDnaMeasured::forUser($user);
        } catch (\Throwable $e) {
            report($e);
        }
        $compare = [];
        foreach ((array) ($measured['risks'] ?? []) as $k => $m) {
            if (! isset($risks[$k])) {
                continue;
            }
            $said = (int) ($risks[$k]['habit'] ?? 0) * 25;
            $d = (int) $m['score'] - $said;
            $compare[] = ['key' => $k, 'said' => self::FREQ[(int) ($risks[$k]['habit'] ?? 0)] ?? '—', 'did' => (int) $m['score'], 'base' => $m['base'] ?? null,
                'verdict' => $d >= 25 ? 'worse' : ($d <= -25 ? 'better' : 'match')];
        }
        usort($compare, fn ($a, $b) => ($b['did'] - 0) <=> ($a['did'] - 0));

        return view('admin.dna.show', compact('student', 'attempts', 'latest', 'risks', 'measured', 'compare')
            + ['riskNames' => self::RISKS, 'names' => self::NAMES, 'freq' => self::FREQ]);
    }
}
