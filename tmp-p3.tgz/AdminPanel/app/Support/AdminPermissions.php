<?php

namespace App\Support;

use Illuminate\Support\Str;

/**
 * The admin panel's permission model (Issue 51 — Roles & Permissions).
 *
 * A permission is "<module>.<action>". Every admin route is mapped to a
 * module by its route NAME (patterns below), and to an action by the route's
 * last name segment and HTTP verb. That lets one middleware (AdminAccess)
 * enforce permissions on all ~250 admin routes — including the legacy
 * nwidart modules — without touching each module's route file.
 *
 * A route that matches no module falls into "settings", so anything added
 * later is locked to people who may change settings until it is mapped.
 */
final class AdminPermissions
{
    public const ACTIONS = [
        'view' => 'View',
        'create' => 'Create',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'approve' => 'Approve / publish',
    ];

    /** Reachable by every signed-in admin, whatever the role. */
    public const ALWAYS = [
        'admin.login', 'admin.store-login', 'admin.store-register', 'admin.logout',
        'admin.edit-profile', 'admin.profile-update', 'admin.update-password',
        'admin.search', 'admin.dashboard', 'admin.',
    ];

    /**
     * module => [label, actions, route-name patterns]. Order matters: the
     * first matching module wins, so the specific patterns sit above broad
     * ones (course payments above courses).
     */
    public const MODULES = [
        'dashboard' => ['Dashboard & analytics', ['view'], ['admin.analytics']],
        'payments' => ['Payments & revenue', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.payment.*', 'admin.course-pending-payment', 'admin.course-rejected-payment',
            'admin.enrollment-payment-*', 'admin.earning-and-revenue', 'admin.revenue*', 'admin.coupon*',
        ]],
        'students' => ['Students & memberships', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.user-*', 'admin.pending-user', 'admin.student-progress*', 'admin.course-enrollment*',
        ]],
        'instructors' => ['Instructors & withdrawals', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.seller-*', 'admin.pending-seller', 'admin.withdraw-*',
        ]],
        'question_bank' => ['Question bank', ['view', 'create', 'edit', 'delete', 'approve'], ['admin.question-bank*']],
        'courses' => ['Courses & curriculum', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.courses.*', 'admin.course-*', 'admin.courses-*', 'admin.pending-course', 'admin.rejected-course',
            'admin.active-course', 'admin.submit-for-review', 'admin.category.*', 'admin.courselanguage.*',
            'admin.courselevel.*', 'admin.quiz-questions.*',
        ]],
        'academy' => ['Homework, bonus lessons, live sessions & certificates', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.homework*', 'admin.bonus-lessons*', 'admin.live-sessions*', 'admin.certificatebuilder*',
            'admin.certificate-builder*',
        ]],
        'challenges' => ['Trading challenges', ['view', 'create', 'edit', 'approve'], ['admin.challenges.*']],
        'mentorship' => ['Mentorship bookings', ['view', 'edit', 'approve'], ['admin.mentorship*']],
        // 2026-11-20 — Admin → Trading Journal (books, connections, mentor notes, reports, settings).
        'journal' => ['Trading journal', ['view', 'edit', 'delete'], ['admin.journal*']],
        // 2026-11-20 — Admin → Trading DNA (DISC results, reliability, mentor view).
        'dna' => ['Trading DNA (DISC)', ['view'], ['admin.dna*']],
        'testimonials' => ['Testimonials', ['view', 'create', 'edit', 'delete', 'approve'], ['admin.testimonial*']],
        'faq' => ['FAQ / Q&A', ['view', 'create', 'edit', 'delete', 'approve'], ['admin.faq*']],
        'media' => ['Featured & Media', ['view', 'create', 'edit', 'delete', 'approve'], ['admin.media*']],
        'reviews' => ['Ratings & reviews', ['view', 'edit', 'delete', 'approve'], ['admin.reviews*']],
        'notifications' => ['Notifications & newsletter', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.notifications*', 'admin.newsletter-*', 'admin.send-newsletter-email',
        ]],
        'announcements' => ['Announcements', ['view', 'create', 'edit', 'delete'], ['admin.announcements*']],
        'blog' => ['Blog & comments', ['view', 'create', 'edit', 'delete', 'approve'], [
            'admin.blog*', 'admin.comment-list', 'admin.show-comment', 'admin.delete-blog-comment',
        ]],
        'pages' => ['Website pages & SEO', ['view', 'create', 'edit', 'delete'], [
            'admin.custom-page.*', 'admin.privacy-policy', 'admin.update-privacy-policy', 'admin.terms-conditions',
            'admin.update-terms-conditions', 'admin.front-end.*', 'admin.footer', 'admin.update-footer',
            'admin.partner.*', 'admin.contact-us', 'admin.update-contact-us', 'admin.breadcrumb*',
            'admin.seo-setting', 'admin.update-seo-setting',
        ]],
        'support' => ['Support tickets & messages', ['view', 'edit', 'delete'], [
            'admin.support-ticket*', 'admin.contact-message*', 'admin.show-message', 'admin.delete-contact-message',
        ]],
        'referrals' => ['Referrals', ['view'], ['admin.referrals*']],
        // Telegram bot admin (botadmin.*) — Exness IB partner-change retention (issue 57).
        'retention' => ['IB partner-change retention (bot admin)', ['view', 'edit', 'approve'], ['admin.retention*']],
        'audit_logs' => ['Security & audit logs', ['view'], ['admin.audit-logs*']],
        'roles' => ['Roles, permissions & admin accounts', ['view', 'create', 'edit', 'delete'], ['admin.roles*', 'admin.admins*']],
        'settings' => ['System settings', ['view', 'edit'], []],
    ];

    /** @return array<string,string> permission => human label */
    public static function all(): array
    {
        $out = ['dashboard.view' => 'Dashboard & analytics — View'];
        foreach (self::MODULES as $module => [$label, $actions]) {
            foreach ($actions as $action) {
                $out["{$module}.{$action}"] = $label.' — '.self::ACTIONS[$action];
            }
        }

        return $out;
    }

    public static function moduleForRoute(?string $name): string
    {
        if ($name === null || $name === 'admin.dashboard' || $name === 'admin.') {
            return 'dashboard';
        }
        foreach (self::MODULES as $module => [, , $patterns]) {
            foreach ($patterns as $pattern) {
                if (Str::is($pattern, $name)) {
                    return $module;
                }
            }
        }

        return 'settings';
    }

    public static function actionForRoute(?string $name, string $method): string
    {
        $last = $name ? Str::afterLast($name, '.') : '';
        $method = strtoupper($method);

        if (preg_match('/(destroy|delete|remove|clear)/', $last) || $method === 'DELETE') {
            return 'delete';
        }
        if (preg_match('/(approv|reject|publish|status|moderate|hide|verify|freeze|finalize|resolve|override|retry|resync|send|dispatch)/', $last)) {
            return 'approve';
        }
        if ($method === 'GET' || $method === 'HEAD') {
            if ($last === 'create') {
                return 'create';
            }
            if ($last === 'edit') {
                return 'edit';
            }

            return 'view';
        }
        if ($last === 'store' || Str::startsWith($last, 'store')) {
            return 'create';
        }

        return 'edit';
    }

    /** The permission a route requires, or null when it is always reachable. */
    public static function forRoute(?string $name, string $method): ?string
    {
        if ($name === null || in_array($name, self::ALWAYS, true)) {
            return null;
        }

        $module = self::moduleForRoute($name);
        $action = self::actionForRoute($name, $method);
        $actions = self::MODULES[$module][1] ?? ['view', 'edit'];

        // A module without a dedicated action folds it into the nearest one
        // it does have: create/delete/approve → edit → view.
        if (! in_array($action, $actions, true)) {
            $action = in_array('edit', $actions, true) && $action !== 'view' ? 'edit' : 'view';
        }

        return "{$module}.{$action}";
    }

    public static function moduleLabel(?string $module): string
    {
        return self::MODULES[$module][0] ?? Str::headline((string) $module);
    }
}
