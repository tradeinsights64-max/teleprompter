<?php
use Illuminate\Support\Facades\DB;
$T = ['flow.welcome_back' => [
 'en' => "Welcome back 🎉 We saw your new trade — your VIP seat is open again.\n\nTap the button below to rejoin.",
 'am' => "እንኳን ደህና መጡ 🎉 አዲሱን tradeዎን አይተናል — VIP ቦታዎ በድጋሚ ተከፍቷል።\n\nለመመለስ ከታች ያለውን button ይጫኑ።"]];
foreach ($T as $key => $langs) foreach ($langs as $lang => $body) {
  $q = DB::table('message_templates')->where('key',$key)->where('language',$lang);
  if ($q->exists()) { $q->update(['body'=>$body]); echo "updated $key $lang\n"; continue; }
  $base = (array) DB::table('message_templates')->where('key','flow.verified')->where('language',$lang)->first();
  if (!$base) { echo "no base $lang\n"; continue; }
  unset($base['id']); $base['key']=$key; $base['body']=$body; foreach (['created_at','updated_at'] as $c) if (array_key_exists($c,$base)) $base[$c]=now();
  if (array_key_exists('label',$base)) $base['label']='Welcome back after inactivity removal';
  DB::table('message_templates')->insert($base); echo "created $key $lang\n";
}
$q = app(App\Services\Exness\CheckQueue::class)->eligible();
echo 'daily-check members: '.$q->count()."\n";
Cache::flush();
