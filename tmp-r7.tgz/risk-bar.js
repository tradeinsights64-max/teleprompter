/* Trade Insight — risk warning bar at the top of every page (2026-11-20).
 * Lives outside the React root (inserted before #root), so the SPA is untouched.
 * Follows the EN/አማ switch (localStorage "ti-ui-lang"). */
(function () {
  'use strict';
  var T = {
    en: '⚠️ <b>Trading carries high risk.</b> You can lose some or all of your money. Trade Insight is education only — not financial advice. <a href="/risk-disclosure/">Read the risk disclosure →</a>',
    am: '⚠️ <b>Trading ከፍተኛ risk አለው።</b> ገንዘብዎን በከፊል ወይም ሙሉ በሙሉ ሊያጡ ይችላሉ። Trade Insight ትምህርት ብቻ ነው — የፋይናንስ ምክር አይደለም። <a href="/risk-disclosure/#am">የrisk ማሳሰቢያውን ያንብቡ →</a>'
  };
  function lang() { try { return localStorage.getItem('ti-ui-lang') === 'am' ? 'am' : 'en'; } catch (e) { return 'en'; } }
  function build() {
    if (document.getElementById('ti-risk-bar')) return;
    var bar = document.createElement('div');
    bar.id = 'ti-risk-bar';
    bar.setAttribute('role', 'note');
    bar.style.cssText = 'background:#fff4e0;color:#3d2a00;border-bottom:1px solid #f3c77a;font:500 13.5px/1.45 Outfit,"Noto Sans Ethiopic",system-ui,sans-serif;padding:8px 16px;text-align:center';
    var css = document.createElement('style');
    css.textContent = '#ti-risk-bar a{color:#0b0f3b;font-weight:700;text-decoration:underline;white-space:nowrap}#ti-risk-bar b{font-weight:700}';
    document.head.appendChild(css);
    var cur = '';
    function render() { var l = lang(); if (l !== cur) { cur = l; bar.innerHTML = T[l]; } }
    render();
    var root = document.getElementById('root');
    if (root && root.parentNode) root.parentNode.insertBefore(bar, root); else document.body.insertBefore(bar, document.body.firstChild);
    window.addEventListener('storage', render);
    document.addEventListener('click', function () { setTimeout(render, 60); }, true);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
