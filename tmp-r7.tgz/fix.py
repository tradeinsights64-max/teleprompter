import os,re,shutil,json
os.chdir('/var/www/TradeInsightProduction/TD/StudentPortal'); B='/root/backups/risk-20261120'; os.makedirs(B,exist_ok=True)
def rd(p): return open(p,encoding='utf-8').read()
def wr(p,s): open(p,'w',encoding='utf-8').write(s)
def q(x): return json.dumps(x,ensure_ascii=False)
# Home: bootcamp CTA -> Choose your path (offers page)
s=rd('assets/Home-ti1120h.js')
n1=s.count('"Apply to the bootcamp"'); s=s.replace('"Apply to the bootcamp"','"🎯 Choose your path"')
n2=s.count('to:l?"/courses":"/register"'); s=s.replace('to:l?"/courses":"/register"','to:l?"/courses":"/mentorship"')
wr('assets/Home-ti1120i.js',s); print('home',n1,n2)
# Mentorship: education line on paid offers
m=rd('assets/Mentorship-ti1120d.js')
EDU=' Education only — no guaranteed profits.'; EDUAM=' ለትምህርት ብቻ — የትርፍ ዋስትና የለም።'
olds=['A mentor assigned to you alone, with a roadmap built around where you actually are.','The same courses and VIP if the free option is not available in your country. Pay by bank transfer, Telebirr or another way — we help you.']
a=rd('i18n/am.js'); shutil.copy2('i18n/am.js',B+'/am.js')
for o in olds:
    print('mentor', m.count(q(o)))
    m=m.replace(q(o),q(o+EDU))
    mm=re.search(re.escape(q(o))+r'\s*:\s*"((?:[^"\\]|\\.)*)"',a)
    if mm and q(o+EDU) not in a:
        a=a.replace(mm.group(0), mm.group(0)+', '+q(o+EDU)+': '+q(json.loads('"'+mm.group(1)+'"')+EDUAM),1); print('am pair added')
wr('assets/Mentorship-ti1120e.js',m)
wr('i18n/am.js',a)
p='assets/index-BaObQ8fx.js'; t=rd(p); shutil.copy2(p,B+'/index-BaObQ8fx.js')
t=t.replace('Home-ti1120h.js','Home-ti1120i.js').replace('Mentorship-ti1120d.js','Mentorship-ti1120e.js'); wr(p,t)
print('refs', t.count('Home-ti1120i.js'), t.count('Mentorship-ti1120e.js'))
# risk bar + page
shutil.copy2('/root/r7/risk-bar.js','i18n/risk-bar.js')
os.makedirs('risk-disclosure',exist_ok=True); shutil.copy2('/root/r7/page/index.html','risk-disclosure/index.html')
h=rd('index.html'); shutil.copy2('index.html',B+'/index.html')
if 'risk-bar.js' not in h: h=h.replace('</body>','  <script src="/i18n/risk-bar.js?v=1"></script>\n</body>',1)
h=re.sub(r'am\.js\?v=[0-9a-z]+','am.js?v=20261120k',h); wr('index.html',h); print('bar tag', 'risk-bar.js' in h)
