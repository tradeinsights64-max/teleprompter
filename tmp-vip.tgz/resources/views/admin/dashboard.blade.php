<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Dashboard') }}</h2>
            <x-period-tabs :period="$period" route="dashboard" />
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <x-flash />

            {{-- Overview cards. Each carries an icon that describes the metric,
                 tinted by what the number means: green good, amber waiting,
                 red needs attention. Activity cards count from the start of
                 the selected period; snapshot cards show the current state. --}}
            @php
                $rangeLabel = match ($period) {
                    'weekly' => __('Last 7 days'),
                    'monthly' => __('Last 30 days'),
                    'yearly' => __('Last 12 months'),
                    'all' => __('All time'),
                    default => __('Today'),
                };
                $snapshotLabel = __('Current');
            @endphp
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <x-stat-card icon="members" tone="brand"
                             :label="__('Total members')" :value="number_format($cards['total_members'])" :sub="$snapshotLabel" />
                <x-stat-card icon="start" tone="muted"
                             :label="__('Members started')" :value="number_format($cards['started_today'])" :sub="$rangeLabel" />
                <x-stat-card icon="verified" tone="good"
                             :label="__('Members verified')" :value="number_format($cards['verified_today'])" :sub="$rangeLabel" />
                <x-stat-card icon="joined" tone="good"
                             :label="__('Members joined')" :value="number_format($cards['joined_today'])" :sub="$rangeLabel" />
                <x-stat-card icon="vip" tone="brand"
                             :label="__('VIP access given')" :value="number_format($cards['vip_active'])" :sub="$snapshotLabel" />
                <x-stat-card icon="vip" tone="good"
                             :label="__('Traded last 30 days')" :value="number_format($cards['traded_30d'] ?? 0)" :sub="__('VIP members')" />
                <x-stat-card icon="pending" tone="warn"
                             :label="__('Pending verification')" :value="number_format($cards['pending_verification'])" :sub="$snapshotLabel" />
                <x-stat-card icon="sent" tone="muted"
                             :label="__('Messages sent')" :value="number_format($cards['messages_sent_today'])" :sub="$rangeLabel" />
                <x-stat-card icon="failed" :tone="$cards['messages_failed_today'] > 0 ? 'bad' : 'muted'"
                             :label="__('Messages failed/blocked')" :value="number_format($cards['messages_failed_today'])" :sub="$rangeLabel" />
            </div>

            {{-- Exness client book --}}
            @if (! empty($clientStats))
                <div class="bg-white rounded-lg border border-gray-200 p-4">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-sm font-medium text-gray-700">{{ __('Exness client book') }}</h3>
                        <a href="{{ route('admin.clients.index') }}" class="text-sm text-blue-700 hover:underline">{{ __('View all') }} →</a>
                    </div>
                    <div class="grid grid-cols-2 md:grid-cols-6 gap-4">
                        @foreach ([
                            ['label' => __('Total clients'), 'value' => $clientStats['total'], 'class' => 'text-gray-900', 'tab' => 'all', 'icon' => 'clients', 'tone' => 'muted'],
                            ['label' => __('Active'), 'value' => $clientStats['active'], 'class' => 'text-green-700', 'tab' => 'active', 'icon' => 'active', 'tone' => 'good'],
                            ['label' => __('Inactive'), 'value' => $clientStats['inactive'], 'class' => 'text-amber-700', 'tab' => 'inactive', 'icon' => 'inactive', 'tone' => 'warn'],
                            ['label' => __('Left'), 'value' => $clientStats['left'], 'class' => 'text-gray-500', 'tab' => 'left', 'icon' => 'left', 'tone' => 'muted'],
                            ['label' => __('Eligible for VIP'), 'value' => $clientStats['eligible'], 'class' => 'text-[#C25400]', 'tab' => 'eligible', 'icon' => 'eligible', 'tone' => 'brand'],
                            ['label' => __('Email known'), 'value' => $clientStats['with_email'], 'class' => 'text-gray-900', 'tab' => 'with_email', 'icon' => 'email', 'tone' => 'muted'],
                        ] as $card)
                            <a href="{{ route('admin.clients.index', ['tab' => $card['tab']]) }}"
                               class="rounded-lg border border-gray-100 p-3 hover:border-[#FF6F00] hover:bg-[#FFF3E8]/40 transition">
                                <x-stat-card :icon="$card['icon']" :tone="$card['tone']"
                                             :label="$card['label']"
                                             :value="number_format($card['value'])"
                                             class="!border-0 !bg-transparent !p-0" />
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif

            {{-- Growth charts --}}
            <div class="grid md:grid-cols-2 gap-4">
                <x-chart-card :title="__('Onboarding — starts vs verified vs joined')" :spec="[
                    'type' => 'line',
                    'labels' => $growth['starts']['labels'],
                    'datasets' => [
                        ['label' => __('Started'), 'values' => $growth['starts']['values']],
                        ['label' => __('Verified'), 'values' => $growth['registrations']['values']],
                        ['label' => __('Joined group'), 'values' => $growth['joins']['values']],
                    ],
                ]" />
                <x-chart-card :title="__('Messages delivered')" :spec="[
                    'type' => 'bar',
                    'labels' => $growth['messages_sent']['labels'],
                    'datasets' => [
                        ['label' => __('Sent'), 'values' => $growth['messages_sent']['values']],
                    ],
                ]" />
                <x-chart-card :title="__('Deposits (USD)')" :spec="[
                    'type' => 'bar',
                    'labels' => $growth['deposits']['labels'],
                    'datasets' => [
                        ['label' => __('Deposits'), 'values' => $growth['deposits']['values']],
                    ],
                ]" />
                <x-chart-card :title="__('Trading volume (lots)')" :spec="[
                    'type' => 'line',
                    'labels' => $growth['volume_lots']['labels'],
                    'datasets' => [
                        ['label' => 'Lots', 'values' => $growth['volume_lots']['values']],
                    ],
                ]" />
            </div>

            <div class="grid md:grid-cols-3 gap-4">
                {{-- Members by status --}}
                <div class="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 class="text-sm font-medium text-gray-700 mb-3">{{ __('Members by status') }}</h3>
                    <table class="w-full text-sm">
                        @foreach ($byStatus as $status => $count)
                            <tr class="border-t border-gray-100">
                                <td class="py-1.5 text-gray-600">
                                    <a class="hover:underline font-mono text-xs" href="{{ route('admin.members.index', ['status' => $status]) }}">{{ $status }}</a>
                                </td>
                                <td class="py-1.5 text-right font-medium tabular-nums">{{ number_format($count) }}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>

                {{-- Work queues --}}
                <div class="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 class="text-sm font-medium text-gray-700 mb-3">{{ __('Work queues') }}</h3>
                    <table class="w-full text-sm">
                        @foreach ([
                            'unfunded_over_48h' => __('Unfunded > 48h'),
                            'inactivity_warned' => __('Inactivity warned'),
                            'due_for_removal' => __('Due for removal'),
                            'discipline_flagged' => __('Discipline flagged'),
                            'partner_change_pending' => __('Partner change pending'),
                            'verification_failed' => __('Verification failed'),
                            'support_escalations' => __('Support escalations'),
                        ] as $key => $label)
                            <tr class="border-t border-gray-100">
                                <td class="py-1.5 text-gray-600">{{ $label }}</td>
                                <td class="py-1.5 text-right font-medium tabular-nums {{ $queues[$key] > 0 ? 'text-amber-700' : '' }}">
                                    {{ number_format($queues[$key]) }}
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>

                {{-- Funnel --}}
                <div class="bg-white rounded-lg border border-gray-200 p-4">
                    <h3 class="text-sm font-medium text-gray-700 mb-3">{{ __('Onboarding funnel') }}</h3>
                    <table class="w-full text-sm">
                        @foreach ($funnel as $stage)
                            <tr class="border-t border-gray-100">
                                <td class="py-1.5 text-gray-600">{{ __(str_replace('_', ' ', $stage['stage'])) }}</td>
                                <td class="py-1.5 text-right font-medium tabular-nums">{{ number_format($stage['count']) }}</td>
                                <td class="py-1.5 text-right text-xs text-gray-500 tabular-nums w-14">{{ $stage['pct_of_start'] }}%</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>

            {{-- High volume leaderboard --}}
            <div class="bg-white rounded-lg border border-gray-200 p-4">
                <h3 class="text-sm font-medium text-gray-700 mb-3">{{ __('High-volume leaderboard (30d lots)') }}</h3>
                @if ($leaderboard->isEmpty())
                    <p class="text-sm text-gray-500">{{ __('No volume recorded yet — populated by the trade sync jobs.') }}</p>
                @else
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left text-xs uppercase text-gray-500">
                                <th class="py-1.5">#</th><th>{{ __('Member') }}</th><th>{{ __('Account') }}</th>
                                <th class="text-right">{{ __('Lots (30d)') }}</th><th class="text-right">{{ __('Last trade') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($leaderboard as $i => $m)
                                <tr class="border-t border-gray-100">
                                    <td class="py-1.5 text-gray-500">{{ $i + 1 }}</td>
                                    <td><a class="text-blue-700 hover:underline" href="{{ route('admin.members.show', $m) }}">{{ $m->first_name ?? $m->telegram_username ?? $m->telegram_id }}</a></td>
                                    <td class="text-gray-600">{{ $m->exness_account_number }}</td>
                                    <td class="text-right font-medium tabular-nums">{{ number_format($m->lot_volume_30d, 2) }}</td>
                                    <td class="text-right text-gray-500 tabular-nums">{{ $m->last_trade_at?->format('Y-m-d') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
