<?php

namespace App\Services;

use App\Enums\MemberStatus;
use App\Models\Deposit;
use App\Models\Event;
use App\Models\ExnessClient;
use App\Models\Member;
use App\Models\NotificationLog;
use App\Models\Trade;
use App\Models\VerificationAttempt;
use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Aggregations for the dashboard, the analytics/report pages, and the
 * Telegram group daily summary. Everything is computed from local tables,
 * never live broker calls (brief section 12).
 *
 * Periods: daily (today, hourly buckets), weekly (last 7 days), monthly
 * (last month, daily buckets), yearly (last year, monthly buckets),
 * all (everything since the first member, monthly buckets).
 */
class AnalyticsService
{
    public function __construct(private readonly Settings $settings) {}

    // ------------------------------------------------------------------
    // Overview
    // ------------------------------------------------------------------

    /** @return array<string, int> status => count */
    public function membersByStatus(): array
    {
        $counts = Member::query()
            ->select('status', DB::raw('COUNT(*) as c'))
            ->groupBy('status')
            ->pluck('c', 'status')
            ->all();

        $out = [];
        foreach (MemberStatus::cases() as $case) {
            $out[$case->value] = (int) ($counts[$case->value] ?? 0);
        }

        return $out;
    }

    /**
     * The Exness client book (everyone under the partner link), as opposed to
     * Telegram members who have gone through the bot.
     */
    public function clientStats(): array
    {
        if (! Schema::hasTable('exness_clients')) {
            return [];
        }

        $minDeposit = (float) $this->settings->int('flow.min_deposit_usd', 50);

        return [
            'total' => ExnessClient::count(),
            'active' => ExnessClient::where('status', 'ACTIVE')->count(),
            'inactive' => ExnessClient::where('status', 'INACTIVE')->count(),
            'left' => ExnessClient::where('status', 'LEFT')->count(),
            'eligible' => ExnessClient::eligible($minDeposit)->count(),
            'with_email' => ExnessClient::whereNotNull('email')->count(),
        ];
    }

    /**
     * Overview cards. The *_today keys keep their historical names (the
     * Telegram daily report relies on them) but count from the start of the
     * given period — today, last 7 days, last 30 days, last 12 months, or
     * all time — so the dashboard cards follow the period tabs. Snapshot
     * cards (totals and status counts) have no time dimension.
     */
    public function overviewCards(string $period = 'daily'): array
    {
        // null start = no lower bound (all time).
        $start = $period === 'all' ? null : $this->periodSpec($period)[1];

        $since = fn ($query, string $column) => $start === null
            ? $query
            : $query->where($column, '>=', $start);

        return [
            'period' => $period,
            'total_members' => Member::count(),
            'started_today' => $since(Member::query(), 'started_at')->count(),
            'verified_today' => $since(Member::query(), 'verified_at')->count(),
            'joined_today' => $since(Member::query(), 'joined_group_at')->count(),
            'vip_active' => Member::where('status', MemberStatus::VipActive)->count(),
            'traded_30d' => Member::whereIn('status', [MemberStatus::VipActive, MemberStatus::InactiveWarned])
                ->where(fn ($q) => $q->where('last_trade_at', '>=', now()->subDays(30))->orWhere('commission_30d', '>', 0))
                ->count(),
            'pending_verification' => Member::whereIn('status', [MemberStatus::AwaitingEmail, MemberStatus::VerificationFailed])->count(),
            'messages_sent_today' => $since(NotificationLog::where('status', 'sent'), 'sent_at')->count(),
            'messages_failed_today' => $since(NotificationLog::whereIn('status', ['failed', 'blocked']), 'updated_at')->count(),
        ];
    }

    // ------------------------------------------------------------------
    // Work queues (brief section 12)
    // ------------------------------------------------------------------

    public function queues(): array
    {
        $unfundedHours = $this->settings->int('followup.unfunded_delay_hours', 48);
        $kickDays = $this->settings->int('activity.kick_days', 20);

        return [
            'unfunded_over_48h' => Member::where('status', MemberStatus::RegisteredUnfunded)
                ->where('registered_at', '<=', now()->subHours($unfundedHours))
                ->count(),
            'inactivity_warned' => Member::where('status', MemberStatus::InactiveWarned)->count(),
            'due_for_removal' => Member::where('status', MemberStatus::InactiveWarned)
                ->whereNotNull('last_trade_at')
                ->where('last_trade_at', '<=', now()->subDays($kickDays))
                ->count(),
            'discipline_flagged' => Member::whereNotNull('discipline_warning_sent_at')->count(),
            'partner_change_pending' => Member::where('status', MemberStatus::PartnerChangePending)->count(),
            'verification_failed' => Member::where('status', MemberStatus::VerificationFailed)->count(),
            'support_escalations' => Event::whereIn('event_type', [
                'verification.escalated_to_support',
                'verification.duplicate_email',
                'verification.api_error_exhausted',
            ])->count(),
        ];
    }

    /** @return Collection<int, Member> */
    public function highVolumeLeaderboard(): Collection
    {
        return Member::query()
            ->where('lot_volume_30d', '>', 0)
            ->orderByDesc('lot_volume_30d')
            ->limit($this->settings->int('volume.top_n', 20))
            ->get();
    }

    // ------------------------------------------------------------------
    // Time series (daily / monthly / yearly)
    // ------------------------------------------------------------------

    /**
     * Generic bucketed time-series aggregation.
     *
     * @param  string  $period  daily|monthly|yearly
     * @return array{labels: string[], values: float[]}
     */
    public function series(string $table, string $column, string $period, array $where = [], string $aggregate = 'COUNT(*)'): array
    {
        [$format, $start, $buckets] = $this->periodSpec($period);

        /*
         | Buckets are cut with MySQL's DATE_FORMAT, so they follow whatever
         | is stored. Since the merge that is UTC, shared with the backend.
         |
         | Rows written BEFORE the merge were stored in EAT (UTC+3), so
         | historical hourly buckets are shifted by three hours against
         | anything written since. Day-scale figures are unaffected in any way
         | that matters; the hourly view of pre-merge days is the one place to
         | be careful reading.
         */
        $query = DB::table($table)
            ->selectRaw("DATE_FORMAT({$column}, '{$format}') as bucket, {$aggregate} as v")
            ->whereNotNull($column)
            ->where($column, '>=', $start);

        foreach ($where as $clause) {
            $query->where(...$clause);
        }

        $rows = $query->groupBy('bucket')->pluck('v', 'bucket')->all();

        $labels = [];
        $values = [];
        foreach ($buckets as $bucket) {
            $labels[] = $bucket;
            $values[] = (float) ($rows[$bucket] ?? 0);
        }

        return ['labels' => $labels, 'values' => $values];
    }

    /**
     * The core growth datasets (brief section 12) for one period.
     */
    public function growth(string $period): array
    {
        return [
            'starts' => $this->series('members', 'started_at', $period),
            'registrations' => $this->series('members', 'verified_at', $period),
            'joins' => $this->series('members', 'joined_group_at', $period),
            /*
             | Table names come from the models, not from literals.
             |
             | The merge renamed `deposits` and `trades` to `member_deposits`
             | and `member_trades`, because in the shared database those bare
             | names read as though they belonged to the challenge engine. The
             | models were updated; these two literals were not, and since they
             | go through the query builder rather than Eloquent nothing caught
             | it until the dashboard 500'd. Asking the model removes the class
             | of bug rather than this instance of it.
             */
            'deposits' => $this->series((new Deposit)->getTable(), 'occurred_at', $period, [['type', '=', 'deposit']], 'COALESCE(SUM(amount),0)'),
            'volume_lots' => $this->series((new Trade)->getTable(), 'close_at', $period, [], 'COALESCE(SUM(lots),0)'),
            'messages_sent' => $this->series('notifications_log', 'sent_at', $period, [['status', '=', 'sent']]),
        ];
    }

    /**
     * Bot/user actions categorized by event type over a period --
     * the detailed workflow report by transaction/action type.
     *
     * @return array<string, array{labels: string[], values: int[]}>
     */
    public function actionsByCategory(string $period): array
    {
        [$format, $start, $buckets] = $this->periodSpec($period);

        $rows = Event::query()
            ->selectRaw("SUBSTRING_INDEX(event_type, '.', 1) as category, DATE_FORMAT(created_at, '{$format}') as bucket, COUNT(*) as c")
            ->where('created_at', '>=', $start)
            ->groupBy('category', 'bucket')
            ->get();

        $out = [];
        foreach ($rows->groupBy('category') as $category => $group) {
            $byBucket = $group->pluck('c', 'bucket')->all();
            $out[$category] = [
                'labels' => $buckets,
                'values' => array_map(fn ($b) => (int) ($byBucket[$b] ?? 0), $buckets),
            ];
        }

        ksort($out);

        return $out;
    }

    /** Raw event-type counts for a period (table view). */
    public function actionTypeCounts(string $period): array
    {
        [, $start] = $this->periodSpec($period);

        return Event::query()
            ->selectRaw('event_type, actor_type, COUNT(*) as c')
            ->where('created_at', '>=', $start)
            ->groupBy('event_type', 'actor_type')
            ->orderByDesc('c')
            ->get()
            ->map(fn ($r) => ['event_type' => $r->event_type, 'actor_type' => $r->actor_type, 'count' => (int) $r->c])
            ->all();
    }

    /** Verification outcomes breakdown for a period. */
    public function verificationOutcomes(string $period): array
    {
        [, $start] = $this->periodSpec($period);

        $counts = VerificationAttempt::query()
            ->selectRaw('outcome, COUNT(*) as c')
            ->where('created_at', '>=', $start)
            ->groupBy('outcome')
            ->pluck('c', 'outcome')
            ->all();

        return array_map('intval', array_merge(
            ['matched' => 0, 'not_found' => 0, 'invalid_format' => 0, 'api_error' => 0, 'duplicate' => 0],
            $counts,
        ));
    }

    /** Message delivery breakdown for a period. */
    public function messageOutcomes(string $period): array
    {
        [, $start] = $this->periodSpec($period);

        $counts = NotificationLog::query()
            ->selectRaw('status, COUNT(*) as c')
            ->where('created_at', '>=', $start)
            ->groupBy('status')
            ->pluck('c', 'status')
            ->all();

        return array_map('intval', array_merge(
            ['sent' => 0, 'failed' => 0, 'blocked' => 0, 'queued' => 0],
            $counts,
        ));
    }

    // ------------------------------------------------------------------
    // Onboarding workflow funnel
    // ------------------------------------------------------------------

    /**
     * started -> socials confirmed -> email submitted -> verified -> invited
     * -> joined, with per-stage conversion from the first stage.
     */
    public function funnel(string $period): array
    {
        [, $start] = $this->periodSpec($period);

        $stages = [
            'started' => Member::where('started_at', '>=', $start)->count(),
            'socials_confirmed' => Member::where('socials_confirmed_at', '>=', $start)->count(),
            'email_submitted' => VerificationAttempt::where('created_at', '>=', $start)->distinct('member_id')->count('member_id'),
            'verified' => Member::where('verified_at', '>=', $start)->count(),
            'invited' => Event::where('event_type', 'invite.issued')->where('created_at', '>=', $start)->distinct('member_id')->count('member_id'),
            'joined' => Member::where('joined_group_at', '>=', $start)->count(),
        ];

        $base = max(1, $stages['started']);

        $out = [];
        $prev = null;
        foreach ($stages as $stage => $count) {
            $out[] = [
                'stage' => $stage,
                'count' => $count,
                'pct_of_start' => round($count / $base * 100, 1),
                'drop_from_prev' => $prev !== null ? max(0, $prev - $count) : 0,
            ];
            $prev = $count;
        }

        return $out;
    }

    // ------------------------------------------------------------------
    // Daily summary for the Telegram admin group
    // ------------------------------------------------------------------

    public function dailySummaryData(): array
    {
        return [
            'date' => CarbonImmutable::now(config('app.display_timezone'))->format('Y-m-d'),
            'cards' => $this->overviewCards(),
            'queues' => $this->queues(),
            'verification' => $this->verificationOutcomes('daily'),
        ];
    }

    // ------------------------------------------------------------------

    public const PERIODS = ['daily', 'weekly', 'monthly', 'yearly', 'all'];

    /**
     * @return array{0: string, 1: CarbonImmutable, 2: string[]} [mysql format, start, bucket labels]
     */
    private function periodSpec(string $period): array
    {
        $now = CarbonImmutable::now(config('app.display_timezone'));

        return match ($period) {
            // Last 7 days, one bucket per day.
            'weekly' => [
                '%Y-%m-%d',
                $now->subDays(6)->startOfDay(),
                collect(range(6, 0))->map(fn ($i) => $now->subDays($i)->format('Y-m-d'))->all(),
            ],
            // Last month, one bucket per day.
            'monthly' => [
                '%Y-%m-%d',
                $now->subDays(29)->startOfDay(),
                collect(range(29, 0))->map(fn ($i) => $now->subDays($i)->format('Y-m-d'))->all(),
            ],
            // Last year, one bucket per month.
            'yearly' => [
                '%Y-%m',
                $now->subMonths(11)->startOfMonth(),
                collect(range(11, 0))->map(fn ($i) => $now->subMonths($i)->format('Y-m'))->all(),
            ],
            // Everything since the first member, one bucket per month.
            'all' => $this->allTimeSpec($now),
            // Today, one bucket per hour.
            default => [
                '%H:00',
                $now->startOfDay(),
                collect(range(0, 23))->map(fn ($h) => sprintf('%02d:00', $h))->all(),
            ],
        };
    }

    /**
     * @return array{0: string, 1: CarbonImmutable, 2: string[]}
     */
    private function allTimeSpec(CarbonImmutable $now): array
    {
        $first = Member::withTrashed()->min('created_at');

        $start = ($first ? CarbonImmutable::parse($first, config('app.display_timezone')) : $now->subMonths(11))
            ->startOfMonth();

        // Cap the axis at 10 years of monthly buckets just in case.
        $months = min(119, (int) $start->diffInMonths($now));

        $buckets = collect(range($months, 0))
            ->map(fn ($i) => $now->subMonths($i)->format('Y-m'))
            ->all();

        return ['%Y-%m', $start, $buckets];
    }
}
