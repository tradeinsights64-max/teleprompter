<?php

namespace App\Console\Commands;

use App\Services\AnalyticsService;
use App\Services\EventRecorder;
use App\Services\Telegram\TelegramApiException;
use App\Services\Telegram\TelegramClient;
use Illuminate\Console\Command;

/**
 * Posts the daily operational summary to the Telegram admin group
 * (owner request 2026-08-09: reports in the group in addition to the
 * dashboard). Admin-facing content, not member-facing copy.
 */
class ReportDaily extends Command
{
    protected $signature = 'report:daily';

    protected $description = 'Post the daily analytics summary to the Telegram group';

    public function handle(AnalyticsService $analytics, TelegramClient $telegram, EventRecorder $events): int
    {
        $chatId = config('telegram.bootcamp_chat_id');

        if (empty($chatId)) {
            $this->error('TELEGRAM_BOOTCAMP_CHAT_ID is not configured.');

            return self::FAILURE;
        }

        $d = $analytics->dailySummaryData();
        $c = $d['cards'];
        $q = $d['queues'];
        $v = $d['verification'];

        $lines = [
            "📊 TradeInsight daily report — {$d['date']}",
            '',
            "👥 Members: {$c['total_members']} total · {$c['vip_active']} VIP access · ".($c['traded_30d'] ?? 0).' traded 30d',
            "🆕 Today: {$c['started_today']} started · {$c['verified_today']} verified · {$c['joined_today']} joined",
            "✉️ Messages today: {$c['messages_sent_today']} sent · {$c['messages_failed_today']} failed/blocked",
            '',
            '🔎 Verification (today): '
                ."{$v['matched']} matched · {$v['not_found']} not found · {$v['api_error']} API errors · {$v['duplicate']} duplicates",
            '',
            '⚠️ Queues: '
                ."{$q['verification_failed']} verify-failed · {$q['support_escalations']} escalations · "
                ."{$q['unfunded_over_48h']} unfunded>48h · {$q['inactivity_warned']} warned · "
                ."{$q['partner_change_pending']} partner-pending",
        ];

        try {
            $telegram->sendMessage($chatId, implode("\n", $lines));
        } catch (TelegramApiException $e) {
            $this->error('Failed to post report: '.$e->getMessage());

            return self::FAILURE;
        }

        $events->system('report.daily_posted', null, ['date' => $d['date']]);
        $this->info('Daily report posted to the group.');

        return self::SUCCESS;
    }
}
