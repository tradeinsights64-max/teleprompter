<?php

namespace App\Console\Commands;

use App\Enums\MemberStatus;
use App\Models\CommunityAccess;
use App\Models\Member;
use App\Models\NotificationLog;
use App\Services\CommunityAccessService;
use App\Services\EventRecorder;
use App\Services\FeatureFlags;
use App\Services\Settings;
use App\Services\Telegram\BotFlow;
use App\Services\Telegram\FlowMessenger;
use App\Services\Telegram\TelegramApiException;
use App\Services\Telegram\TelegramClient;
use Illuminate\Console\Command;
use Illuminate\Database\UniqueConstraintViolationException;

/**
 * Trading activity monitoring — §12.2 of the flow document.
 * Reminders on days 20 / 22 / 24, removal on day 26. Any trade resets
 * everything. Removal still respects the safety flags: kick.auto_kick must be
 * ON and kick.dry_run OFF before anyone is actually removed.
 */
class FlowInactivity extends Command
{
    protected $signature = 'flow:inactivity';

    protected $description = 'Inactivity reminders (day 20/22/24) and removal (day 26)';

    public function handle(
        Settings $settings,
        FeatureFlags $flags,
        FlowMessenger $flow,
        TelegramClient $telegram,
        EventRecorder $events,
    ): int {
        // Step 20 can be switched off on the Bot Flow board.
        if (! BotFlow::enabled(BotFlow::STEP_INACTIVITY_MONITOR)) {
            $this->info('Step 20 is switched off — nothing to do.');

            return self::SUCCESS;
        }

        $flags->refresh();

        // TI-025: thresholds, warning count and which services are monitored
        // are all settings. Nothing about 20/22/24/26 is fixed in code.
        $warnings = max(0, $settings->int('flow.inactive_warning_count', 3));
        $days = [];

        for ($n = 1; $n <= $warnings; $n++) {
            $default = [1 => 20, 2 => 22, 3 => 24][$n] ?? (20 + ($n - 1) * 2);
            $days[$n] = $settings->int("flow.inactive_day_{$n}", $default);
        }

        $removeDay = $settings->int('flow.inactive_remove_day', 26);
        $neverTradedFrom = \Illuminate\Support\Carbon::parse((string) ($settings->get('flow.never_traded_since') ?: '2026-11-20'));

        // A 'json' setting is already decoded by Settings::typedValue(); an
        // older string value must still work, so accept both shapes.
        $monitored = $settings->get('activity.monitor_services');
        $monitored = is_string($monitored) ? json_decode($monitored, true) : $monitored;
        $monitored = is_array($monitored) && $monitored !== [] ? array_values($monitored) : null;

        if ($days === []) {
            $this->info('No inactivity warnings are configured.');

            return self::SUCCESS;
        }

        $reminded = 0;
        $removed = 0;

        // Already-warned members must stay in scope, otherwise the ladder
        // could never progress past the first reminder.
        $members = Member::whereIn('status', [MemberStatus::VipActive, MemberStatus::InactiveWarned])
            // Members with no trade on record are monitored too (from the
            // later of their group join date and the rollout date), so a
            // VIP seat is never kept forever without trading.
            // Only the services an administrator has put under monitoring —
            // but a member with no recorded service is still monitored, so
            // missing data can never be a way out of the rules.
            ->when($monitored !== null, fn ($q) => $q->where(
                fn ($w) => $w->whereIn('service_selected', $monitored)->orWhereNull('service_selected')
            ))
            ->get();

        foreach ($members as $member) {
            $since = $this->activitySince($member, $neverTradedFrom);
            if ($since === null) {
                continue;
            }
            $inactive = (int) $since->diffInDays(now());

            // Traded again → reset the ladder entirely and cancel removal.
            if ($inactive < $days[1]) {
                if (! empty($member->inactivity_reminders_sent) || $member->status === MemberStatus::InactiveWarned) {
                    $member->update([
                        'inactivity_reminders_sent' => [],
                        'status' => MemberStatus::VipActive,
                        'warned_at' => null,
                    ]);
                    $events->system('flow.inactivity_reset', $member->id, ['days_inactive' => $inactive]);
                }

                continue;
            }

            // ---- removal (day 26) ----
            if ($inactive >= $removeDay) {
                $removed += $this->remove($member, $inactive, $flags, $flow, $telegram, $events) ? 1 : 0;

                continue;
            }

            // ---- reminders ----
            // §12.2 is an IF/ELSE-IF chain: the lowest-numbered unsent
            // reminder whose threshold has passed is the one that fires.
            $already = (array) ($member->inactivity_reminders_sent ?? []);
            $due = null;
            foreach ($days as $n => $threshold) {
                if ($inactive >= $threshold && ! in_array($n, $already, true)) {
                    $due = $n;
                    break;
                }
            }

            if ($due === null) {
                continue;
            }

            try {
                NotificationLog::create([
                    'member_id' => $member->id,
                    'template_key' => 'flow.inactivity_reminder',
                    'dedupe_key' => "inactivity_reminder:{$member->id}:{$due}:".$since->format('Ymd'),
                    'status' => 'queued',
                ]);
            } catch (UniqueConstraintViolationException) {
                continue;
            }

            $ok = $flow->send($member, 'flow.inactivity_reminder', ['days_inactive' => $inactive]);

            $already[] = $due;
            $member->update([
                'inactivity_reminders_sent' => array_values(array_unique($already)),
                'status' => MemberStatus::InactiveWarned,
                'warned_at' => now(),
            ]);

            $events->system('flow.inactivity_reminder_sent', $member->id, [
                'reminder' => $due, 'days_inactive' => $inactive, 'delivered' => $ok,
            ]);

            $reminded++;
        }

        $this->info("Inactivity reminders: {$reminded} · removals: {$removed}");

        return self::SUCCESS;
    }

    private function remove(
        Member $member,
        int $inactive,
        FeatureFlags $flags,
        FlowMessenger $flow,
        TelegramClient $telegram,
        EventRecorder $events,
    ): bool {
        $dryRun = $flags->enabled('kick.dry_run');
        $allowed = $flags->enabled('kick.auto_kick') && $flags->enabled('kick.on_inactivity');

        if (! $allowed || $dryRun) {
            $events->system('flow.inactivity_removal_skipped', $member->id, [
                'days_inactive' => $inactive,
                'reason' => $dryRun ? 'kick.dry_run is ON — logged, not executed' : 'kick.auto_kick / kick.on_inactivity is OFF',
                'would_have' => 'removed from the community',
            ]);

            return false;
        }

        // Remove them from the group they were actually admitted into. With
        // one group per service, the chat named in .env is not necessarily
        // theirs — their access record is the authority.
        $access = app(CommunityAccessService::class);
        $grant = $access->liveAccess($member);
        $chatId = $grant?->chat_id ?? $access->chatIdFor($member->service_selected);

        if (blank($chatId)) {
            $events->system('flow.inactivity_removal_failed', $member->id, [
                'error' => 'no community group is configured for this member',
            ]);

            return false;
        }

        try {
            $telegram->kickAndUnban($chatId, (int) $member->telegram_id);
        } catch (TelegramApiException $e) {
            $events->system('flow.inactivity_removal_failed', $member->id, ['error' => $e->getMessage()]);

            return false;
        }

        if ($grant !== null) {
            $grant->update([
                'status' => CommunityAccess::STATUS_REVOKED,
                'revoked_at' => now(),
                'revoked_reason' => 'inactive for '.$inactive.' days',
            ]);
        }

        $member->update([
            'status' => MemberStatus::KickedInactive,
            'joined_group_at' => null,
        ]);

        $flow->send($member, 'flow.removed_inactive', ['days_inactive' => $inactive]);

        $events->system('flow.inactivity_removed', $member->id, ['days_inactive' => $inactive]);

        return true;
    }

    /**
     * The date inactivity is counted from. Last trade when there is one;
     * otherwise the later of the group join date and the rollout date.
     * Null = skip (no trade on record but commission is coming in).
     */
    private function activitySince(Member $member, \Illuminate\Support\Carbon $neverTradedFrom): ?\Illuminate\Support\Carbon
    {
        if ($member->last_trade_at) {
            return $member->last_trade_at;
        }
        if ((float) ($member->commission_30d ?? 0) > 0) {
            return null;
        }
        $joined = $member->joined_group_at ?? $member->verified_at ?? $member->created_at;

        return $joined && $joined->greaterThan($neverTradedFrom) ? $joined : $neverTradedFrom->copy();
    }
}
