import os,re,shutil,glob,json,sys
os.chdir('/var/www/TradeInsightProduction/TD/StudentPortal')
B='/root/backups/noexness-20261120'; os.makedirs(B,exist_ok=True)
BOT='Register through our Telegram bot.'
EN={
 'Free · with Exness under Trade Insight':'100% Free',
 'The full 13-module Academy, Bootcamp and VIP — free when you open your Exness account under Trade Insight.':'The full 13-module Academy, Bootcamp and VIP — 100% free. '+BOT,
 'The same 13-module Academy and VIP for traders in countries where Exness is not available. Pay by bank transfer, Telebirr or another way — we help you.':'The same 13-module Academy and VIP if the free option is not available in your country. Pay by bank transfer, Telebirr or another way — we help you.',
 'Live group sessions on Zoom twice a week with Molla. Free with an Exness account under Trade Insight, KYC done and a first deposit of $100 or more.':'Live group sessions on Zoom twice a week with Molla. Free for qualified members — '+BOT[0].lower()+BOT[1:],
 'Free with an Exness account under Trade Insight. Academy + VIP ($300) where Exness is not available.':'100% free — '+BOT[0].lower()+BOT[1:-1]+'. Academy + VIP ($300) where the free option is not available.',
 '-course Academy, Bootcamp & VIP — 100% FREE with an Exness account under Trade Insight.':'-course Academy, Bootcamp & VIP — 100% FREE. '+BOT,
 ' — free with an Exness account under Trade Insight.':' — 100% free. '+BOT,
}
AM={
 '100% Free':'100% ነጻ',
 EN['The full 13-module Academy, Bootcamp and VIP — free when you open your Exness account under Trade Insight.']:'ሙሉ 13 module ያለው Academy፣ Bootcamp እና VIP — 100% ነጻ። በTelegram bot ይመዝገቡ።',
 EN['The same 13-module Academy and VIP for traders in countries where Exness is not available. Pay by bank transfer, Telebirr or another way — we help you.']:'ነጻው አማራጭ በሀገርዎ የማይሰራ ከሆነ ተመሳሳይ 13 module Academy እና VIP። በባንክ፣ በTelebirr ወይም በሌላ መንገድ ይክፈሉ — እኛ እንረዳዎታለን።',
 EN['Live group sessions on Zoom twice a week with Molla. Free with an Exness account under Trade Insight, KYC done and a first deposit of $100 or more.']:'በሳምንት ሁለት ጊዜ ከሞላ ጋር በZoom live group sessions። ለሚያሟሉ አባላት ነጻ — በTelegram bot ይመዝገቡ።',
 EN['Free with an Exness account under Trade Insight. Academy + VIP ($300) where Exness is not available.']:'100% ነጻ — በTelegram bot ይመዝገቡ። ነጻው አማራጭ በማይሰራበት ሀገር Academy + VIP ($300)።',
 EN['-course Academy, Bootcamp & VIP — 100% FREE with an Exness account under Trade Insight.']:' ኮርሶች ያሉት Academy፣ Bootcamp እና VIP — 100% ነጻ። በTelegram bot ይመዝገቡ።',
 'Register free on Telegram':'በTelegram በነጻ ይመዝገቡ',
 '100% free. Register in our Telegram bot and start learning today.':'100% ነጻ። በTelegram bot ይመዝገቡ እና ዛሬውኑ መማር ይጀምሩ።',
 'Register in our bot (free)':'በbot ይመዝገቡ (ነጻ)',
}
REN={'Home-ti1010a.js':'Home-ti1120c.js','Mentorship-ti1120b.js':'Mentorship-ti1120c.js','CourseDetail-ti1120b.js':'CourseDetail-ti1120c.js'}
def rd(p): return open(p,encoding='utf-8').read()
def wr(p,s): open(p,'w',encoding='utf-8').write(s)
# 1) chunks: copy to new names with text replaced
for old,new in REN.items():
    s=rd('assets/'+old); n=0
    for a,b in EN.items():
        if a in s: s=s.replace(a,b); n+=1
    wr('assets/'+new,s); shutil.copymode('assets/'+old,'assets/'+new); print(new,'replaced',n,'exness left',len(re.findall('(?i)exness',s)))
# 2) references to old chunk names
for p in glob.glob('assets/*.js'):
    if any(p.endswith(n) for n in REN.values()): continue
    s=rd(p); t=s
    for old,new in REN.items(): t=t.replace(old,new)
    if t!=s: shutil.copy2(p,B+'/'+os.path.basename(p)); wr(p,t); print('refs updated',p)
# 3) index.html
shutil.copy2('index.html',B+'/index.html'); s=rd('index.html')
s=s.replace(EN[' — free with an Exness account under Trade Insight.'],'@@').replace(' — free with an Exness account under Trade Insight.',' — 100% free. '+BOT)
s=s.replace(' — free with an Exness account under Trade Insight. Amharic',' — 100% free. '+BOT+' Amharic').replace('@@',' — 100% free. '+BOT)
s=re.sub(r'am\.js\?v=[0-9a-z]+','am.js?v=20261120e',s); wr('index.html',s); print('index.html exness left',len(re.findall('(?i)exness',s)))
# 4) am.js: rewrite keys + values
shutil.copy2('i18n/am.js',B+'/am.js'); s=rd('i18n/am.js')
def q(x): return json.dumps(x,ensure_ascii=False)
for a,b in EN.items():
    if a.startswith(' — free'): continue
    pat=re.compile(re.escape(q(a))+r'\s*:\s*"(?:[^"\\]|\\.)*"')
    s,n=pat.subn(lambda m: q(b)+': '+q(AM[b]),s); print('am key',a[:30],n)
anchor=q('100% Free')+': '+q(AM['100% Free'])
extra=''.join(', '+q(k)+': '+q(v) for k,v in AM.items() if k in('Register free on Telegram','100% free. Register in our Telegram bot and start learning today.','Register in our bot (free)'))
if anchor in s: s=s.replace(anchor,anchor+extra,1); print('am extras added')
wr('i18n/am.js',s)
