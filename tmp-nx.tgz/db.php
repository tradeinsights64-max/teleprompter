<?php
use Illuminate\Support\Facades\DB;
$B='/root/backups/noexness-20261120';
file_put_contents($B.'/global_settings.json', json_encode(DB::table('global_settings')->whereIn('id',[58,59,62,69])->get(), JSON_UNESCAPED_UNICODE));
file_put_contents($B.'/footer_translations.json', json_encode(DB::table('footer_translations')->whereIn('id',[1,13])->get(), JSON_UNESCAPED_UNICODE));
$set=[58=>'Register free on Telegram',59=>'https://t.me/TradeInsightOfficialBot',62=>'100% free. Register in our Telegram bot and start learning today.',69=>'Register in our bot (free)'];
foreach($set as $id=>$v) DB::table('global_settings')->where('id',$id)->update(['value'=>$v]);
$f=DB::table('footer_translations')->where('id',1)->value('about_us');
DB::table('footer_translations')->where('id',1)->update(['about_us'=>str_replace('Academy, Bootcamp and VIP are free when you open Exness under Trade Insight.','Academy, Bootcamp and VIP are 100% free — register through our Telegram bot.',$f)]);
$f=DB::table('footer_translations')->where('id',13)->value('about_us');
DB::table('footer_translations')->where('id',13)->update(['about_us'=>str_replace('Exness በTrade Insight ስር ስትከፍቱ Academy፣ Bootcamp እና VIP በነጻ ታገኛላችሁ።','Academy፣ Bootcamp እና VIP 100% በነጻ ናቸው — በTelegram bot ተመዝገቡ።',$f)]);
echo 'db left: gs '.DB::table('global_settings')->where('value','like','%xness%')->count().' ft '.DB::table('footer_translations')->where('about_us','like','%xness%')->count().PHP_EOL;
Cache::flush();
