<?php
use Illuminate\Support\Facades\DB; use App\Models\Member;
$B='/root/backups/vip-rule-20261120';
$s = app(App\Services\Settings::class);
file_put_contents($B.'/templates_v3_before.json', json_encode(DB::table('message_templates')->whereIn('key',['flow.inactivity_reminder','flow.removed_inactive','flow.inactivity_nudge'])->get(), JSON_UNESCAPED_UNICODE));
$s->set('flow.inactive_day_1', 15); $s->set('flow.inactive_day_2', 20); $s->set('flow.inactive_remove_day', 22);
$s->setOrCreate('flow.inactive_nudge_day', 10, 'int', 'flow', 'Friendly nudge after N trading days without a trade');
$s->setOrCreate('flow.inactive_gap1_tradingdays', 5, 'int', 'flow', 'Trading days between warning 1 and warning 2');
$s->setOrCreate('flow.inactive_gap2_tradingdays', 2, 'int', 'flow', 'Trading days between warning 2 and removal');
$T = [
 'flow.inactivity_nudge' => [
  'en' => "👋 Hi! We haven't seen a trade from you in a while. Stuck on a setup or not sure where to start? Ask in the VIP group — we're here to help.\n\n💡 Tip: to keep your account active, even a small trade counts — open the smallest lot (0.01) and close it.\n\nNeed help? @trade_insight_support_team",
  'am' => "👋 ሰላም! ለተወሰነ ጊዜ trade ሲያደርጉ አላየንም። setup ላይ ተቸግረዋል ወይስ ከየት እንደሚጀምሩ ግራ ገብቶዎታል? VIP group ውስጥ ይጠይቁ — ለመርዳት ዝግጁ ነን።\n\n💡 ምክር፦ accountዎን active ለማድረግ ትንሽ trade እንኳን ይበቃል — ትንሹን lot (0.01) ከፍተው ወዲያው ይዝጉት።\n\nእርዳታ ከፈለጉ፦ @trade_insight_support_team"],
 'flow.inactivity_reminder' => [
  'en' => "⚠️ VIP is for active traders. No trades for {{days_inactive}} trading days.\n\nPlease place a trade to keep your VIP seat. Quick way: open the smallest lot (0.01) and close it — that's enough to show your account is active.\n\nAfter 2 warnings, inactive members are removed. Need help? @trade_insight_support_team",
  'am' => "⚠️ VIP ለንቁ traders ነው። ለ{{days_inactive}} trading ቀናት ምንም trade አላደረጉም።\n\nVIP ቦታዎን ለማቆየት trade ያድርጉ። ቀላሉ መንገድ፦ ትንሹን lot (0.01) ከፍተው ወዲያው ይዝጉት — account active መሆኑን ለማሳየት ይበቃል።\n\nከ2 ማስጠንቀቂያ በኋላ trade የማያደርጉ አባላት ይወገዳሉ። እርዳታ ከፈለጉ፦ @trade_insight_support_team"],
 'flow.removed_inactive' => [
  'en' => "You've been moved out of VIP for now — no trades for {{days_inactive}} trading days.\n\nComing back is easy: place one trade (even the smallest lot, 0.01, opened and closed), then send /start here and the bot will bring you back in.",
  'am' => "ለ{{days_inactive}} trading ቀናት trade ስላልተደረገ ለጊዜው ከVIP ወጥተዋል።\n\nመመለስ ቀላል ነው፦ አንድ trade ያድርጉ (ትንሹን lot 0.01 ከፍተው መዝጋት እንኳን ይበቃል)፣ ከዚያ እዚህ /start ይላኩ — bot መልሶ ያስገባዎታል።"],
];
foreach ($T as $key => $langs) foreach ($langs as $lang => $body) {
  $q = DB::table('message_templates')->where('key',$key)->where('language',$lang);
  if ($q->exists()) { $q->update(['body'=>$body]); continue; }
  $base = (array) DB::table('message_templates')->where('key','flow.inactivity_reminder')->where('language',$lang)->first();
  unset($base['id']); $base['key']=$key; $base['body']=$body; foreach (['created_at','updated_at'] as $c) if (array_key_exists($c,$base)) $base[$c]=now();
  if (array_key_exists('name',$base)) $base['name']='Friendly inactivity nudge'; if (array_key_exists('label',$base)) $base['label']='Step 22 — Friendly nudge (trading day 10)';
  DB::table('message_templates')->insert($base); echo "created $key $lang\n";
}
// Fresh start under the new rule (nobody has been warned yet today).
$n = Member::whereIn('status',['vip_active','inactive_warned'])->update(['inactivity_reminders_sent'=>json_encode([]),'warned_at'=>null,'status'=>'vip_active']);
echo "ladder reset $n\n";
// Preview: who gets what on Monday 23 Nov.
Illuminate\Support\Carbon::setTestNow(Illuminate\Support\Carbon::parse('2026-11-23 10:00'));
$cmd = app(App\Console\Commands\FlowInactivity::class); $m = new ReflectionMethod($cmd,'activitySince');
$from = Illuminate\Support\Carbon::parse('2026-11-20'); $o=['learning'=>0,'nudge_monday'=>0,'fine'=>0,'commission_skip'=>0];
foreach (Member::where('status','vip_active')->get() as $x) { $since=$m->invoke($cmd,$x,$from,30); if(!$since){$o['commission_skip']++;continue;} if($since->isFuture()){$o['learning']++;continue;} ($since->copy()->startOfDay()->diffInWeekdays(now()->startOfDay())>=10)?$o['nudge_monday']++:$o['fine']++; }
Illuminate\Support\Carbon::setTestNow();
echo json_encode($o)."\n"; Cache::flush();
