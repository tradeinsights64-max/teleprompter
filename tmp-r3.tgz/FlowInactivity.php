<?php

namespace App\Console\Commands;

use App\Enums\MemberStatus;
use App\Models\CommunityAccess;
use App\Models\Member;
use App\Models\NotificationLog;
use App\Services\CommunityAccessService;
use App\Services\EventRecorder;
use App\Services\FeatureFlags;
use App\Services\Settings;
use App\Services\Telegram\BotFlow;
use App\Services\Telegram\FlowMessenger;
use App\Services\Telegram\TelegramApiException;
use App\Services\Telegram\TelegramClient;
use Illuminate\Console\Command;
use Illuminate\Database\UniqueConstraintViolationException;

/**
 * Trading activity monitoring — §12.2 of the flow document.
 * Reminders on days 20 / 22 / 24, removal on day 26. Any trade resets
 * everything. Removal still respects the safety flags: kick.auto_kick must be
 * ON and kick.dry_run OFF before anyone is actually removed.
 */
class FlowInactivity extends Command
{
    protected $signature = 'flow:inactivity';

    protected $description = 'Inactivity (trading days): learning 30d, nudge day 10, warning day 15, 2nd warning +5, removal +2';

    public function handle(
        Settings $settings,
        FeatureFlags $flags,
        FlowMessenger $flow,
        TelegramClient $telegram,
        EventRecorder $events,
    ): int {
        // Step 20 can be switched off on the Bot Flow board.
        if (! BotFlow::enabled(BotFlow::STEP_INACTIVITY_MONITOR)) {
            $this->info('Step 20 is switched off — nothing to do.');

            return self::SUCCESS;
        }

        $flags->refresh();

        // TI-025: thresholds, warning count and which services are monitored
        // are all settings. Nothing about 20/22/24/26 is fixed in code.
        $warnings = max(0, $settings->int('flow.inactive_warning_count', 3));
        $days = [];

        for ($n = 1; $n <= $warnings; $n++) {
            $default = [1 => 20, 2 => 22, 3 => 24][$n] ?? (20 + ($n - 1) * 2);
            $days[$n] = $settings->int("flow.inactive_day_{$n}", $default);
        }

        $removeDay = $settings->int('flow.inactive_remove_day', 26);
        $neverTradedFrom = \Illuminate\Support\Carbon::parse((string) ($settings->get('flow.never_traded_since') ?: '2026-11-20'));

        // A 'json' setting is already decoded by Settings::typedValue(); an
        // older string value must still work, so accept both shapes.
        $monitored = $settings->get('activity.monitor_services');
        $monitored = is_string($monitored) ? json_decode($monitored, true) : $monitored;
        $monitored = is_array($monitored) && $monitored !== [] ? array_values($monitored) : null;

        if ($days === []) {
            $this->info('No inactivity warnings are configured.');

            return self::SUCCESS;
        }

        $reminded = 0;
        $removed = 0;

        // Already-warned members must stay in scope, otherwise the ladder
        // could never progress past the first reminder.
        $members = Member::whereIn('status', [MemberStatus::VipActive, MemberStatus::InactiveWarned])
            // Members with no trade on record are monitored too (from the
            // later of their group join date and the rollout date), so a
            // VIP seat is never kept forever without trading.
            // Only the services an administrator has put under monitoring —
            // but a member with no recorded service is still monitored, so
            // missing data can never be a way out of the rules.
            ->when($monitored !== null, fn ($q) => $q->where(
                fn ($w) => $w->whereIn('service_selected', $monitored)->orWhereNull('service_selected')
            ))
            ->get();

        // Rule (Molla, 20 Nov 2026) — counted in TRADING days (Mon–Fri):
        // 30-day learning period for new members, then
        //   trading day 10 without a trade → friendly nudge
        //   trading day 15                 → warning 1
        //   +5 trading days (one week)     → warning 2 (+ alert for bigger clients)
        //   +2 trading days                → removal
        // Any trade resets everything. Removal never happens without both warnings.
        if (now()->isWeekend()) {
            $this->info('Weekend — markets closed, nothing to do.');

            return self::SUCCESS;
        }
        $nudgeDay = $settings->int('flow.inactive_nudge_day', 10);
        $firstDay = $settings->int('flow.inactive_day_1', 15);
        $gap1 = max(1, $settings->int('flow.inactive_gap1_tradingdays', 5));
        $gap2 = max(1, $settings->int('flow.inactive_gap2_tradingdays', 2));
        $graceDays = max(0, $settings->int('flow.learning_grace_days', 30));
        $tradingDays = fn ($from) => (int) $from->copy()->startOfDay()->diffInWeekdays(now()->startOfDay());
        $bigClients = [];

        foreach ($members as $member) {
            $since = $this->activitySince($member, $neverTradedFrom, $graceDays);
            if ($since === null || $since->isFuture()) {
                continue;
            }
            $inactive = $tradingDays($since);
            $state = (array) ($member->inactivity_reminders_sent ?? []);
            $warnings = array_values(array_filter($state, 'is_int'));
            $nudgedOn = null;
            foreach ($state as $v) {
                if (is_string($v) && str_starts_with($v, 'nudge:')) {
                    $nudgedOn = \Illuminate\Support\Carbon::parse(substr($v, 6));
                }
            }

            // Traded again (or still learning) → reset the ladder entirely.
            if ($inactive < $nudgeDay) {
                if ($state !== [] || $member->status === MemberStatus::InactiveWarned) {
                    $member->update(['inactivity_reminders_sent' => [], 'status' => MemberStatus::VipActive, 'warned_at' => null]);
                    $events->system('flow.inactivity_reset', $member->id, ['days_inactive' => $inactive]);
                }

                continue;
            }

            $sinceWarn = $member->warned_at ? $tradingDays($member->warned_at) : 0;

            if (count($warnings) >= 2) {
                if ($sinceWarn >= $gap2) {
                    $removed += $this->remove($member, $inactive, $flags, $flow, $telegram, $events) ? 1 : 0;
                }

                continue;
            }

            if (count($warnings) === 1) {
                if ($sinceWarn < $gap1) {
                    continue;
                }
                $key = 'flow.inactivity_reminder'; $step = 2;
            } elseif ($nudgedOn === null) {
                // Everyone gets the friendly nudge first.
                $key = 'flow.inactivity_nudge'; $step = 'nudge:'.now()->toDateString();
            } elseif ($inactive >= $firstDay && $tradingDays($nudgedOn) >= 3) {
                $key = 'flow.inactivity_reminder'; $step = 1;
            } else {
                continue;
            }

            try {
                NotificationLog::create([
                    'member_id' => $member->id,
                    'template_key' => $key,
                    'dedupe_key' => 'inactivity_'.(is_int($step) ? $step : 'nudge').":{$member->id}:".$since->format('Ymd'),
                    'status' => 'queued',
                ]);
            } catch (UniqueConstraintViolationException) {
                continue;
            }

            $ok = $flow->send($member, $key, ['days_inactive' => $inactive]);
            $state[] = $step;
            $update = ['inactivity_reminders_sent' => array_values(array_unique($state, SORT_REGULAR))];
            if (is_int($step)) {
                $update['status'] = MemberStatus::InactiveWarned;
                $update['warned_at'] = now();
            }
            $member->update($update);

            $events->system('flow.inactivity_reminder_sent', $member->id, [
                'reminder' => $step, 'days_inactive' => $inactive, 'delivered' => $ok,
            ]);

            if ($step === 2 && max((int) $member->deposit_range_id, (int) $member->balance_range_id) >= 3) {
                $bigClients[] = '• '.($member->telegram_username ? '@'.$member->telegram_username : $member->telegram_id).' — '.$inactive.' trading days';
            }

            $reminded++;
        }

        // Bigger clients on their final warning → a person follows up.
        if ($bigClients !== [] && filled($chat = config('telegram.admin_chat_id'))) {
            try {
                $telegram->sendMessage($chat, "📞 Final warning sent — please contact personally (2 trading days left):\n".implode("\n", array_slice($bigClients, 0, 40)));
            } catch (TelegramApiException) {
            }
        }

        $this->info("Inactivity reminders: {$reminded} · removals: {$removed}");

        return self::SUCCESS;
    }

    private function remove(
        Member $member,
        int $inactive,
        FeatureFlags $flags,
        FlowMessenger $flow,
        TelegramClient $telegram,
        EventRecorder $events,
    ): bool {
        $dryRun = $flags->enabled('kick.dry_run');
        $allowed = $flags->enabled('kick.auto_kick') && $flags->enabled('kick.on_inactivity');

        if (! $allowed || $dryRun) {
            $events->system('flow.inactivity_removal_skipped', $member->id, [
                'days_inactive' => $inactive,
                'reason' => $dryRun ? 'kick.dry_run is ON — logged, not executed' : 'kick.auto_kick / kick.on_inactivity is OFF',
                'would_have' => 'removed from the community',
            ]);

            return false;
        }

        // Remove them from the group they were actually admitted into. With
        // one group per service, the chat named in .env is not necessarily
        // theirs — their access record is the authority.
        $access = app(CommunityAccessService::class);
        $grant = $access->liveAccess($member);
        $chatId = $grant?->chat_id ?? $access->chatIdFor($member->service_selected);

        if (blank($chatId)) {
            $events->system('flow.inactivity_removal_failed', $member->id, [
                'error' => 'no community group is configured for this member',
            ]);

            return false;
        }

        try {
            $telegram->kickAndUnban($chatId, (int) $member->telegram_id);
        } catch (TelegramApiException $e) {
            $events->system('flow.inactivity_removal_failed', $member->id, ['error' => $e->getMessage()]);

            return false;
        }

        if ($grant !== null) {
            $grant->update([
                'status' => CommunityAccess::STATUS_REVOKED,
                'revoked_at' => now(),
                'revoked_reason' => 'inactive for '.$inactive.' days',
            ]);
        }

        $member->update([
            'status' => MemberStatus::KickedInactive,
            'joined_group_at' => null,
        ]);

        $flow->send($member, 'flow.removed_inactive', ['days_inactive' => $inactive]);

        $events->system('flow.inactivity_removed', $member->id, ['days_inactive' => $inactive]);

        return true;
    }

    /**
     * The date inactivity is counted from. Last trade when there is one;
     * otherwise the later of the group join date and the rollout date.
     * Null = skip (no trade on record but commission is coming in).
     */
    private function activitySince(Member $member, \Illuminate\Support\Carbon $neverTradedFrom, int $graceDays = 30): ?\Illuminate\Support\Carbon
    {
        $joined = $member->joined_group_at ?? $member->verified_at ?? $member->created_at;
        // Learning period: counting starts only after it ends.
        $learnedBy = $joined ? $joined->copy()->addDays($graceDays) : null;

        if ($member->last_trade_at) {
            $since = $member->last_trade_at->copy();
        } elseif ((float) ($member->commission_30d ?? 0) > 0) {
            return null;
        } else {
            // No trade on record: never count from before the rollout date.
            $since = $neverTradedFrom->copy();
        }

        return $learnedBy && $learnedBy->greaterThan($since) ? $learnedBy : $since;
    }
}
