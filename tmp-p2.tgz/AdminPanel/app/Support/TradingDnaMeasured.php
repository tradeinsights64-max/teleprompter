<?php

namespace App\Support;

/**
 * Trading DNA Phase 2 (2026-11-20): "what you said vs what you did".
 *
 * Reads the student's own journal book (live trades only, newest 200 within
 * 120 days) and measures the same 12 behaviours the DISC test asks about.
 * Every score is a plain percentage of real trades/days, with the counts that
 * produced it, so a student can check it in their journal. A behaviour that
 * the journal cannot show (or has too few trades for) is left out, never
 * guessed. Nothing is stored: it is recomputed on every request.
 */
class TradingDnaMeasured
{
    public const MIN_TRADES = 10;

    public static function forUser(int $uid): ?array
    {
        $book = JournalBook::decode(JournalBook::row($uid));

        return $book ? self::compute($book) : null;
    }

    public static function compute(array $book): ?array
    {
        $since = strtotime('-120 days');
        $trades = [];
        foreach ($book['accounts'] ?? [] as $a) {
            $max = (int) ($a['settings']['maxTrades'] ?? 0) ?: 3;
            foreach ($a['trades'] ?? [] as $x) {
                if (! empty($x['backtest'])) {
                    continue;
                }
                $o = strtotime((string) ($x['openTime'] ?? '')) ?: null;
                $c = strtotime((string) ($x['closeTime'] ?? '')) ?: $o;
                if (! $c || $c < $since) {
                    continue;
                }
                $trades[] = $x + ['_o' => $o ?: $c, '_c' => $c, '_acct' => (string) ($a['id'] ?? ''), '_max' => $max, '_net' => JournalBook::net($x)];
            }
        }
        usort($trades, fn ($p, $q) => $p['_c'] <=> $q['_c']);
        $trades = array_slice($trades, -200);
        $n = count($trades);
        if ($n < self::MIN_TRADES) {
            return ['trades' => $n, 'enough' => false, 'min' => self::MIN_TRADES, 'risks' => new \stdClass()];
        }

        $tag = fn ($x, $t) => in_array($t, (array) ($x['mistakes'] ?? []), true);
        $r = [];

        // Lot-size baseline per account.
        $lots = [];
        foreach ($trades as $x) {
            $lots[$x['_acct']][] = (float) ($x['lots'] ?? 0);
        }
        $median = [];
        foreach ($lots as $k => $v) {
            sort($v);
            $median[$k] = $v[intdiv(count($v), 2)] ?: 0;
        }
        $big = fn ($x, $f) => $median[$x['_acct']] > 0 && (float) ($x['lots'] ?? 0) > $f * $median[$x['_acct']];

        // 1. Overtrading: trading days above the account's daily trade limit.
        $days = [];
        foreach ($trades as $x) {
            $k = $x['_acct'].'|'.date('Y-m-d', $x['_o']);
            $days[$k] = ['n' => ($days[$k]['n'] ?? 0) + 1, 'max' => $x['_max']];
        }
        $over = count(array_filter($days, fn ($d) => $d['n'] > $d['max']));
        $r['overtrading'] = self::row($over, count($days), 'days', ['over' => $over, 'days' => count($days)]);

        // 2. Revenge: a new trade opened within 30 minutes of closing a loss.
        $loss = $quick = 0;
        for ($i = 0; $i < $n - 1; $i++) {
            if ($trades[$i]['_net'] < 0) {
                $loss++;
                $next = $trades[$i + 1];
                if ($next['_o'] >= $trades[$i]['_c'] && $next['_o'] - $trades[$i]['_c'] <= 1800) {
                    $quick++;
                }
            }
        }
        $r['revenge'] = self::row($quick, $loss, 'losses', ['quick' => $quick, 'losses' => $loss], 5);

        // 3. Oversizing: lot size above 1.5× your usual size, or tagged "Oversized".
        $ov = count(array_filter($trades, fn ($x) => $big($x, 1.5) || $tag($x, 'Oversized')));
        $r['oversizing'] = self::row($ov, $n, 'trades', ['big' => $ov, 'trades' => $n]);

        // 4. Moving the stop loss: losses bigger than the stop (over 1.1R), no stop, or tagged.
        $lossRows = array_values(array_filter($trades, fn ($x) => $x['_net'] < 0));
        $wide = 0;
        foreach ($lossRows as $x) {
            $e = (float) ($x['entry'] ?? 0);
            $sl = (float) ($x['sl'] ?? 0);
            $ex = (float) ($x['exit'] ?? 0);
            $beyond = $e && $sl && $e != $sl && $ex && abs($ex - $e) > 1.1 * abs($e - $sl);
            if ($beyond || ! $sl || $tag($x, 'Moved SL') || $tag($x, 'No SL')) {
                $wide++;
            }
        }
        $r['moving_sl'] = self::row($wide, count($lossRows), 'losses', ['wide' => $wide, 'losses' => count($lossRows)], 5);

        // 5. Holding losers: how much longer losing trades stay open than winning ones.
        $hold = fn ($rows) => $rows ? array_sum(array_map(fn ($x) => max(0, $x['_c'] - $x['_o']), $rows)) / count($rows) : 0;
        $winRows = array_values(array_filter($trades, fn ($x) => $x['_net'] > 0));
        if (count($winRows) >= 3 && count($lossRows) >= 3 && $hold($winRows) > 0) {
            $ratio = $hold($lossRows) / $hold($winRows);
            $r['holding_losers'] = ['score' => (int) round(max(0, min(100, ($ratio - 1) * 50))), 'base' => count($lossRows),
                'fact' => ['ratio' => round($ratio, 1), 'loss_min' => (int) round($hold($lossRows) / 60), 'win_min' => (int) round($hold($winRows) / 60)]];
        }

        // 6. Early exits: winners closed before 80% of the way to take profit, or tagged.
        $withTp = $early = 0;
        foreach ($winRows as $x) {
            $e = (float) ($x['entry'] ?? 0);
            $tp = (float) ($x['tp'] ?? 0);
            $ex = (float) ($x['exit'] ?? 0);
            if ($e && $tp && $tp != $e) {
                $withTp++;
                if (abs($ex - $e) < 0.8 * abs($tp - $e)) {
                    $early++;
                }
            } elseif ($tag($x, 'Closed early')) {
                $withTp++;
                $early++;
            }
        }
        $r['early_exit'] = self::row($early, $withTp, 'wins', ['early' => $early, 'wins' => $withTp], 5);

        // 7. Plan deviation: trades marked "I did not follow my plan" or "Broke daily limit".
        $judged = array_filter($trades, fn ($x) => array_key_exists('followed', $x) && $x['followed'] !== null);
        $broke = count(array_filter($judged, fn ($x) => ! $x['followed'] || $tag($x, 'Broke daily limit')));
        $r['plan_deviation'] = self::row($broke, count($judged), 'trades', ['broke' => $broke, 'judged' => count($judged)], 5);

        // 8. Impatience: trades tagged "Entered early".
        $ee = count(array_filter($trades, fn ($x) => $tag($x, 'Entered early')));
        $r['impatience'] = self::row($ee, $n, 'trades', ['early' => $ee, 'trades' => $n], self::MIN_TRADES, self::tagged($trades));

        // 9. Hesitation: missed valid setups logged, against trades taken.
        $missed = 0;
        foreach ((array) ($book['missed'] ?? []) as $m) {
            $d = strtotime((string) ($m['date'] ?? '')) ?: 0;
            $missed += $d >= $since ? 1 : 0;
        }
        // Only when the student uses the missed-setup log at all; otherwise 0 would mean nothing.
        if (count((array) ($book['missed'] ?? [])) > 0) {
                $r['hesitation'] = ['score' => (int) round(min(100, 200 * $missed / ($missed + $n))), 'base' => $missed + $n,
                'fact' => ['missed' => $missed, 'trades' => $n]];
        }

        // 10. FOMO: trades logged with the emotion "FOMO".
        $emo = array_filter($trades, fn ($x) => ! empty($x['emotion']));
        $fomo = count(array_filter($emo, fn ($x) => $x['emotion'] === 'FOMO'));
        $r['fomo'] = self::row($fomo, count($emo), 'trades', ['fomo' => $fomo, 'tagged' => count($emo)], 5);

        // 11. Overconfidence: bigger lots straight after 3 wins in a row.
        $streak = $after = $up = 0;
        foreach ($trades as $x) {
            if ($streak >= 3) {
                $after++;
                $up += $big($x, 1.2) ? 1 : 0;
            }
            $streak = $x['_net'] > 0 ? $streak + 1 : 0;
        }
        $r['overconfidence'] = self::row($up, $after, 'trades', ['up' => $up, 'after' => $after], 3);

        // 12. over_analysis is a thinking habit: the journal cannot show it, so it is left out.

        $r = array_filter($r);
        $first = $trades[0]['_c'];
        $last = $trades[$n - 1]['_c'];

        return ['trades' => $n, 'enough' => true, 'from' => date('Y-m-d', $first), 'to' => date('Y-m-d', $last), 'risks' => $r];
    }

    /** A percentage row, or null when the base is too small to mean anything. */
    private static function row(int $hit, int $base, string $unit, array $fact, int $min = self::MIN_TRADES, bool $ok = true): ?array
    {
        if ($base < $min || ! $ok) {
            return null;
        }

        return ['score' => (int) round(100 * $hit / $base), 'base' => $base, 'unit' => $unit, 'fact' => $fact];
    }

    /** True when the student uses mistake tags at all (so "no tag" means "did not happen"). */
    private static function tagged(array $trades): bool
    {
        return count(array_filter($trades, fn ($x) => ! empty($x['mistakes']) || (array_key_exists('followed', $x) && $x['followed'] !== null))) >= 5;
    }
}
