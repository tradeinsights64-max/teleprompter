<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Trading DNA v2 (2026-11-20): answer-quality result (consistency + "too perfect" checks).
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('disc_assessments', 'quality')) {
            Schema::table('disc_assessments', fn (Blueprint $t) => $t->json('quality')->nullable()->after('overall_risk'));
        }
    }

    public function down(): void
    {
        Schema::table('disc_assessments', fn (Blueprint $t) => $t->dropColumn('quality'));
    }
};
