<?php

namespace App\Support;

use Illuminate\Validation\ValidationException;

/**
 * Session 11 — the DISC Behavioral Risk Assessment scoring engine.
 *
 *   answers → DISC raw scores → intensity / share per dimension
 *           → primary + secondary style → twelve trading-risk indices
 *
 * The question wording lives in the SPA (src/DiscAssessment*.jsx); this class
 * only knows the ids, which DISC letter each choice carries and how the
 * habit items map to risks, so a client can never change how a result is
 * computed. Bump VERSION if the item set changes — stored attempts keep the
 * version they were scored with.
 *
 * Three instruments feed the result:
 *  - 12 market scenarios, one choice each, +3 to the chosen letter;
 *  - 8 word sets, "most like me" +2 and "least like me" −1 (forced choice,
 *    which stops a student rating every trait as "very me");
 *  - 12 trading-habit frequencies (0 never … 4 almost always), one per risk.
 *
 * A risk index blends the profile's natural predisposition (40%) with the
 * self-reported habit frequency (60%) — the habit is direct evidence, the
 * profile explains why it happens and where it will appear under stress.
 */
class DiscAssessment
{
    public const VERSION = 'v2'; // v2 (2026-11-20): neutral scenario wording + answer-quality check items

    public const LETTERS = ['D', 'I', 'S', 'C'];

    public const SCENARIOS = 12;

    public const WORD_SETS = 8;

    /** Habit item ids double as the risk keys. */
    public const RISKS = [
        'overtrading', 'impatience', 'hesitation', 'revenge', 'oversizing', 'early_exit',
        'moving_sl', 'holding_losers', 'fomo', 'plan_deviation', 'over_analysis', 'overconfidence',
    ];

    /** How strongly each style is naturally drawn to each risk (0–1). */
    public const PREDISPOSITION = [
        'overtrading' => ['D' => .6, 'I' => .9, 'S' => .1, 'C' => .2],
        'impatience' => ['D' => .9, 'I' => .7, 'S' => .1, 'C' => .1],
        'hesitation' => ['D' => .05, 'I' => .2, 'S' => .8, 'C' => .9],
        'revenge' => ['D' => .9, 'I' => .6, 'S' => .2, 'C' => .2],
        'oversizing' => ['D' => .9, 'I' => .6, 'S' => .1, 'C' => .1],
        'early_exit' => ['D' => .2, 'I' => .4, 'S' => .8, 'C' => .5],
        'moving_sl' => ['D' => .7, 'I' => .5, 'S' => .6, 'C' => .2],
        'holding_losers' => ['D' => .6, 'I' => .4, 'S' => .8, 'C' => .3],
        'fomo' => ['D' => .5, 'I' => .9, 'S' => .3, 'C' => .1],
        'plan_deviation' => ['D' => .5, 'I' => .9, 'S' => .2, 'C' => .1],
        'over_analysis' => ['D' => .05, 'I' => .1, 'S' => .4, 'C' => .95],
        'overconfidence' => ['D' => .9, 'I' => .7, 'S' => .1, 'C' => .2],
    ];

    /**
     * Answer-quality items (v2). c1/c2 mirror a habit item in reverse (consistent
     * answers add up to about 4); c3/c4 are "too perfect to be true" statements.
     * Optional so an old draft still scores.
     */
    public const CHECKS = ['c1' => 'hesitation', 'c2' => 'moving_sl', 'c3' => null, 'c4' => null];

    /** Lowest and highest raw score one letter can reach. */
    private const RAW_MIN = -1 * self::WORD_SETS;

    private const RAW_MAX = 3 * self::SCENARIOS + 2 * self::WORD_SETS;

    /**
     * @param  array{scenarios?:array, words?:array, habits?:array}  $answers
     * @return array<string, mixed>
     */
    public function score(array $answers): array
    {
        $clean = $this->validate($answers);

        $raw = array_fill_keys(self::LETTERS, 0);
        foreach ($clean['scenarios'] as $letter) {
            $raw[$letter] += 3;
        }
        foreach ($clean['words'] as $pick) {
            $raw[$pick['most']] += 2;
            $raw[$pick['least']] -= 1;
        }

        $intensity = [];
        foreach ($raw as $l => $v) {
            $intensity[$l] = (int) round(100 * ($v - self::RAW_MIN) / (self::RAW_MAX - self::RAW_MIN));
        }

        $sum = max(1, array_sum($intensity));
        $shares = [];
        foreach ($intensity as $l => $v) {
            $shares[$l] = round(100 * $v / $sum, 1);
        }

        // Ties go to the letter chosen more often in the scenarios — what the
        // student does in the market outranks how they describe themselves.
        $scenarioCount = array_count_values($clean['scenarios']) + array_fill_keys(self::LETTERS, 0);
        $order = self::LETTERS;
        usort($order, fn ($a, $b) => [$raw[$b], $scenarioCount[$b], array_search($a, self::LETTERS)]
            <=> [$raw[$a], $scenarioCount[$a], array_search($b, self::LETTERS)]);
        [$primary, $secondary] = $order;

        // A blend is reported when the runner-up is within 12 intensity points.
        $code = $intensity[$primary] - $intensity[$secondary] <= 12 ? $primary . $secondary : $primary;

        $risks = $this->risks($shares, $clean['habits']);

        return [
            'version' => self::VERSION,
            'answers' => $clean,
            'raw_scores' => $raw,
            'intensity' => $intensity,
            'shares' => $shares,
            'primary_style' => $primary,
            'secondary_style' => $secondary,
            'style_code' => $code,
            'risks' => $risks,
            'overall_risk' => (int) round(array_sum(array_column($risks, 'score')) / count($risks)),
            'quality' => $this->quality($clean),
        ];
    }

    /** high | medium | low, from the reversed pairs and the "too perfect" items. */
    private function quality(array $clean): ?array
    {
        $c = $clean['checks'] ?? [];
        if (count($c) < count(self::CHECKS)) {
            return null;
        }
        $gap = 0;
        foreach (self::CHECKS as $id => $risk) {
            if ($risk !== null) {
                $gap += abs($clean['habits'][$risk] + $c[$id] - 4);
            }
        }
        $perfect = (int) ($c['c3'] >= 3) + (int) ($c['c4'] >= 3);
        $level = ($gap >= 5 || $perfect >= 2) ? 'low' : (($gap <= 2 && $perfect === 0) ? 'high' : 'medium');

        return ['level' => $level, 'inconsistency' => $gap, 'too_perfect' => $perfect];
    }

    /**
     * @return array<string, array{score:int, level:string, predisposition:int, habit:int}>
     */
    private function risks(array $shares, array $habits): array
    {
        // Squared shares sharpen the dominant style: a 40/25/20/15 profile is
        // driven by its top letter far more than a flat average would suggest.
        $w = [];
        foreach ($shares as $l => $s) {
            $w[$l] = ($s / 100) ** 2;
        }
        $wsum = array_sum($w) ?: 1;

        $out = [];
        foreach (self::RISKS as $risk) {
            $pred = 0;
            foreach ($w as $l => $v) {
                $pred += $v * self::PREDISPOSITION[$risk][$l];
            }
            $pred /= $wsum;
            $habit = $habits[$risk] / 4;
            $score = (int) round(100 * (.4 * $pred + .6 * $habit));
            $out[$risk] = [
                'score' => $score,
                'level' => $score >= 65 ? 'high' : ($score >= 40 ? 'moderate' : 'low'),
                'predisposition' => (int) round(100 * $pred),
                'habit' => (int) $habits[$risk],
            ];
        }

        return $out;
    }

    private function validate(array $a): array
    {
        $errors = [];
        $out = ['scenarios' => [], 'words' => [], 'habits' => []];

        for ($i = 1; $i <= self::SCENARIOS; $i++) {
            $v = $a['scenarios']["s$i"] ?? null;
            in_array($v, self::LETTERS, true) ? $out['scenarios']["s$i"] = $v : $errors["scenarios.s$i"] = 'Answer every market scenario.';
        }
        for ($i = 1; $i <= self::WORD_SETS; $i++) {
            $most = $a['words']["w$i"]['most'] ?? null;
            $least = $a['words']["w$i"]['least'] ?? null;
            if (! in_array($most, self::LETTERS, true) || ! in_array($least, self::LETTERS, true) || $most === $least) {
                $errors["words.w$i"] = 'Pick one word that is most like you and a different one that is least like you.';
            } else {
                $out['words']["w$i"] = ['most' => $most, 'least' => $least];
            }
        }
        foreach (self::RISKS as $risk) {
            $v = $a['habits'][$risk] ?? null;
            is_numeric($v) && (int) $v == $v && $v >= 0 && $v <= 4
                ? $out['habits'][$risk] = (int) $v
                : $errors["habits.$risk"] = 'Rate every trading habit.';
        }

        foreach (array_keys(self::CHECKS) as $id) {
            $v = $a['checks'][$id] ?? null;
            if (is_numeric($v) && (int) $v == $v && $v >= 0 && $v <= 4) {
                $out['checks'][$id] = (int) $v;
            }
        }

        if ($errors) {
            throw ValidationException::withMessages($errors);
        }

        return $out;
    }
}
