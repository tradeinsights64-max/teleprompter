<?php

namespace App\Http\Controllers\Api\V1\Extensions;

use App\Http\Controllers\Controller;
use App\Support\DiscAssessment;
use App\Support\StudentProgress;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Session 11 — DISC Behavioral Risk Assessment. The student's own attempts
 * (newest first) and submitting a new one. Submitting also ticks off the
 * Session 11 "Digital Assessment" lesson — any lesson whose content_json
 * carries "assessment":"disc" — in every course the student is enrolled in.
 */
class StudentDiscAssessmentController extends Controller
{
    public function index(): JsonResponse
    {
        $rows = DB::table('disc_assessments')->where('user_id', Auth::guard('web')->id())
            ->orderByDesc('id')->limit(30)->get();

        return response()->json(['data' => $rows->map(fn ($r) => $this->shape($r))->values()]);
    }

    public function store(Request $request, DiscAssessment $engine, StudentProgress $progress): JsonResponse
    {
        $request->validate(['answers' => ['required', 'array'], 'course' => ['nullable', 'string', 'max:191']]);
        $uid = (int) Auth::guard('web')->id();
        $result = $engine->score($request->input('answers'));

        $enrolled = $progress->enrolledCourseIds($uid);
        $courseId = $request->filled('course')
            ? DB::table('courses')->where('slug', $request->input('course'))->whereIn('id', $enrolled ?: [0])->value('id')
            : null;

        $now = now();
        $id = DB::table('disc_assessments')->insertGetId([
            'user_id' => $uid,
            'course_id' => $courseId,
            'version' => $result['version'],
            'answers' => json_encode($result['answers']),
            'raw_scores' => json_encode($result['raw_scores']),
            'intensity' => json_encode($result['intensity']),
            'shares' => json_encode($result['shares']),
            'primary_style' => $result['primary_style'],
            'secondary_style' => $result['secondary_style'],
            'style_code' => $result['style_code'],
            'risks' => json_encode($result['risks']),
            'overall_risk' => $result['overall_risk'],
            'quality' => $result['quality'] ? json_encode($result['quality']) : null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $this->completeLessons($uid, $enrolled);

        return response()->json(['data' => $this->shape(DB::table('disc_assessments')->find($id))], 201);
    }

    private function completeLessons(int $uid, array $enrolled): void
    {
        if (! $enrolled) {
            return;
        }
        $lessons = DB::table('course_module_lessons as l')
            ->join('course_modules as m', 'm.id', '=', 'l.course_module_id')
            ->whereIn('m.course_id', $enrolled)
            ->where(fn ($q) => $q->where('l.content_json', 'like', '%"assessment":"disc"%')->orWhere('l.content_json', 'like', '%"assessment": "disc"%'))
            ->get(['l.id', 'm.course_id']);

        foreach ($lessons as $l) {
            $exists = DB::table('lesson_checklists')->where('student_id', $uid)->where('course_module_lesson_id', $l->id)->exists();
            if (! $exists) {
                DB::table('lesson_checklists')->insert([
                    'student_id' => $uid, 'course_id' => $l->course_id, 'course_module_lesson_id' => $l->id,
                    'created_at' => now(), 'updated_at' => now(),
                ]);
            }
        }
    }

    private function shape(object $r): array
    {
        return [
            'id' => (int) $r->id,
            'version' => $r->version,
            'raw_scores' => json_decode($r->raw_scores, true),
            'intensity' => json_decode($r->intensity, true),
            'shares' => json_decode($r->shares, true),
            'primary' => $r->primary_style,
            'secondary' => $r->secondary_style,
            'style_code' => $r->style_code,
            'risks' => json_decode($r->risks, true),
            'overall_risk' => (int) $r->overall_risk,
            'quality' => isset($r->quality) && $r->quality ? json_decode($r->quality, true) : null,
            'created_at' => \Illuminate\Support\Carbon::parse($r->created_at)->toIso8601String(),
        ];
    }
}
