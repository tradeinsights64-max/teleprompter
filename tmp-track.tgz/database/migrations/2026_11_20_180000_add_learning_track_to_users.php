<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('users', 'learning_track')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('learning_track', 2)->nullable()->after('id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('users', 'learning_track')) {
            Schema::table('users', fn (Blueprint $table) => $table->dropColumn('learning_track'));
        }
    }
};
