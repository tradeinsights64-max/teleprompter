<?php

namespace App\Http\Controllers\Api\V1\Student;

use App\Http\Controllers\Controller;
use App\Http\Resources\Student\EnrolledCourseResource;
use App\Support\CourseOrdering;
use App\Support\StudentCurriculum;
use App\Support\StudentProgress;
use App\Support\TrackProgression;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Modules\Course\App\Models\Course;
use Modules\Course\App\Models\CourseModuleLesson;
use Modules\EventCalendar\App\Models\Meeting;

/**
 * The student's own programmes: the Learning Journey list and the course player.
 *
 * AUTHORIZATION. Two independent gates, and both are needed:
 *
 *   index()  scopes the query to the ids in course_enrollment_lists for this
 *            student. A listing cannot be "authorized" record by record — the
 *            protection is that a foreign course is never in the result set.
 *   show()   loads by slug and then calls CoursePolicy::viewContent. `role:
 *            student` proves the caller is a student; it says nothing about
 *            whether THIS course is one they paid for, so the policy runs on
 *            the specific record. An unenrolled student gets 403, an unknown
 *            slug 404.
 *
 * A third gate lives inside show(): the sequential unlock rule. The Blade
 * player only greyed out locked rows in the sidebar — the lesson URL still
 * served the content to anyone who typed it. Here the lesson body is returned
 * for the active lesson only, and a locked lesson is refused, so skipping ahead
 * fails at the server rather than in the styling.
 */
class EnrolledCourseController extends Controller
{
    public function __construct(
        protected StudentProgress $progress,
        protected StudentCurriculum $curriculum,
    ) {
    }

    /**
     * GET student/courses — the Learning Journey.
     *
     * Server-side paginated. Progress for the whole page is two correlated
     * subqueries, not a per-row accessor: Course::$actual_total_lesson and the
     * $appends accessors would each cost a query per card.
     */
    public function index(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'search'   => ['nullable', 'string', 'max:255'],
            'sort'     => ['nullable', 'in:sequence,recent,progress'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:50'],
        ]);

        $student = $this->student($request);
        // One course language per student: only their track is listed
        // (both, until they have made progress or chosen one).
        $enrolledIds = app(\App\Support\LearningTrack::class)
            ->filterIds($this->progress->enrolledCourseIds((int) $student->id), (int) $student->id);

        $query = Course::query()
            // The ownership boundary for this endpoint. An empty array yields
            // an empty page rather than the whole catalogue.
            ->whereIn('courses.id', $enrolledIds)
            ->with([
                // *.translate / *.front_translate are not decoration: Category
                // exposes `name` as an accessor reading those relations, so
                // omitting them costs two queries per distinct category.
                'category', 'category.translate', 'category.front_translate',
                'instructor',
                'translate', 'front_translate',
            ])
            ->withCount('modules')
            ->addSelect([
                'lessons_count'   => $this->progress->lessonCountSubquery(),
                'completed_count' => $this->progress->completedCountSubquery((int) $student->id),
            ]);

        if (! empty($validated['search'])) {
            $term = $validated['search'];
            $query->whereHas('translate', fn ($q) => $q->where('title', 'like', "%{$term}%"));
        }

        /*
         | Curriculum order by default, not newest-first.
         |
         | A student is enrolled in all thirteen modules of their track at
         | once, so "newest first" ordered the Learning page by course id and
         | put Module 13 at the top — the one furthest from being openable,
         | with the longest countdown on it — and Module 1, the only one they
         | can actually start, at the bottom. Ordering by the module number is
         | the only arrangement that matches how the course is taught and how
         | the release schedule unlocks it.
         |
         | 'recent' is kept because it is still the right answer for a student
         | who has bought unrelated one-off programmes over time.
         */
        match ($validated['sort'] ?? 'sequence') {
            // Ordered by the subquery alias; MySQL resolves a select alias in
            // ORDER BY, and paginate()'s count query strips orders entirely.
            // Sorting by title is deliberately not offered: the title lives in
            // course_translations, so it would need a join this query does not
            // otherwise carry.
            'progress' => $query->orderByRaw('completed_count desc'),
            'recent'   => $query->latest('courses.id'),
            default    => CourseOrdering::sequential($query),
        };

        // Default 50 (2026-11-13): the web Learning Journey asks without
        // per_page and has no pager, so at 12 a student on all 13 sessions
        // never saw Session 13 — or the certificate link on its card.
        $courses = $query->paginate($validated['per_page'] ?? 50)->withQueryString();

        $progression = app(TrackProgression::class);

        foreach ($courses as $course) {
            $course->progress = $this->progress->shape(
                (int) ($course->lessons_count ?? 0),
                (int) ($course->completed_count ?? 0),
            );

            // The Learning page shows the same lock and the same countdown as
            // the catalogue, so the answer is computed once here rather than
            // re-derived in the client from a date it would have to trust.
            $course->gate_state = $progression->gate($course, (int) $student->id);
        }

        // ->collection($paginator) keeps Laravel's standard links/meta envelope,
        // the same one the public catalogue returns, so the client has one
        // pagination shape to understand. The tiles ride along in `summary`.
        return EnrolledCourseResource::collection($courses)
            ->additional(['summary' => $this->summary($enrolledIds, (int) $student->id)])
            ->response();
    }

    /**
     * GET student/courses/{slug} — the player payload.
     *
     * The course is looked up WITHOUT the published filter the public
     * catalogue applies, then handed to CoursePolicy::viewContent, which lets
     * an enrolled student in even if the instructor has since unpublished the
     * course. Buying access to something that later leaves the catalogue must
     * not revoke it.
     */
    public function show(Request $request, string $slug): JsonResponse
    {
        $validated = $request->validate([
            'lesson_id' => ['nullable', 'integer'],
        ]);

        $student = $this->student($request);

        $course = Course::query()
            ->where('slug', $slug)
            ->with([
                'category', 'category.translate', 'category.front_translate',
                'instructor',
                'translate', 'front_translate',
            ])
            ->firstOrFail();

        // Ownership, on the specific record. Role got the caller this far.
        $this->authorize('viewContent', $course);

        /*
         * The release clock and the sequential-track rule, enforced where the
         * player actually loads. Enrolment is not enough: every student is
         * enrolled in all thirteen modules of their track from day one, so
         * without this they could open module 13 on launch day by typing the
         * slug. 403 rather than 404 — the course exists, it is simply not
         * theirs to open yet, and the message says which of the two reasons
         * applies.
         */
        $gate = app(TrackProgression::class)->gate($course, (int) $student->id);

        if (! $gate['allowed']) {
            return response()->json([
                'message' => $gate['message'],
                'blocked_reason' => $gate['reason'],
                'blocked_by' => $gate['blocked_by'],
            ], 403);
        }

        $curriculum = $this->curriculum->build($course, (int) $student->id);
        $rows = $curriculum['rows'];

        $totals = $this->progress->shape(
            count($rows),
            count(array_filter($rows, fn ($row) => $row['done'])),
        );

        $activeIndex = $this->resolveActiveIndex($rows, $validated['lesson_id'] ?? null);
        $active = $activeIndex === null ? null : $rows[$activeIndex];

        $nextAny = $activeIndex !== null && isset($rows[$activeIndex + 1]) ? $rows[$activeIndex + 1] : null;
        $prev = $activeIndex !== null && $activeIndex > 0 ? $rows[$activeIndex - 1] : null;

        // The first lesson still to do — where "Continue" should land.
        $nextIncomplete = null;
        foreach ($rows as $row) {
            if (! $row['done']) {
                $nextIncomplete = $row;
                break;
            }
        }

        return response()->json([
            'data' => [
                'course' => [
                    'id'               => $course->id,
                    'slug'             => $course->slug,
                    'title'            => html_decode((string) $course->title),
                    'thumbnail'        => tide_image($course->thumb_image),

                    // The session video, played on the mobile app's Videos tab.
                    // Enrolled students only — this endpoint is already behind
                    // CoursePolicy::viewContent — which is why it is a separate
                    // column from the public preview_video_id trailer.
                    'video_url'        => $course->course_video_url ?: null,

                    'category'         => $course->category?->name,
                    'instructor'       => $course->instructor ? [
                        'name'  => $course->instructor->name,
                        'image' => $course->instructor->image ? tide_image($course->instructor->image) : null,
                    ] : null,
                    'modules_count'    => $curriculum['modules']->count(),
                    'lessons_count'    => count($rows),
                    // Whole minutes. video_duration is a varchar of minutes, so
                    // it is cast before summing rather than trusting PHP string
                    // arithmetic. The model's total_duration accessor is
                    // deliberately avoided: it walks the relations again and
                    // returns a preformatted string.
                    'duration_minutes' => array_sum(array_map(
                        fn ($row) => $this->lessonDuration($row['lesson']),
                        $rows,
                    )),
                ],

                'progress' => $totals,

                'modules' => $curriculum['modules']->map(fn ($module) => [
                    'id'      => $module->id,
                    'title'   => html_decode((string) $module->name),
                    'lessons' => $module->lessons->map(function ($lesson) use ($curriculum, $active) {
                        $row = $curriculum['by_lesson_id'][(int) $lesson->id] ?? null;

                        return [
                            'id'               => $lesson->id,
                            'title'            => html_decode((string) $lesson->name),
                            'content_type'     => $lesson->content_type,
                            'duration_minutes' => $this->lessonDuration($lesson),
                            'is_complete'      => (bool) ($row['done'] ?? false),
                            'is_unlocked'      => (bool) ($row['unlocked'] ?? false),
                            'is_active'        => $active !== null && (int) $active['lesson']->id === (int) $lesson->id,
                            'has_quiz'         => $lesson->content_type === 'quiz' && $lesson->quiz !== null,
                        ];
                    })->values(),
                ])->values(),

                'active_lesson'  => $active === null ? null : $this->activeLessonPayload($active),
                'prev_lesson_id' => $prev === null ? null : (int) $prev['lesson']->id,
                // Both are reported: the Blade footer shows either the Next
                // button or the "finish this one first" hint, and it needs to
                // know a next lesson exists but is locked.
                'next_lesson_id' => $nextAny !== null && $nextAny['unlocked'] ? (int) $nextAny['lesson']->id : null,
                'next_locked'    => $nextAny !== null && ! $nextAny['unlocked'],
                'continue_lesson_id' => $nextIncomplete === null ? null : (int) $nextIncomplete['lesson']->id,

                'live_meeting' => $this->liveMeeting($course),
            ],
        ]);
    }

    /**
     * Which lesson the player opens on.
     *
     * A requested lesson must be part of this course's enabled curriculum
     * (otherwise 404 — a lesson id from another course is simply not here) and
     * must be unlocked (otherwise 403). With nothing requested, the player
     * opens on the first unfinished lesson, which is also the last unlocked
     * one, so it is always reachable.
     *
     * @param  array<int, array<string, mixed>>  $rows
     */
    protected function resolveActiveIndex(array $rows, ?int $lessonId): ?int
    {
        if ($rows === []) {
            return null;
        }

        if ($lessonId !== null) {
            foreach ($rows as $index => $row) {
                if ((int) $row['lesson']->id === $lessonId) {
                    abort_unless($row['unlocked'], 403, 'Complete the previous lesson to unlock this one.');

                    return $index;
                }
            }

            abort(404, 'That lesson is not part of this programme.');
        }

        foreach ($rows as $index => $row) {
            if (! $row['done']) {
                return $index;
            }
        }

        // Everything is complete: land on the last lesson rather than nothing.
        return array_key_last($rows);
    }

    /** @param array<string, mixed> $row */
    protected function activeLessonPayload(array $row): array
    {
        /** @var CourseModuleLesson $lesson */
        $lesson = $row['lesson'];

        return [
            'id'               => $lesson->id,
            'title'            => html_decode((string) $lesson->name),
            'module_id'        => $row['module']->id,
            'module_title'     => html_decode((string) $row['module']->name),
            'content_type'     => $lesson->content_type,
            'duration_minutes' => $this->lessonDuration($lesson),
            'is_complete'      => (bool) $row['done'],
            'description'      => $lesson->description ? html_decode((string) $lesson->description) : null,
            'content'          => $this->lessonContent($lesson),
        ];
    }

    /**
     * The playable body of the active lesson.
     *
     * Returned for the active lesson ONLY, and resolveActiveIndex() has already
     * refused a locked one — so this is where the unlock rule stops being
     * decoration. A video id, a document URL or a lesson body for a lesson the
     * student has not reached is never serialised.
     */
    protected function lessonContent(CourseModuleLesson $lesson): array
    {
        return match ($lesson->content_type) {
            'video' => [
                'source'    => $lesson->content('video_source') ?? $lesson->video_source,
                'embed_url' => $this->videoUrl($lesson),
            ],
            // TEMPORARY (2026-09-18): session/lesson files are hidden from the
            // student frontend while the content is private. `url => null`
            // withholds the file; restore `$this->mediaUrl(...)` to re-enable.
            'audio' => [
                'url'           => null,
                'original_name' => $lesson->content('original_name', 'Audio lesson'),
                'mime'          => $lesson->content('mime', 'audio/mpeg'),
            ],
            'document' => [
                'url'           => null,
                'original_name' => $lesson->content('original_name', 'Document'),
                'extension'     => strtolower((string) pathinfo((string) $lesson->content('file_path', ''), PATHINFO_EXTENSION)),
            ],
            'richtext' => [
                'body' => html_decode((string) $lesson->content('body', $lesson->description)),
            ],
            'quiz' => [
                // Definition only. Questions are a separate, separately
                // authorized endpoint, and the answer key never leaves the
                // server at all — see Student\QuizController.
                'quiz' => $lesson->quiz === null ? null : [
                    'id'             => $lesson->quiz->id,
                    'title'          => html_decode((string) ($lesson->quiz->title ?: $lesson->name)),
                    'description'    => $lesson->quiz->description ? html_decode((string) $lesson->quiz->description) : null,
                    'question_count' => (int) ($lesson->quiz->questions_count ?? 0),
                    'time_limit'     => (int) ($lesson->quiz->time_limit ?? 30),
                    'passing_score'  => (int) ($lesson->quiz->passing_score ?? 70),
                ],
            ],
            default => [],
        };
    }

    /**
     * YouTube ids are stored in every shape the old admin form accepted — a
     * bare id, a watch URL, a share link. The extraction regex is carried over
     * from the Blade video player unchanged so the same rows keep playing.
     */
    protected function videoUrl(CourseModuleLesson $lesson): ?string
    {
        $source = $lesson->content('video_source') ?? $lesson->video_source;
        $videoId = html_entity_decode((string) ($lesson->content('video_id') ?? $lesson->video_id));

        if ($videoId === '') {
            return null;
        }

        if ($source === 'youtube') {
            preg_match(
                '/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/',
                $videoId,
                $matches
            );

            if (! empty($matches[1])) {
                return 'https://www.youtube.com/embed/' . $matches[1] . '?' . http_build_query([
                    'rel'             => 0,
                    'modestbranding'  => 1,
                    'controls'        => 1,
                    'showinfo'        => 0,
                    'iv_load_policy'  => 3,
                    'fs'              => 1,
                ]);
            }
        }

        return $videoId;
    }

    /**
     * Uploaded media as a same-origin path.
     *
     * Storage::url() may return an absolute URL built from APP_URL, which in
     * development points at the Laravel port rather than the Vite one — the
     * browser would then request it cross-origin and the dev proxy would never
     * see it. Only the path survives, and /storage is proxied.
     */
    protected function mediaUrl(?string $path): ?string
    {
        if (empty($path)) {
            return null;
        }

        return parse_url(Storage::url($path), PHP_URL_PATH) ?: null;
    }

    /** Mirrors the Blade player's $lessonDuration closure, in the same order. */
    protected function lessonDuration(CourseModuleLesson $lesson): int
    {
        return (int) ($lesson->content('estimated_duration')
            ?? $lesson->content('video_duration')
            ?? $lesson->video_duration
            ?? 0);
    }

    /**
     * The live session banner. Only reported while it is actually running,
     * which is the condition the Blade view applies before rendering.
     */
    protected function liveMeeting(Course $course): ?array
    {
        $meeting = Meeting::where('course_id', $course->id)->latest()->first();

        if (! $meeting || ! $meeting->start_time) {
            return null;
        }

        $start = \Carbon\Carbon::parse($meeting->start_time);
        $end = $start->copy()->addMinutes((int) ($meeting->duration ?? 0));

        if (! now()->between($start, $end)) {
            return null;
        }

        return [
            'title'      => $meeting->title,
            'link'       => $meeting->meeting_link,
            'started_at' => $start->toIso8601String(),
            'ends_at'    => $end->toIso8601String(),
        ];
    }

    /**
     * The three tiles above the journey list, in one query rather than one per
     * course. Courses with no enabled lessons are absent from the totals map
     * and count as not started, which is what an empty programme is.
     *
     * @param  array<int, int>  $enrolledIds
     */
    protected function summary(array $enrolledIds, int $studentId): array
    {
        $totals = $this->progress->totalsForCourses($enrolledIds, $studentId);

        $completed = 0;
        $inProgress = 0;

        foreach ($totals as $total) {
            if ($total['is_complete']) {
                $completed++;
            } elseif ($total['completed'] > 0) {
                $inProgress++;
            }
        }

        return [
            'enrolled'    => count($enrolledIds),
            'in_progress' => $inProgress,
            'completed'   => $completed,
            'not_started' => max(0, count($enrolledIds) - $completed - $inProgress),
        ];
    }

    /**
     * The acting student. Read from the guard, never from input — the role
     * middleware has already established there is one.
     */
    protected function student(Request $request)
    {
        return Auth::guard('web')->user() ?? $request->user();
    }
}
