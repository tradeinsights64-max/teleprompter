<?php

namespace App\Http\Controllers\Api\V1\Student;

use App\Http\Controllers\Controller;
use App\Support\StudentProgress;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * The figures the Blade student dashboard renders.
 *
 * Shape follows Student\ProfileController::getStudentDashboardStats — the same
 * tiles, the same activity series, the same streak, plus the quiz/certificate
 * counts and the notice/meeting lists the Blade view queries inline.
 *
 * ONE DELIBERATE DIVERGENCE, and it is a correctness fix rather than a
 * redesign. The Blade version's denominators are the WHOLE CATALOGUE:
 * getModuleStats counts every row in course_modules, getLessonStats every
 * enabled lesson in the system, and getCourseStats every course including ones
 * the student has never seen. A student two lessons into their one programme is
 * told they are "0.4% complete" and have "312 lessons remaining", which is not
 * a fact about them. Every figure below is scoped to the courses the student is
 * actually enrolled on. The tiles, their order and their labels are unchanged.
 *
 * PERFORMANCE. Nothing here touches Course::$appends — total_student,
 * avg_rating, total_rating and total_duration each run a relation query per
 * row. The per-course totals are one grouped query for the whole set (see
 * StudentProgress::totalsForCourses), not two counts per course.
 */
class DashboardController extends Controller
{
    public function __construct(protected StudentProgress $progress)
    {
    }

    public function __invoke(Request $request): JsonResponse
    {
        $student = Auth::guard('web')->user() ?? $request->user();
        $studentId = (int) $student->id;

        $courseIds = app(\App\Support\LearningTrack::class)
            ->filterIds($this->progress->enrolledCourseIds($studentId), $studentId);
        $totals = $this->progress->totalsForCourses($courseIds, $studentId);

        return response()->json([
            'data' => [
                'student' => [
                    'name'  => $student->name,
                    'image' => $student->image ? tide_image($student->image) : null,
                ],
                'course_stats'    => $this->courseStats($courseIds, $totals),
                'module_stats'    => $this->moduleStats($courseIds, $studentId),
                'lesson_stats'    => $this->lessonStats($courseIds, $studentId),
                'progress_stats'  => $this->progressStats($totals),
                'quiz_stats'      => $this->quizStats($studentId),
                'certificates'    => DB::table('issued_certificates')->where('student_id', $studentId)->count(),
                'recent_activity' => $this->recentActivity($studentId),
                'weekly_progress' => $this->weeklyProgress($studentId),
                'learning_streak' => $this->learningStreak($studentId),
                'upcoming_sessions' => $this->upcomingSessions($courseIds),
                'announcements'   => $this->announcements($courseIds),
            ],
        ]);
    }

    /**
     * @param  array<int, int>  $courseIds
     * @param  array<int, array<string, mixed>>  $totals
     */
    protected function courseStats(array $courseIds, array $totals): array
    {
        $completed = 0;
        $inProgress = 0;

        foreach ($totals as $total) {
            if ($total['is_complete']) {
                $completed++;
            } elseif ($total['completed'] > 0) {
                $inProgress++;
            }
        }

        $total = count($courseIds);

        return [
            'total'           => $total,
            'completed'       => $completed,
            'in_progress'     => $inProgress,
            'not_started'     => max(0, $total - $completed - $inProgress),
            'completion_rate' => $total > 0 ? round(($completed / $total) * 100, 1) : 0,
        ];
    }

    /**
     * Modules where every enabled lesson is ticked off.
     *
     * One grouped query. Every column is alias-qualified because course_modules
     * and course_module_lessons both carry a `status` column, and an
     * unqualified predicate across the join is ambiguous enough for MySQL to
     * reject the statement.
     *
     * @param  array<int, int>  $courseIds
     */
    protected function moduleStats(array $courseIds, int $studentId): array
    {
        if ($courseIds === []) {
            return ['total' => 0, 'completed' => 0, 'completion_rate' => 0];
        }

        $rows = DB::table('course_modules as m')
            ->join('course_module_lessons as l', function ($join) {
                $join->on('l.course_module_id', '=', 'm.id')
                    ->where('l.status', '=', 'enable');
            })
            ->leftJoin('lesson_checklists as lc', function ($join) use ($studentId) {
                $join->on('lc.course_module_lesson_id', '=', 'l.id')
                    ->where('lc.student_id', '=', $studentId);
            })
            ->whereIn('m.course_id', $courseIds)
            ->where('m.status', 'enable')
            ->groupBy('m.id')
            ->select([
                'm.id',
                DB::raw('count(distinct l.id) as total_lessons'),
                DB::raw('count(distinct lc.course_module_lesson_id) as completed_lessons'),
            ])
            ->get();

        $completed = $rows
            ->filter(fn ($row) => $row->total_lessons > 0 && $row->completed_lessons >= $row->total_lessons)
            ->count();

        // Modules with no enabled lessons cannot be completed and are not
        // counted in either figure.
        $total = $rows->count();

        return [
            'total'           => $total,
            'completed'       => $completed,
            'completion_rate' => $total > 0 ? round(($completed / $total) * 100, 1) : 0,
        ];
    }

    /** @param array<int, int> $courseIds */
    protected function lessonStats(array $courseIds, int $studentId): array
    {
        if ($courseIds === []) {
            return [
                'total' => 0, 'completed' => 0, 'remaining' => 0, 'completion_rate' => 0,
                'total_duration' => '0m', 'completed_duration' => '0m', 'remaining_duration' => '0m',
            ];
        }

        // video_duration is a varchar of whole MINUTES. The Blade helper
        // divides it by 3600 as if it were seconds, so the dashboard reports
        // "0m" for every student; the cast and the units are corrected here.
        $row = DB::table('course_module_lessons as l')
            ->join('course_modules as m', 'm.id', '=', 'l.course_module_id')
            ->leftJoin('lesson_checklists as lc', function ($join) use ($studentId) {
                $join->on('lc.course_module_lesson_id', '=', 'l.id')
                    ->where('lc.student_id', '=', $studentId);
            })
            ->whereIn('m.course_id', $courseIds)
            ->where('m.status', 'enable')
            ->where('l.status', 'enable')
            ->select([
                DB::raw('count(distinct l.id) as total_lessons'),
                DB::raw('count(distinct lc.course_module_lesson_id) as completed_lessons'),
                DB::raw('sum(cast(coalesce(l.video_duration, 0) as unsigned)) as total_minutes'),
                DB::raw('sum(case when lc.id is not null then cast(coalesce(l.video_duration, 0) as unsigned) else 0 end) as completed_minutes'),
            ])
            ->first();

        $total = (int) ($row->total_lessons ?? 0);
        $completed = min((int) ($row->completed_lessons ?? 0), $total);
        $totalMinutes = (int) ($row->total_minutes ?? 0);
        $completedMinutes = (int) ($row->completed_minutes ?? 0);

        return [
            'total'              => $total,
            'completed'          => $completed,
            'remaining'          => max(0, $total - $completed),
            'completion_rate'    => $total > 0 ? round(($completed / $total) * 100, 1) : 0,
            'total_duration'     => $this->formatMinutes($totalMinutes),
            'completed_duration' => $this->formatMinutes($completedMinutes),
            'remaining_duration' => $this->formatMinutes(max(0, $totalMinutes - $completedMinutes)),
        ];
    }

    /** @param array<int, array<string, mixed>> $totals */
    protected function progressStats(array $totals): array
    {
        $lessons = array_sum(array_column($totals, 'total'));
        $done = array_sum(array_column($totals, 'completed'));

        return [
            'overall_progress' => $lessons > 0 ? round(($done / $lessons) * 100, 1) : 0,
            'total_completed'  => $done,
        ];
    }

    protected function quizStats(int $studentId): array
    {
        $row = DB::table('quiz_results')
            ->where('student_id', $studentId)
            ->select([
                DB::raw("sum(case when status = 'pass' then 1 else 0 end) as passed"),
                DB::raw('avg(score) as average'),
                DB::raw('count(*) as attempts'),
            ])
            ->first();

        return [
            'passed'   => (int) ($row->passed ?? 0),
            'attempts' => (int) ($row->attempts ?? 0),
            // Float, not the model's sprintf('%.2f') string: a typed client
            // cannot do arithmetic on "0.00".
            'average'  => $row->average === null ? null : round((float) $row->average, 1),
        ];
    }

    /**
     * The last ten lessons ticked off, with enough context to link back into
     * the player. Joined rather than hydrated: this is a read-only list and
     * loading Course models would drag $appends along with them.
     */
    protected function recentActivity(int $studentId): array
    {
        return DB::table('lesson_checklists as lc')
            ->join('course_module_lessons as l', 'lc.course_module_lesson_id', '=', 'l.id')
            ->join('course_modules as m', 'l.course_module_id', '=', 'm.id')
            ->join('courses as c', 'm.course_id', '=', 'c.id')
            ->leftJoin('course_translations as ct', function ($join) {
                $join->on('ct.course_id', '=', 'c.id')
                    ->where('ct.lang_code', '=', config('app.locale', 'en'));
            })
            ->where('lc.student_id', $studentId)
            ->select([
                'c.id as course_id',
                'c.slug as course_slug',
                DB::raw('coalesce(ct.title, concat("Course #", c.id)) as course_title'),
                'm.name as module_name',
                'l.id as lesson_id',
                'l.name as lesson_name',
                'lc.created_at',
            ])
            ->orderByDesc('lc.created_at')
            ->limit(10)
            ->get()
            ->map(fn ($row) => [
                'course_id'    => (int) $row->course_id,
                'course_slug'  => $row->course_slug,
                'course_title' => html_decode((string) $row->course_title),
                'module_name'  => html_decode((string) $row->module_name),
                'lesson_id'    => (int) $row->lesson_id,
                'lesson_name'  => html_decode((string) $row->lesson_name),
                'completed_at' => $row->created_at ? Carbon::parse($row->created_at)->toIso8601String() : null,
            ])
            ->all();
    }

    /** Lessons completed per day for the last seven days, labels included. */
    protected function weeklyProgress(int $studentId): array
    {
        $start = Carbon::now()->subDays(6)->startOfDay();

        $counts = DB::table('lesson_checklists')
            ->where('student_id', $studentId)
            ->where('created_at', '>=', $start)
            ->select([
                DB::raw('date(created_at) as period'),
                DB::raw('count(distinct course_module_lesson_id) as completed'),
            ])
            ->groupBy('period')
            ->pluck('completed', 'period');

        $labels = [];
        $data = [];

        for ($date = $start->copy(); $date->lte(Carbon::now()); $date->addDay()) {
            $labels[] = $date->format('D');
            $data[] = (int) ($counts[$date->format('Y-m-d')] ?? 0);
        }

        return ['labels' => $labels, 'data' => $data];
    }

    /**
     * Consecutive days with at least one completion.
     *
     * Rewritten rather than transcribed: the Blade implementation compares
     * Carbon::diffInDays() — which is unsigned by default — and only updates
     * the current streak while $i === 0, so a three-day streak reports as two.
     * The definition is the same; the arithmetic works.
     */
    protected function learningStreak(int $studentId): array
    {
        $dates = DB::table('lesson_checklists')
            ->where('student_id', $studentId)
            ->select(DB::raw('date(created_at) as day'))
            ->distinct()
            ->orderByDesc('day')
            ->pluck('day')
            ->map(fn ($day) => Carbon::parse($day)->startOfDay())
            ->values();

        if ($dates->isEmpty()) {
            return ['current_streak' => 0, 'longest_streak' => 0, 'last_activity' => null];
        }

        $longest = 1;
        $run = 1;

        for ($i = 0; $i < $dates->count() - 1; $i++) {
            $gap = $dates[$i + 1]->diffInDays($dates[$i]);

            if ($gap === 1) {
                $run++;
                $longest = max($longest, $run);
            } else {
                $run = 1;
            }
        }

        // A streak is only "current" if it reaches today or yesterday.
        $current = 0;
        $today = Carbon::today();

        if ($dates[0]->equalTo($today) || $dates[0]->equalTo($today->copy()->subDay())) {
            $current = 1;
            for ($i = 0; $i < $dates->count() - 1; $i++) {
                if ($dates[$i + 1]->diffInDays($dates[$i]) !== 1) {
                    break;
                }
                $current++;
            }
        }

        return [
            'current_streak' => $current,
            'longest_streak' => max($longest, $current),
            'last_activity'  => $dates[0]->toDateString(),
        ];
    }

    /** @param array<int, int> $courseIds */
    protected function upcomingSessions(array $courseIds): array
    {
        if ($courseIds === []) {
            return [];
        }

        return DB::table('meetings')
            ->whereIn('course_id', $courseIds)
            ->where('start_time', '>=', Carbon::now()->startOfDay())
            ->orderBy('start_time')
            ->limit(3)
            ->get(['id', 'title', 'start_time', 'meeting_link', 'course_id'])
            ->map(fn ($row) => [
                'id'         => (int) $row->id,
                'title'      => html_decode((string) ($row->title ?: 'Live session')),
                'starts_at'  => $row->start_time ? Carbon::parse($row->start_time)->toIso8601String() : null,
                'link'       => $row->meeting_link,
            ])
            ->all();
    }

    /**
     * Announcements for the student's own programmes, plus the academy-wide
     * ones (course_id null or 0).
     *
     * @param  array<int, int>  $courseIds
     */
    protected function announcements(array $courseIds): array
    {
        return DB::table('notice_boards')
            ->where(function ($query) use ($courseIds) {
                $query->whereNull('course_id')->orWhere('course_id', 0);

                if ($courseIds !== []) {
                    $query->orWhereIn('course_id', $courseIds);
                }
            })
            ->orderByDesc('created_at')
            ->limit(3)
            ->get(['id', 'title', 'description', 'created_at'])
            ->map(fn ($row) => [
                'id'         => (int) $row->id,
                'title'      => html_decode((string) ($row->title ?: 'Announcement')),
                'excerpt'    => \Illuminate\Support\Str::limit(
                    strip_tags(html_decode((string) ($row->description ?? ''))),
                    140
                ),
                'created_at' => $row->created_at ? Carbon::parse($row->created_at)->toIso8601String() : null,
            ])
            ->all();
    }

    /** Whole minutes in, "2h 15m" out. */
    protected function formatMinutes(int $minutes): string
    {
        if ($minutes <= 0) {
            return '0m';
        }

        $hours = intdiv($minutes, 60);
        $rest = $minutes % 60;

        if ($hours > 0) {
            return $rest > 0 ? "{$hours}h {$rest}m" : "{$hours}h";
        }

        return "{$rest}m";
    }
}
