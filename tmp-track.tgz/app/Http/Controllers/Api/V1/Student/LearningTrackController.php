<?php

namespace App\Http\Controllers\Api\V1\Student;

use App\Http\Controllers\Controller;
use App\Support\LearningTrack;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * GET  student/learning-track            → the student's course language.
 * GET  student/learning-track?set=am|en  → choose it (the website EN/አማ course switch).
 * POST student/learning-track {track}    → same, for clients that post.
 * set=auto clears the choice (back to "the track you progressed in").
 */
class LearningTrackController extends Controller
{
    public function __invoke(Request $request, LearningTrack $tracks): JsonResponse
    {
        $id = (int) $request->user()->id;
        $set = $request->input('set', $request->input('track'));

        if ($set !== null) {
            $tracks->set($id, in_array($set, LearningTrack::TRACKS, true) ? $set : null);
        }

        return response()->json(['data' => [
            'track' => $tracks->forStudent($id),
            'chosen' => $tracks->explicit($id),
        ]]);
    }
}
