<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * One course language per student (2026-11-20, Molla).
 *
 * The academy has two parallel tracks (Amharic, English) of 13 modules each.
 * Showing both side by side made students open the other language by mistake
 * and hit "finish Module N first". So the course lists the website and the
 * mobile app read show only the student's track:
 *
 *   1. users.learning_track when the student chose one (EN/አማ course switch);
 *   2. otherwise the track they have completed the most lessons in
 *      (ties: the track of their latest completed lesson);
 *   3. no progress yet → null → both tracks are shown, so they can pick.
 *
 * Courses outside the two tracks are never hidden.
 */
class LearningTrack
{
    public const TRACKS = ['am', 'en'];

    public static function ready(): bool
    {
        static $ready = null;

        return $ready ??= Schema::hasColumn('users', 'learning_track');
    }

    /** 'am' | 'en' | null for a course slug. */
    public static function ofSlug(?string $slug): ?string
    {
        return CourseRelease::parse($slug)['track'] ?? null;
    }

    public function explicit(int $studentId): ?string
    {
        if (! self::ready()) {
            return null;
        }
        $t = DB::table('users')->where('id', $studentId)->value('learning_track');

        return in_array($t, self::TRACKS, true) ? $t : null;
    }

    public function inferred(int $studentId): ?string
    {
        return Cache::remember("learning_track.inferred.{$studentId}", 600, function () use ($studentId) {
            $rows = DB::table('lesson_checklists as lc')
                ->join('course_module_lessons as l', 'l.id', '=', 'lc.course_module_lesson_id')
                ->join('course_modules as m', 'm.id', '=', 'l.course_module_id')
                ->join('courses as c', 'c.id', '=', 'm.course_id')
                ->where('lc.student_id', $studentId)
                ->where('c.slug', 'like', 'session-%')
                ->groupBy('c.slug')
                ->selectRaw('c.slug, count(distinct lc.course_module_lesson_id) as done, max(lc.id) as last_id')
                ->get();

            $score = ['am' => 0, 'en' => 0];
            $last = ['am' => 0, 'en' => 0];
            foreach ($rows as $r) {
                $t = self::ofSlug($r->slug);
                if ($t) {
                    $score[$t] += (int) $r->done;
                    $last[$t] = max($last[$t], (int) $r->last_id);
                }
            }
            if ($score['am'] === 0 && $score['en'] === 0) {
                return null;
            }
            if ($score['am'] === $score['en']) {
                return $last['en'] > $last['am'] ? 'en' : 'am';
            }

            return $score['am'] > $score['en'] ? 'am' : 'en';
        });
    }

    public function forStudent(int $studentId): ?string
    {
        return $this->explicit($studentId) ?? $this->inferred($studentId);
    }

    /**
     * Keep only the student's track (plus every non-track course).
     *
     * @param  int[]  $courseIds
     * @return int[]
     */
    public function filterIds(array $courseIds, int $studentId): array
    {
        $track = $this->forStudent($studentId);
        if ($track === null || $courseIds === []) {
            return $courseIds;
        }
        $slugs = DB::table('courses')->whereIn('id', $courseIds)->pluck('slug', 'id');

        return array_values(array_filter($courseIds, function ($id) use ($slugs, $track) {
            $t = self::ofSlug($slugs[$id] ?? null);

            return $t === null || $t === $track;
        }));
    }

    public function set(int $studentId, ?string $track): void
    {
        if (! self::ready()) {
            return;
        }
        DB::table('users')->where('id', $studentId)->update([
            'learning_track' => in_array($track, self::TRACKS, true) ? $track : null,
        ]);
        Cache::forget("learning_track.inferred.{$studentId}");
    }
}
