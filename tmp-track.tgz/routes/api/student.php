<?php

/*
|--------------------------------------------------------------------------
| Student API routes
|--------------------------------------------------------------------------
|
| Loaded by routes/api.php inside the /api/v1 group, so every path here is
| relative to /api/v1 and every route name is prefixed api.v1.
|
| This file is owned by the student area. Keeping each area in its own file is
| deliberate: several people (and several agents) edit these concurrently, and
| a single shared routes file loses work to clobbering.
|
| Authorization is NOT optional here. Every route must sit behind auth plus the
| appropriate role middleware, and every controller must additionally authorize
| the specific record — role alone does not prove ownership.
|
*/

use App\Http\Controllers\Api\V1\Student\AccountController;
use App\Http\Controllers\Api\V1\Student\CertificateController;
use App\Http\Controllers\Api\V1\Student\DashboardController;
use App\Http\Controllers\Api\V1\Student\EnrolledCourseController;
use App\Http\Controllers\Api\V1\Student\EnrolmentController;
use App\Http\Controllers\Api\V1\Student\LessonController;
use App\Http\Controllers\Api\V1\Student\OrderController;
use App\Http\Controllers\Api\V1\Student\ProfileController;
use App\Http\Controllers\Api\V1\Student\QuizController;
use Illuminate\Support\Facades\Route;


/*
| Public homepage payload. Lives in this file only because routes/api.php is a
| shared-edit hazard while several areas are being built concurrently; it has
| nothing to do with the student portal and should move to the public block
| once the portal work settles.
*/
Route::get('home', \App\Http\Controllers\Api\V1\HomeController::class)->name('home');


/*
| ---------------------------------------------------------------------------
| The student portal proper.
| ---------------------------------------------------------------------------
|
| Two middleware, doing two different jobs, and both are required:
|
|   auth:sanctum   there is a session at all      -> 401 without one
|   role:student   that session belongs to a student -> 403 for an instructor
|
| Neither says anything about WHICH course, lesson, quiz, order or certificate
| is being asked for. That is the controllers' job, and every one of them either
| calls a policy on the loaded record (CoursePolicy::viewContent,
| CourseModuleLessonPolicy::complete, QuizPolicy::view / ::attempt,
| CourseEnrollmentPolicy::viewAny, UserPolicy::view / ::update) or scopes the
| query by student_id so a foreign row can never be in the result set.
|
| Route-model binding is deliberately NOT used for {lesson} and {quiz}. Binding
| resolves the record before anything else runs, but these controllers need the
| surrounding course first — "is this lesson unlocked for you" cannot be
| answered from the lesson alone — so the lookup stays visible in the method.
*/
Route::middleware(['auth:sanctum', 'role:student'])
    ->prefix('student')
    ->name('student.')
    ->group(function () {

        // Dashboard widgets: tiles, activity series, streak, upcoming sessions.
        Route::get('dashboard', DashboardController::class)->name('dashboard');

        // Course language (Amharic / English track) — 2026-11-20.
        Route::match(['get', 'post'], 'learning-track', \App\Http\Controllers\Api\V1\Student\LearningTrackController::class)->name('learning-track');

        /*
        | Learning journey and the course player.
        |
        | The player is keyed by slug to match the public catalogue URL, so a
        | student following a link from /courses/{slug} lands on the same
        | programme they were reading about.
        */
        Route::get('courses', [EnrolledCourseController::class, 'index'])->middleware('ib.access')->name('courses.index');
        Route::get('courses/{slug}', [EnrolledCourseController::class, 'show'])->middleware('ib.access')->name('courses.show');

        /*
        | Enrol. Free programmes only — a priced one is refused here and
        | belongs to checkout. Idempotent, so a double-tap is not an error.
        |
        | Throttled because it writes: it is the only student route that
        | creates an order row, and a slug is public.
        */
        Route::post('courses/{slug}/enroll', [EnrolmentController::class, 'store'])
            ->middleware(['throttle:20,1', 'ib.access'])
            ->name('courses.enroll');

        // Idempotent: a repeat POST reports the same percentage rather than
        // toggling the lesson back off, which is what the Blade endpoint does.
        Route::post('lessons/{lesson}/complete', [LessonController::class, 'complete'])
            ->middleware('ib.access')->whereNumber('lesson')
            ->name('lessons.complete');

        /*
        | Quizzes. The GET returns questions with NO correct_answer and NO
        | explanation; the POST carries answers only — there is no field for a
        | score, because the server computes it.
        */
        Route::get('quizzes/{quiz}', [QuizController::class, 'show'])
            ->middleware('ib.access')->whereNumber('quiz')
            ->name('quizzes.show');
        Route::post('quizzes/{quiz}/submit', [QuizController::class, 'submit'])
            ->middleware('ib.access')->whereNumber('quiz')
            ->name('quizzes.submit');

        // Certificates. The download streams the same PDF the Blade route
        // produces, from the same template and the same builder settings.
        Route::get('certificates', [CertificateController::class, 'index'])->name('certificates.index');
        Route::get('certificates/{certificate}/download', [CertificateController::class, 'download'])
            ->whereNumber('certificate')
            ->name('certificates.download');
        // One-time feedback before the first download (2026-11-13).
        Route::post('certificates/{certificate}/review', [CertificateController::class, 'review'])
            ->middleware('throttle:10,1')->whereNumber('certificate')
            ->name('certificates.review');

        // Enrolment history.
        Route::get('orders', [OrderController::class, 'index'])->name('orders.index');

        // Own profile. No {user} parameter anywhere: the record is the session.
        Route::get('profile', [ProfileController::class, 'show'])->name('profile.show');
        Route::put('profile', [ProfileController::class, 'update'])->name('profile.update');

        // Self-service account deletion (soft delete; see AccountController).
        Route::delete('account', [AccountController::class, 'destroy'])->name('account.destroy');
    });

/*
| Lesson content.
|
| The player endpoint returns curriculum metadata only, so nothing could render
| a lesson body, PDF or video — this serves the content for one lesson, behind
| the same enrolment and sequential-unlock rules as the rest of the portal.
*/
Route::middleware(['auth:web', 'role:student', 'ib.access'])->prefix('student')->name('student.')->group(function () {
    Route::get('lessons/{lesson}', [\App\Http\Controllers\Api\V1\Student\LessonContentController::class, 'show'])
        ->whereNumber('lesson')
        ->name('lessons.show');

    /*
    | The lesson's attached material (the session PDF), streamed.
    |
    | Added for the mobile app. The web portal does not call it and is
    | unaffected: lessons.show still reports file: null, exactly as it has since
    | 2026-09-18. Serving the bytes here rather than returning the
    | /storage/... path keeps that path — which is public once known — out of
    | any response, and re-applies enrolment and the sequential-unlock rule on
    | every fetch.
    */
    Route::get('lessons/{lesson}/file', [\App\Http\Controllers\Api\V1\Student\LessonContentController::class, 'download'])
        ->whereNumber('lesson')
        ->name('lessons.file');
});

/*
| Sidebar parity: quiz history, announcements, live sessions, support tickets.
| Each mirrors the scoping of its Blade counterpart — see the controllers.
| Literal segments (quiz-history) sit above wildcard siblings on principle,
| though nothing here collides today.
*/
Route::middleware(['auth:web', 'role:student'])->prefix('student')->name('student.')->group(function () {
    Route::get('quiz-history', [\App\Http\Controllers\Api\V1\Student\QuizHistoryController::class, 'index'])->middleware('ib.access')
        ->name('quiz-history.index');
    Route::get('quiz-history/{id}', [\App\Http\Controllers\Api\V1\Student\QuizHistoryController::class, 'show'])->middleware('ib.access')
        ->whereNumber('id')->name('quiz-history.show');
    // Issue 46 — answer review for one of the student's own attempts.
    Route::get('quiz-history/{id}/review', [\App\Http\Controllers\Api\V1\Student\QuizHistoryController::class, 'review'])->middleware('ib.access')
        ->whereNumber('id')->name('quiz-history.review');

    Route::get('notices', [\App\Http\Controllers\Api\V1\Student\NoticeBoardController::class, 'index'])
        ->name('notices.index');

    Route::get('meetings', [\App\Http\Controllers\Api\V1\Student\MeetingController::class, 'index'])->middleware('ib.access')
        ->name('meetings.index');

    /*
     | Homework: what is assigned on the student's courses, one submission
     | each. Drafts and other courses' assignments do not exist here.
     */
    Route::get('homeworks', [\App\Http\Controllers\Api\V1\Student\HomeworkController::class, 'index'])->middleware('ib.access')
        ->name('homeworks.index');
    Route::get('homeworks/{homework}', [\App\Http\Controllers\Api\V1\Student\HomeworkController::class, 'show'])->middleware('ib.access')
        ->whereNumber('homework')->name('homeworks.show');
    Route::post('homeworks/{homework}/submit', [\App\Http\Controllers\Api\V1\Student\HomeworkController::class, 'submit'])->middleware('ib.access')
        ->whereNumber('homework')->name('homeworks.submit');

    // The bonus shelf — published lessons outside the 26-module curriculum.
    // Never part of course progress or the final exam, by construction.
    Route::get('bonus-lessons', [\App\Http\Controllers\Api\V1\Student\BonusLessonController::class, 'index'])->middleware('ib.access')
        ->name('bonus-lessons.index');
    Route::get('bonus-lessons/{lesson}', [\App\Http\Controllers\Api\V1\Student\BonusLessonController::class, 'show'])->middleware('ib.access')
        ->whereNumber('lesson')->name('bonus-lessons.show');

    // A student shares their story; it stays 'pending' until the team
    // approves it in the admin Testimonial screen.
    Route::post('testimonials', [\App\Http\Controllers\Api\V1\Student\TestimonialController::class, 'store'])
        ->middleware('throttle:10,1')->name('testimonials.store');
    // Issue 52 — the student's own submission and its private image.
    Route::get('testimonials/mine', [\App\Http\Controllers\Api\V1\Student\TestimonialController::class, 'mine'])
        ->name('testimonials.mine');
    Route::get('testimonials/{id}/image', [\App\Http\Controllers\Api\V1\Student\TestimonialController::class, 'image'])
        ->whereNumber('id')->name('testimonials.image');

    Route::get('support-tickets', [\App\Http\Controllers\Api\V1\Student\SupportTicketController::class, 'index'])
        ->name('support-tickets.index');
    Route::post('support-tickets', [\App\Http\Controllers\Api\V1\Student\SupportTicketController::class, 'store'])
        ->middleware('throttle:10,1')->name('support-tickets.store');
    Route::get('support-tickets/{ticketId}', [\App\Http\Controllers\Api\V1\Student\SupportTicketController::class, 'show'])
        ->name('support-tickets.show');
    Route::post('support-tickets/{ticketId}/reply', [\App\Http\Controllers\Api\V1\Student\SupportTicketController::class, 'reply'])
        ->middleware('throttle:20,1')->name('support-tickets.reply');
});
