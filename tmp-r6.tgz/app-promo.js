/* Trade Insight — "Get the app" floating button (2026-11-20).
 * Body-level only (outside the React root), so the SPA is never touched.
 * Android + desktop: Google Play link. iPhone: hidden until the iOS app is live.
 * Dismiss (×) hides it for 7 days. Amharic when the EN/አማ switch is on Amharic. */
(function () {
  'use strict';
  var PLAY = 'https://play.google.com/store/apps/details?id=com.trade.insight.app';
  var KEY = 'ti-app-promo-hide';
  var ua = navigator.userAgent || '';
  if (/iPhone|iPad|iPod/i.test(ua)) return;
  try { var h = +localStorage.getItem(KEY); if (h && Date.now() < h) return; } catch (e) {}
  function am() { try { return localStorage.getItem('ti-ui-lang') === 'am'; } catch (e) { return false; } }
  function build() {
    if (document.getElementById('ti-app-promo')) return;
    var box = document.createElement('div');
    box.id = 'ti-app-promo';
    box.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:9998;display:flex;align-items:center;gap:6px;font-family:inherit';
    var a = document.createElement('a');
    a.href = PLAY; a.target = '_blank'; a.rel = 'noopener';
    a.style.cssText = 'display:inline-flex;align-items:center;gap:8px;padding:10px 16px;border-radius:999px;background:#0b0f3b;color:#fff;font-weight:600;font-size:14px;text-decoration:none;box-shadow:0 8px 24px rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.15)';
    var x = document.createElement('button');
    x.type = 'button'; x.setAttribute('aria-label', 'Close');
    x.textContent = '×';
    x.style.cssText = 'width:28px;height:28px;border-radius:999px;border:0;background:rgba(11,15,59,.85);color:#fff;font-size:16px;line-height:1;cursor:pointer';
    x.onclick = function () { try { localStorage.setItem(KEY, String(Date.now() + 7 * 864e5)); } catch (e) {} box.remove(); };
    function label() {
      a.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="#fd7e14" aria-hidden="true"><path d="M3.6 2.2 13.4 12l-9.8 9.8c-.4-.2-.6-.6-.6-1.1V3.3c0-.5.2-.9.6-1.1Zm11 11 2.6 2.6-11.6 6.6 9-9.2Zm3.9-3.9 3 1.7c.8.5.8 1.6 0 2.1l-3 1.7-2.8-2.8 2.8-2.7ZM5.6 1.6l11.6 6.6-2.6 2.6-9-9.2Z"/></svg>'
        + (am() ? 'App ያውርዱ · Google Play' : 'Get the app · Google Play');
    }
    label();
    box.appendChild(a); box.appendChild(x);
    document.body.appendChild(box);
    window.addEventListener('storage', label);
    document.addEventListener('click', function () { setTimeout(label, 50); }, true);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
