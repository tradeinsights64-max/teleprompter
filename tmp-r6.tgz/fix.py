import os,re,shutil,json
os.chdir('/var/www/TradeInsightProduction/TD/StudentPortal'); B='/root/backups/app-promo-20261120'; os.makedirs(B,exist_ok=True)
def rd(p): return open(p,encoding='utf-8').read()
def wr(p,s): open(p,'w',encoding='utf-8').write(s)
def q(x): return json.dumps(x,ensure_ascii=False)
OLD='Stop guessing the market. All courses, live sessions every week and a VIP community — all free. Your seat is waiting in our Telegram bot.'
NEW='Stop guessing the market. All courses and a VIP community — all free. Your seat is waiting in our Telegram bot.'
AMNEW='ማርኬቱን በግምት መነገድ ይብቃ። ሁሉም ኮርሶች እና VIP community — ሁሉም ነጻ። ቦታዎ በTelegram bot ይጠብቅዎታል።'
s=rd('assets/Home-ti1120e.js'); n1=s.count(OLD); s=s.replace(OLD,NEW)
anchor='children:x?.secondary_cta?.label??"See the curriculum"})'
btn=',e.jsx("a",{href:"https://play.google.com/store/apps/details?id=com.trade.insight.app",target:"_blank",rel:"noopener",className:"inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3 font-semibold text-white backdrop-blur-md transition-colors hover:bg-white/10 sm:w-auto",children:"📱 Get the app"})'
n2=s.count(anchor); s=s.replace(anchor,anchor+btn,1)
wr('assets/Home-ti1120f.js',s); print('hero',n1,'button',n2)
p='assets/index-BaObQ8fx.js'; t=rd(p); shutil.copy2(p,B+'/index-BaObQ8fx.js'); wr(p,t.replace('Home-ti1120e.js','Home-ti1120f.js')); print('ref',t.count('Home-ti1120e.js'))
a=rd('i18n/am.js'); shutil.copy2('i18n/am.js',B+'/am.js')
a=a.replace(q(OLD)+': ',q(NEW)+': ',1)
a=re.sub(re.escape(q(NEW))+r': "(?:[^"\\]|\\.)*"',lambda m: q(NEW)+': '+q(AMNEW),a,1)
anc='"100% Free": "100% ነጻ"'; a=a.replace(anc,anc+', '+q('📱 Get the app')+': '+q('📱 App ያውርዱ'),1)
wr('i18n/am.js',a); print('am new', q(NEW) in a)
shutil.copy2('/root/r6/app-promo.js','i18n/app-promo.js')
h=rd('index.html'); shutil.copy2('index.html',B+'/index.html')
h=re.sub(r'am\.js\?v=[0-9a-z]+','am.js?v=20261120h',h)
if 'app-promo.js' not in h: h=h.replace('</body>','  <script src="/i18n/app-promo.js?v=1" defer></script>\n</body>',1)
wr('index.html',h); print('promo tag', 'app-promo.js' in h)
